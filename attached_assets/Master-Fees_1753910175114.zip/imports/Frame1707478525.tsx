function Frame1707478531({ collectionPercentage }: { collectionPercentage: number }) {
  return (
    <div className="bg-[#c0f1e5] box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-2.5 py-0.5 relative rounded-[15px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-end leading-[0] not-italic relative shrink-0 text-[#025864] text-[8px] text-left w-[57px]">
        <p className="block leading-[10px]">{Math.round(collectionPercentage)}% Collected</p>
      </div>
    </div>
  );
}

function Frame1707478527({ selectedTerm, collectionPercentage }: { selectedTerm: string; collectionPercentage: number }) {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[244px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[16px] text-left w-[226px]">
        <p className="block leading-[20px]">Tuition Fees - {selectedTerm} | 2025</p>
      </div>
      <Frame1707478531 collectionPercentage={collectionPercentage} />
    </div>
  );
}

function Frame1707478517({ selectedTerm, collectionPercentage }: { selectedTerm: string; collectionPercentage: number }) {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-start p-0 relative shrink-0 w-[448px]">
      <Frame1707478527 selectedTerm={selectedTerm} collectionPercentage={collectionPercentage} />
    </div>
  );
}

function Frame1707478538({ revenue }: { revenue: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] gap-0.5 items-center justify-center leading-[0] not-italic p-0 relative shrink-0 text-nowrap">
      <div className="flex flex-col justify-center relative shrink-0 text-[#000000] text-[16px] text-center">
        <p className="block leading-[20px] text-nowrap whitespace-pre">
          {formatCurrency(revenue)}
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#7d827d] text-[8px] text-left">
        <p className="block leading-[10px] text-nowrap whitespace-pre">
          Revenue
        </p>
      </div>
    </div>
  );
}

function Frame1707478539({ collected }: { collected: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] gap-0.5 items-center justify-center leading-[0] not-italic p-0 relative shrink-0 text-nowrap">
      <div className="flex flex-col justify-center relative shrink-0 text-[#000000] text-[16px] text-center">
        <p className="block leading-[20px] text-nowrap whitespace-pre">
          {formatCurrency(collected)}
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#8a8e8a] text-[8px] text-left">
        <p className="block leading-[10px] text-nowrap whitespace-pre">
          Collected
        </p>
      </div>
    </div>
  );
}

function Frame1707478540({ balance }: { balance: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] gap-0.5 items-center justify-center leading-[0] not-italic p-0 relative shrink-0 text-nowrap">
      <div className="flex flex-col justify-center relative shrink-0 text-[#000000] text-[16px] text-center">
        <p className="block leading-[20px] text-nowrap whitespace-pre">{formatCurrency(balance)}</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#8a8e8a] text-[8px] text-left">
        <p className="block leading-[10px] text-nowrap whitespace-pre">
          Balance
        </p>
      </div>
    </div>
  );
}

function Frame1707478518({ revenue, collected, balance }: { revenue: number; collected: number; balance: number }) {
  return (
    <div className="box-border content-stretch flex flex-row gap-[77px] items-center justify-start p-0 relative shrink-0">
      <Frame1707478538 revenue={revenue} />
      <Frame1707478539 collected={collected} />
      <Frame1707478540 balance={balance} />
    </div>
  );
}

function Frame1707478541({ totalPupils }: { totalPupils: number }) {
  return (
    <div className="box-border content-stretch flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] gap-0.5 items-center justify-center leading-[0] not-italic p-0 relative shrink-0 text-nowrap">
      <div className="flex flex-col justify-center relative shrink-0 text-[#000000] text-[16px] text-center">
        <p className="block leading-[20px] text-nowrap whitespace-pre">{totalPupils}</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 text-[#8a8e8a] text-[8px] text-left">
        <p className="block leading-[10px] text-nowrap whitespace-pre">
          Pupils
        </p>
      </div>
    </div>
  );
}

interface Frame1707478525Props {
  selectedTerm: string;
  totalRevenue: number;
  totalCollected: number;
  outstandingBalance: number;
  totalPupils: number;
  loading?: boolean;
}

export default function Frame1707478525({ 
  selectedTerm, 
  totalRevenue, 
  totalCollected, 
  outstandingBalance, 
  totalPupils,
  loading = false 
}: Frame1707478525Props) {
  // Calculate collection percentage
  const collectionPercentage = totalRevenue > 0 ? (totalCollected / totalRevenue) * 100 : 0;
  
  // Calculate balance (total revenue minus outstanding)
  const balance = totalRevenue - outstandingBalance;

  if (loading) {
    return (
      <div className="bg-[#eff3f5] relative size-full">
        <div className="flex flex-row items-center justify-center relative size-full">
          <div className="animate-pulse flex space-x-8">
            <div className="flex-1 space-y-2 py-1">
              <div className="h-4 bg-gray-300 rounded w-48"></div>
              <div className="h-3 bg-gray-300 rounded w-24"></div>
            </div>
            <div className="flex space-x-16">
              <div className="space-y-2">
                <div className="h-4 bg-gray-300 rounded w-16"></div>
                <div className="h-2 bg-gray-300 rounded w-12"></div>
              </div>
              <div className="space-y-2">
                <div className="h-4 bg-gray-300 rounded w-16"></div>
                <div className="h-2 bg-gray-300 rounded w-12"></div>
              </div>
              <div className="space-y-2">
                <div className="h-4 bg-gray-300 rounded w-16"></div>
                <div className="h-2 bg-gray-300 rounded w-12"></div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-300 rounded w-8"></div>
              <div className="h-2 bg-gray-300 rounded w-10"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#eff3f5] relative size-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-28 items-center justify-start pl-[45px] pr-[52px] py-2 relative size-full">
          <Frame1707478517 
            selectedTerm={selectedTerm} 
            collectionPercentage={collectionPercentage} 
          />
          <Frame1707478518 
            revenue={totalRevenue} 
            collected={totalCollected} 
            balance={balance} 
          />
          <Frame1707478541 totalPupils={totalPupils} />
        </div>
      </div>
    </div>
  );
}