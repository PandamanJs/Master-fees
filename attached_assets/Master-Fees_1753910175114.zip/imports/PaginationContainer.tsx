import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from "sonner@2.0.3";
import svgPaths from "./svg-xzpgbx7l9p";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  onPageChange: (page: number) => void;
  onItemsPerPageChange?: (itemsPerPage: number) => void;
  loading?: boolean;
  disabled?: boolean;
}

const ITEMS_PER_PAGE_OPTIONS = [5, 10, 20, 25, 50, 100];

export default function PaginationContainer({
  currentPage = 1,
  totalPages = 1,
  totalItems = 0,
  itemsPerPage = 10,
  onPageChange,
  onItemsPerPageChange,
  loading = false,
  disabled = false
}: PaginationProps) {
  const [showItemsPerPageDropdown, setShowItemsPerPageDropdown] = useState(false);
  const [isChangingPage, setIsChangingPage] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Handle clicks outside dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowItemsPerPageDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handlePageChange = async (newPage: number) => {
    if (newPage === currentPage || newPage < 1 || newPage > totalPages || loading || disabled) {
      return;
    }

    try {
      setIsChangingPage(true);
      await onPageChange(newPage);
      
      // Show feedback for page changes
      toast.info(`Navigated to page ${newPage} of ${totalPages}`);
      
    } catch (error) {
      console.error('Error changing page:', error);
      toast.error('Failed to change page. Please try again.');
    } finally {
      setIsChangingPage(false);
    }
  };

  const handleItemsPerPageChange = async (newItemsPerPage: number) => {
    if (newItemsPerPage === itemsPerPage || !onItemsPerPageChange) return;

    try {
      setIsChangingPage(true);
      await onItemsPerPageChange(newItemsPerPage);
      setShowItemsPerPageDropdown(false);
      
      // Calculate what page to show after changing items per page
      const newTotalPages = Math.ceil(totalItems / newItemsPerPage);
      const currentFirstItem = (currentPage - 1) * itemsPerPage + 1;
      const newPage = Math.min(Math.ceil(currentFirstItem / newItemsPerPage), newTotalPages);
      
      if (newPage !== currentPage) {
        await onPageChange(newPage);
      }
      
      toast.success(`Showing ${newItemsPerPage} items per page`);
      
    } catch (error) {
      console.error('Error changing items per page:', error);
      toast.error('Failed to update page size. Please try again.');
    } finally {
      setIsChangingPage(false);
    }
  };

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const showEllipsis = totalPages > 7;

    if (!showEllipsis) {
      // Show all pages if 7 or fewer
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Complex logic for ellipsis
      if (currentPage <= 4) {
        // Near the beginning
        pages.push(1, 2, 3, 4, 5, '...', totalPages);
      } else if (currentPage >= totalPages - 3) {
        // Near the end
        pages.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
      } else {
        // In the middle
        pages.push(1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages);
      }
    }

    return pages;
  };

  const startItem = totalItems > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0;
  const endItem = Math.min(currentPage * itemsPerPage, totalItems);

  const isFirstPage = currentPage === 1;
  const isLastPage = currentPage === totalPages;
  const isDisabled = loading || disabled || isChangingPage;

  return (
    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative size-full">
      {/* Left Section - Items per page */}
      <div className="flex flex-row gap-2.5 items-center justify-start">
        <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#003049] text-[14px] text-left text-nowrap">
          <p className="block leading-[normal] whitespace-pre">Rows per page</p>
        </div>
        
        {/* Items per page dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => !isDisabled && setShowItemsPerPageDropdown(!showItemsPerPageDropdown)}
            disabled={isDisabled}
            className={`basis-0 bg-[#ffffff] box-border content-stretch flex flex-row gap-1 items-center justify-center min-h-px min-w-px px-[15px] py-2 relative rounded-[20px] shrink-0 w-[58px] transition-all ${
              isDisabled 
                ? 'opacity-50 cursor-not-allowed' 
                : 'hover:border-[#003049] hover:shadow-sm cursor-pointer'
            }`}
            aria-label={`Items per page: ${itemsPerPage}`}
            aria-expanded={showItemsPerPageDropdown}
          >
            <div className="absolute border border-[#dddddd] border-solid inset-0 pointer-events-none rounded-[20px]" />
            <div className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#003049] text-[14px] text-left text-nowrap">
              <p className="block leading-[normal] whitespace-pre">
                {isChangingPage ? '...' : itemsPerPage}
              </p>
            </div>
            <div className={`relative shrink-0 size-4 transition-transform ${showItemsPerPageDropdown ? 'rotate-180' : ''}`}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
                <path d={svgPaths.pd1b0400} fill="var(--fill-0, #003049)" />
              </svg>
            </div>
          </button>

          <AnimatePresence>
            {showItemsPerPageDropdown && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: -10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -10 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 top-12 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[80px] z-50"
              >
                {ITEMS_PER_PAGE_OPTIONS.map((option) => (
                  <button
                    key={option}
                    onClick={() => handleItemsPerPageChange(option)}
                    disabled={isDisabled}
                    className={`w-full text-left px-3 py-1.5 text-sm transition-colors ${
                      option === itemsPerPage
                        ? 'bg-[#003049] text-white'
                        : 'hover:bg-gray-50 text-gray-700'
                    } ${isDisabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                  >
                    {option}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#003049] text-[14px] text-left text-nowrap">
          <p className="block leading-[normal] whitespace-pre">
            {totalItems > 0 
              ? `${startItem}-${endItem} of ${totalItems.toLocaleString()} rows`
              : 'No rows to display'
            }
          </p>
        </div>
      </div>

      {/* Right Section - Page navigation */}
      <div className="flex flex-row gap-[5px] items-start justify-start">
        {/* First page button */}
        <button
          onClick={() => handlePageChange(1)}
          disabled={isDisabled || isFirstPage}
          className={`bg-[#ffffff] box-border content-stretch flex flex-col gap-2.5 items-center justify-center p-[10px] relative rounded-[20px] shrink-0 size-8 transition-all ${
            isDisabled || isFirstPage
              ? 'opacity-50 cursor-not-allowed'
              : 'hover:border-[#003049] hover:shadow-sm cursor-pointer'
          }`}
          title="First page"
          aria-label="Go to first page"
        >
          <div className="absolute border border-[#f1f1f1] border-solid inset-0 pointer-events-none rounded-[20px]" />
          <div className="relative shrink-0 size-4">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p7933000} fill="var(--fill-0, #003049)" />
              <path d={svgPaths.p22afa4f0} fill="var(--fill-0, #003049)" />
            </svg>
          </div>
        </button>

        {/* Previous page button */}
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={isDisabled || isFirstPage}
          className={`bg-[#ffffff] box-border content-stretch flex flex-col gap-2.5 items-center justify-center p-[10px] relative rounded-[20px] shrink-0 size-8 transition-all ${
            isDisabled || isFirstPage
              ? 'opacity-50 cursor-not-allowed'
              : 'hover:border-[#003049] hover:shadow-sm cursor-pointer'
          }`}
          title="Previous page"
          aria-label="Go to previous page"
        >
          <div className="absolute border border-[#f1f1f1] border-solid inset-0 pointer-events-none rounded-[20px]" />
          <div className="relative shrink-0 size-4">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.p1abd2a00} fill="var(--fill-0, #003049)" />
            </svg>
          </div>
        </button>

        {/* Page numbers */}
        {getPageNumbers().map((page, index) => (
          <div key={`${page}-${index}`}>
            {typeof page === 'number' ? (
              <button
                onClick={() => handlePageChange(page)}
                disabled={isDisabled}
                className={`box-border content-stretch flex flex-col gap-2.5 items-center justify-center p-[10px] relative rounded-[20px] shrink-0 size-8 transition-all ${
                  page === currentPage
                    ? 'bg-[#003049] shadow-md'
                    : 'bg-[#ffffff] hover:border-[#003049] hover:shadow-sm'
                } ${
                  isDisabled 
                    ? 'opacity-50 cursor-not-allowed' 
                    : 'cursor-pointer'
                }`}
                title={`Go to page ${page}`}
                aria-label={`Go to page ${page}`}
                aria-current={page === currentPage ? 'page' : undefined}
              >
                {page !== currentPage && (
                  <div className="absolute border border-[#f1f1f1] border-solid inset-0 pointer-events-none rounded-[20px]" />
                )}
                <div className={`font-['Roboto:SemiBold',_sans-serif] font-semibold leading-[0] relative shrink-0 text-[14px] text-left text-nowrap ${
                  page === currentPage ? 'text-[#ffffff]' : 'text-[#003049]'
                }`}>
                  <p className="block leading-[normal] whitespace-pre">
                    {isChangingPage && page === currentPage ? '...' : page}
                  </p>
                </div>
              </button>
            ) : (
              // Ellipsis
              <div className="bg-[#ffffff] box-border content-stretch flex flex-col gap-2.5 items-center justify-center p-[10px] relative rounded-[20px] shrink-0 size-8">
                <div className="flex flex-col font-['Open_Sans:SemiBold',_sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#003049] text-[13px] text-left text-nowrap">
                  <p className="block leading-[normal] whitespace-pre">...</p>
                </div>
              </div>
            )}
          </div>
        ))}

        {/* Next page button */}
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={isDisabled || isLastPage}
          className={`bg-[#ffffff] box-border content-stretch flex flex-col gap-2.5 items-center justify-center p-[10px] relative rounded-[20px] shrink-0 size-8 transition-all ${
            isDisabled || isLastPage
              ? 'opacity-50 cursor-not-allowed'
              : 'hover:border-[#003049] hover:shadow-sm cursor-pointer'
          }`}
          title="Next page"
          aria-label="Go to next page"
        >
          <div className="absolute border border-[#f1f1f1] border-solid inset-0 pointer-events-none rounded-[20px]" />
          <div className="relative shrink-0 size-4">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.pd0da00} fill="var(--fill-0, #003049)" />
            </svg>
          </div>
        </button>

        {/* Last page button */}
        <button
          onClick={() => handlePageChange(totalPages)}
          disabled={isDisabled || isLastPage}
          className={`bg-[#ffffff] box-border content-stretch flex flex-col gap-2.5 items-center justify-center p-[10px] relative rounded-[20px] shrink-0 size-8 transition-all ${
            isDisabled || isLastPage
              ? 'opacity-50 cursor-not-allowed'
              : 'hover:border-[#003049] hover:shadow-sm cursor-pointer'
          }`}
          title="Last page"
          aria-label="Go to last page"
        >
          <div className="absolute border border-[#f1f1f1] border-solid inset-0 pointer-events-none rounded-[20px]" />
          <div className="relative shrink-0 size-4">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
              <path d={svgPaths.pab9d700} fill="var(--fill-0, #003049)" />
              <path d={svgPaths.p3d333980} fill="var(--fill-0, #003049)" />
            </svg>
          </div>
        </button>
      </div>

      {/* Loading indicator overlay */}
      {loading && (
        <div className="absolute inset-0 bg-white bg-opacity-50 flex items-center justify-center rounded-lg">
          <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg shadow-sm">
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-[#003049] border-t-transparent"></div>
            <span className="text-sm text-[#003049]">Loading...</span>
          </div>
        </div>
      )}
    </div>
  );
}