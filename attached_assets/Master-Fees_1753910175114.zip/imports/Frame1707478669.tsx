import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from "sonner@2.0.3";
import svgPaths from "./svg-y2ru38m37";

interface CustomerManagementHeaderProps {
  totalCustomers: number;
  activeCustomers: number;
  newCustomersThisMonth: number;
  growthRate: number;
  onAddCustomer?: (customer: NewCustomerData) => void;
  onImportData?: (file: File) => void;
  onExportData?: (format: 'csv' | 'excel' | 'pdf') => void;
  onSendReminders?: () => void;
  onBulkUpdate?: (action: string) => void;
  onSearch?: (query: string) => void;
}

interface NewCustomerData {
  studentName: string;
  class: string;
  guardianName: string;
  guardianPhone: string;
  guardianEmail: string;
  address: string;
  emergencyContact: string;
  feeStructure: string;
}

export default function Frame1707478669({
  totalCustomers = 0,
  activeCustomers = 0,
  newCustomersThisMonth = 0,
  growthRate = 0,
  onAddCustomer,
  onImportData,
  onExportData,
  onSendReminders,
  onBulkUpdate,
  onSearch
}: CustomerManagementHeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showImportExportDropdown, setShowImportExportDropdown] = useState(false);
  const [showNewCustomerModal, setShowNewCustomerModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [newCustomerData, setNewCustomerData] = useState<NewCustomerData>({
    studentName: '',
    class: '',
    guardianName: '',
    guardianPhone: '',
    guardianEmail: '',
    address: '',
    emergencyContact: '',
    feeStructure: 'Standard'
  });

  const dropdownRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle clicks outside dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowImportExportDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    onSearch?.(value);
  };

  const handleImportExportClick = () => {
    setShowImportExportDropdown(!showImportExportDropdown);
  };

  const handleExportData = async (format: 'csv' | 'excel' | 'pdf') => {
    try {
      setIsLoading(true);
      await onExportData?.(format);
      toast.success(`Customer data exported as ${format.toUpperCase()} successfully`);
      setShowImportExportDropdown(false);
    } catch (error) {
      toast.error(`Failed to export data as ${format.toUpperCase()}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
    setShowImportExportDropdown(false);
  };

  const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      setIsLoading(true);
      await onImportData?.(file);
      toast.success('Customer data imported successfully');
    } catch (error) {
      toast.error('Failed to import customer data');
    } finally {
      setIsLoading(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSendReminders = async () => {
    try {
      setIsLoading(true);
      await onSendReminders?.();
      toast.success('Payment reminders sent to customers with outstanding balances');
      setShowImportExportDropdown(false);
    } catch (error) {
      toast.error('Failed to send payment reminders');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBulkUpdate = async (action: string) => {
    try {
      setIsLoading(true);
      await onBulkUpdate?.(action);
      toast.success(`Bulk ${action} completed successfully`);
      setShowImportExportDropdown(false);
    } catch (error) {
      toast.error(`Failed to perform bulk ${action}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!newCustomerData.studentName || !newCustomerData.class || !newCustomerData.guardianName) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      setIsLoading(true);
      await onAddCustomer?.(newCustomerData);
      
      // Reset form
      setNewCustomerData({
        studentName: '',
        class: '',
        guardianName: '',
        guardianPhone: '',
        guardianEmail: '',
        address: '',
        emergencyContact: '',
        feeStructure: 'Standard'
      });
      
      setShowNewCustomerModal(false);
      toast.success(`${newCustomerData.studentName} has been added successfully`);
    } catch (error) {
      toast.error('Failed to add new customer');
    } finally {
      setIsLoading(false);
    }
  };

  const classes = [
    'Baby Class', 'Reception', 'Grade 1A', 'Grade 1B', 'Grade 2A', 'Grade 2B',
    'Grade 3A', 'Grade 3B', 'Grade 4A', 'Grade 4B', 'Grade 5A', 'Grade 5B',
    'Grade 6A', 'Grade 6B', 'Grade 7A', 'Grade 7B'
  ];

  const feeStructures = [
    'Standard', 'Scholarship', 'Staff Discount', 'Sibling Discount', 'Custom'
  ];

  return (
    <>
      <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative size-full">
        {/* Search Input */}
        <div className="box-border content-stretch flex flex-col gap-2 h-10 items-start justify-end p-0 relative shrink-0 w-[482px]">
          <div className="basis-0 bg-[#ffffff] grow min-h-px min-w-px relative rounded-lg shrink-0 w-full">
            <div className="absolute border border-[#cbd2e0] border-solid inset-0 pointer-events-none rounded-lg" />
            <div className="flex flex-row items-center relative size-full">
              <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start px-3 py-[11px] relative size-full">
                <SearchNormal1 />
                <input
                  type="text"
                  placeholder="Search customers by name, class, or phone number..."
                  value={searchQuery}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  className="basis-0 grow min-h-px min-w-px bg-transparent border-none outline-none font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] text-[12px] text-[#333333] placeholder:text-[#9ca0a4] tracking-[-0.12px]"
                  aria-label="Search customers"
                />
                {searchQuery && (
                  <button
                    onClick={() => handleSearchChange('')}
                    className="text-[#9ca0a4] hover:text-[#666666] transition-colors"
                    aria-label="Clear search"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="box-border content-stretch flex flex-row gap-[5px] items-center justify-start p-0 relative shrink-0">
          {/* Import/Export Button Group */}
          <div className="box-border content-stretch flex flex-row gap-4 h-10 items-center justify-start p-0 relative shrink-0">
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={handleImportExportClick}
                disabled={isLoading}
                className="bg-[#ffffff] box-border content-stretch flex flex-row gap-2 h-10 items-center justify-center px-4 py-2 relative rounded-lg shrink-0 border border-gray-200 hover:border-[#003049] hover:bg-gray-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Import or export customer data"
                aria-expanded={showImportExportDropdown}
              >
                <IconUpload2Line />
                <div className="box-border content-stretch flex flex-row items-center justify-center px-1 py-0 relative shrink-0">
                  <div className="flex flex-col font-['Inter:Semi_Bold',_sans-serif] font-semibold justify-center leading-[0] not-italic relative shrink-0 text-[#003049] text-[12px] text-center text-nowrap">
                    <p className="block leading-[24px] whitespace-pre">
                      {isLoading ? 'Processing...' : 'Import/Export'}
                    </p>
                  </div>
                </div>
                <svg className="w-3 h-3 text-[#003049]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              <AnimatePresence>
                {showImportExportDropdown && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -10 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 top-12 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[200px] z-50"
                  >
                    {/* Import Section */}
                    <div className="px-3 py-2">
                      <div className="text-xs font-medium text-gray-500 mb-2">Import Data</div>
                      <button
                        onClick={handleImportClick}
                        className="w-full text-left px-2 py-1.5 rounded text-sm hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                        </svg>
                        Import from CSV/Excel
                      </button>
                    </div>

                    <div className="border-t border-gray-100 my-2"></div>

                    {/* Export Section */}
                    <div className="px-3 py-2">
                      <div className="text-xs font-medium text-gray-500 mb-2">Export Data</div>
                      <div className="space-y-1">
                        <button
                          onClick={() => handleExportData('csv')}
                          className="w-full text-left px-2 py-1.5 rounded text-sm hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3M3 17V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
                          </svg>
                          Export as CSV
                        </button>
                        <button
                          onClick={() => handleExportData('excel')}
                          className="w-full text-left px-2 py-1.5 rounded text-sm hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                          Export as Excel
                        </button>
                        <button
                          onClick={() => handleExportData('pdf')}
                          className="w-full text-left px-2 py-1.5 rounded text-sm hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m-1-9a9 9 0 110 18 9 9 0 010-18z" />
                          </svg>
                          Export as PDF
                        </button>
                      </div>
                    </div>

                    <div className="border-t border-gray-100 my-2"></div>

                    {/* Bulk Actions Section */}
                    <div className="px-3 py-2">
                      <div className="text-xs font-medium text-gray-500 mb-2">Bulk Actions</div>
                      <div className="space-y-1">
                        <button
                          onClick={handleSendReminders}
                          className="w-full text-left px-2 py-1.5 rounded text-sm hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                          </svg>
                          Send Payment Reminders
                        </button>
                        <button
                          onClick={() => handleBulkUpdate('fee-update')}
                          className="w-full text-left px-2 py-1.5 rounded text-sm hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                          </svg>
                          Update Fee Structures
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* New Customer Button */}
          <button
            onClick={() => setShowNewCustomerModal(true)}
            disabled={isLoading}
            className="bg-[#5dfcaf] box-border content-stretch flex flex-row gap-3 h-10 items-center justify-center px-4 py-2 relative rounded-lg shrink-0 hover:bg-[#4de89a] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Add new customer"
          >
            <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-start p-0 relative shrink-0">
              <VuesaxLinearAddCircle />
            </div>
            <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#003049] text-[12px] text-center text-nowrap">
              <p className="block leading-[1.45] whitespace-pre">
                {isLoading ? 'Adding...' : 'New Customer'}
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv,.xlsx,.xls"
        onChange={handleFileImport}
        className="hidden"
        aria-label="Select file to import"
      />

      {/* New Customer Modal */}
      <AnimatePresence>
        {showNewCustomerModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-[#003049]">Add New Customer</h2>
                  <button
                    onClick={() => setShowNewCustomerModal(false)}
                    className="text-gray-400 hover:text-gray-600 transition-colors"
                    aria-label="Close modal"
                  >
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>

                <form onSubmit={handleNewCustomerSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Student Name */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Student Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={newCustomerData.studentName}
                        onChange={(e) => setNewCustomerData(prev => ({ ...prev, studentName: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent"
                        placeholder="Enter student's full name"
                      />
                    </div>

                    {/* Class */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Class <span className="text-red-500">*</span>
                      </label>
                      <select
                        required
                        value={newCustomerData.class}
                        onChange={(e) => setNewCustomerData(prev => ({ ...prev, class: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent"
                      >
                        <option value="">Select class</option>
                        {classes.map(className => (
                          <option key={className} value={className}>{className}</option>
                        ))}
                      </select>
                    </div>

                    {/* Guardian Name */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Guardian Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={newCustomerData.guardianName}
                        onChange={(e) => setNewCustomerData(prev => ({ ...prev, guardianName: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent"
                        placeholder="Enter guardian's full name"
                      />
                    </div>

                    {/* Guardian Phone */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Guardian Phone
                      </label>
                      <input
                        type="tel"
                        value={newCustomerData.guardianPhone}
                        onChange={(e) => setNewCustomerData(prev => ({ ...prev, guardianPhone: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent"
                        placeholder="+260 XXX XXX XXX"
                      />
                    </div>

                    {/* Guardian Email */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Guardian Email
                      </label>
                      <input
                        type="email"
                        value={newCustomerData.guardianEmail}
                        onChange={(e) => setNewCustomerData(prev => ({ ...prev, guardianEmail: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent"
                        placeholder="guardian@example.com"
                      />
                    </div>

                    {/* Emergency Contact */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Emergency Contact
                      </label>
                      <input
                        type="tel"
                        value={newCustomerData.emergencyContact}
                        onChange={(e) => setNewCustomerData(prev => ({ ...prev, emergencyContact: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent"
                        placeholder="+260 XXX XXX XXX"
                      />
                    </div>
                  </div>

                  {/* Address */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Address
                    </label>
                    <textarea
                      value={newCustomerData.address}
                      onChange={(e) => setNewCustomerData(prev => ({ ...prev, address: e.target.value }))}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent"
                      placeholder="Enter full address"
                    />
                  </div>

                  {/* Fee Structure */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Fee Structure
                    </label>
                    <select
                      value={newCustomerData.feeStructure}
                      onChange={(e) => setNewCustomerData(prev => ({ ...prev, feeStructure: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent"
                    >
                      {feeStructures.map(structure => (
                        <option key={structure} value={structure}>{structure}</option>
                      ))}
                    </select>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200">
                    <button
                      type="button"
                      onClick={() => setShowNewCustomerModal(false)}
                      className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="px-6 py-2 bg-[#003049] text-white rounded-lg hover:bg-[#004060] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      {isLoading && (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      )}
                      {isLoading ? 'Adding Customer...' : 'Add Customer'}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}

// Icon Components (preserved from original)
function VuesaxLinearSearchNormal() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/search-normal"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="search-normal">
          <path
            d={svgPaths.p14d5dec0}
            id="Vector"
            stroke="var(--stroke-0, #9CA0A4)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d={svgPaths.p355f1080}
            id="Vector_2"
            stroke="var(--stroke-0, #9CA0A4)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function SearchNormal1() {
  return (
    <div className="relative shrink-0 size-5" data-name="search-normal">
      <VuesaxLinearSearchNormal />
    </div>
  );
}

function IconUpload2Line() {
  return (
    <div
      className="relative shrink-0 size-[17px]"
      data-name="Icon-upload-2-line"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 17 17"
      >
        <g id="Icon-upload-2-line">
          <path
            d={svgPaths.p1cd74a00}
            fill="var(--fill-0, #003049)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function AddCircle() {
  return (
    <div
      className="[grid-area:1_/_1] ml-0 mt-0 relative size-6"
      data-name="add-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="add-circle">
          <path
            d="M8 12H16"
            id="Vector"
            stroke="var(--stroke-0, #003049)"
            strokeLinecap="square"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <path
            d="M12 16V8"
            id="Vector_2"
            stroke="var(--stroke-0, #003049)"
            strokeLinecap="square"
            strokeLinejoin="round"
            strokeWidth="2"
          />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function VuesaxLinearAddCircle() {
  return (
    <div
      className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0"
      data-name="vuesax/linear/add-circle"
    >
      <AddCircle />
    </div>
  );
}