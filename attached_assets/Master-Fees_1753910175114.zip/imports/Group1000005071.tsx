import { useState } from 'react';
import svgPaths from "./svg-1nszima3at";

function Frame1707478527() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[122px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-left w-full">
        <p className="block leading-[20px]">Customer Name</p>
      </div>
    </div>
  );
}

function Frame1707478528() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[122px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-full">
        <p className="block leading-[20px]">Grade</p>
      </div>
    </div>
  );
}

function Frame1707478517() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[220px] items-center justify-start p-0 relative shrink-0 w-[498px]">
      <Frame1707478527 />
      <Frame1707478528 />
    </div>
  );
}

function Frame1707478518() {
  return (
    <div className="box-border content-stretch flex flex-row font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] gap-[78px] items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#000000] text-[12px] text-center text-nowrap">
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[40px] text-nowrap whitespace-pre">
          Revenue
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[40px] text-nowrap whitespace-pre">
          Collected
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[40px] text-nowrap whitespace-pre">
          Balance
        </p>
      </div>
    </div>
  );
}

function Frame1707478519() {
  return (
    <div className="bg-[#ffffff] h-[37px] mb-[-1px] relative shrink-0 w-full">
      <div className="absolute border border-[#e1e3e3] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[42px] h-[37px] items-center justify-start px-6 py-2 relative w-full">
          <Frame1707478517 />
          <Frame1707478518 />
        </div>
      </div>
    </div>
  );
}

function Frame1707478531() {
  return (
    <div className="bg-[#c0f1e5] box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-2.5 py-0.5 relative rounded-[15px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-end leading-[0] not-italic relative shrink-0 text-[#025864] text-[8px] text-center w-[57px]">
        <p className="block leading-[10px]">Compliant</p>
      </div>
    </div>
  );
}

function Frame1707478532() {
  return (
    <div className="box-border content-stretch flex flex-row gap-6 items-center justify-start p-0 relative shrink-0 w-[195px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Stephen Kapambwe</p>
      </div>
      <Frame1707478531 />
    </div>
  );
}

function Frame1707478533() {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-start p-0 relative shrink-0 w-[498px]">
      <Frame1707478532 />
    </div>
  );
}

function Frame1707478541({ revenue, collected, balance }: { revenue: number; collected: number; balance: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-row font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] gap-[70px] items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#000000] text-[12px] text-center w-[313px]">
      <div className="flex flex-col justify-center relative shrink-0 w-[61px]">
        <p className="block leading-[40px]">{formatCurrency(revenue)}</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 w-[63px]">
        <p className="block leading-[40px]">{formatCurrency(collected)}</p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0 w-[52px]">
        <p className="block leading-[40px]">{formatCurrency(balance)}</p>
      </div>
    </div>
  );
}

function Frame1707478520({ revenue, collected, balance }: { revenue: number; collected: number; balance: number }) {
  return (
    <div className="mb-[-1px] relative shrink-0 w-full">
      <div className="absolute border border-[#e1e3e3] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-9 items-center justify-start px-6 py-1 relative w-full">
          <Frame1707478533 />
          <Frame1707478541 revenue={revenue} collected={collected} balance={balance} />
        </div>
      </div>
    </div>
  );
}

function Frame1707478584({ sampleData }: { sampleData: Array<{revenue: number; collected: number; balance: number}> }) {
  return (
    <div className="absolute bg-[#f5f7f9] h-[567px] left-0 rounded-[5px] top-[42px] w-[1112px]">
      <div className="box-border content-stretch flex flex-col h-[567px] items-start justify-start overflow-clip pb-px pt-0 px-0 relative w-[1112px]">
        <Frame1707478519 />
        {sampleData.map((data, i) => (
          <Frame1707478520 
            key={i} 
            revenue={data.revenue} 
            collected={data.collected} 
            balance={data.balance} 
          />
        ))}
      </div>
      <div className="absolute border border-[#e1e3e3] border-solid inset-0 pointer-events-none rounded-[5px]" />
    </div>
  );
}

function Frame1707478540() {
  return (
    <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-1 relative rounded-[50px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333333] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">All</p>
      </div>
    </div>
  );
}

function Frame1707478534() {
  return (
    <div className="bg-[#f5f4f6] box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-1 relative rounded-[50px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333333] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Baby Class</p>
      </div>
    </div>
  );
}

function Frame1707478535() {
  return (
    <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-1 relative rounded-[50px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333333] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Reception</p>
      </div>
    </div>
  );
}

function Frame1707478536() {
  return (
    <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-1 relative rounded-[50px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333333] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Grade 1A</p>
      </div>
    </div>
  );
}

function Frame1707478537() {
  return (
    <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-1 relative rounded-[50px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333333] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Grade 1B</p>
      </div>
    </div>
  );
}

function Frame1707478538() {
  return (
    <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-1 relative rounded-[50px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333333] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Grade 2A</p>
      </div>
    </div>
  );
}

function Frame1707478539() {
  return (
    <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-1 relative rounded-[50px] shrink-0">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#333333] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Grade 2B</p>
      </div>
    </div>
  );
}

function FilterBar({ 
  activeFilter, 
  onFilterChange, 
  searchTerm, 
  onSearchChange 
}: { 
  activeFilter: string;
  onFilterChange: (filter: string) => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
}) {
  const filters = [
    { id: 'all', label: 'All', component: Frame1707478540 },
    { id: 'baby-class', label: 'Baby Class', component: Frame1707478534 },
    { id: 'reception', label: 'Reception', component: Frame1707478535 },
    { id: 'grade-1a', label: 'Grade 1A', component: Frame1707478536 },
    { id: 'grade-1b', label: 'Grade 1B', component: Frame1707478537 },
    { id: 'grade-2a', label: 'Grade 2A', component: Frame1707478538 },
    { id: 'grade-2b', label: 'Grade 2B', component: Frame1707478539 },
  ];

  return (
    <div className="absolute box-border content-stretch flex flex-row gap-2 items-center justify-start left-0 p-0 top-0">
      {filters.map((filter) => {
        const FilterComponent = filter.component;
        return (
          <button
            key={filter.id}
            onClick={() => onFilterChange(filter.id)}
            className={`transition-colors ${
              activeFilter === filter.id 
                ? 'bg-[#f5f4f6]' 
                : 'hover:bg-gray-100'
            } rounded-[50px]`}
            aria-label={`Filter by ${filter.label}`}
          >
            <FilterComponent />
          </button>
        );
      })}
    </div>
  );
}

function VuesaxLinearSearchNormal() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/search-normal"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="search-normal">
          <path
            d={svgPaths.p14d5dec0}
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d={svgPaths.p355f1080}
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function SearchNormal1() {
  return (
    <div className="relative shrink-0 size-5" data-name="search-normal">
      <VuesaxLinearSearchNormal />
    </div>
  );
}

function VuesaxLinearFilterSquare() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/filter-square"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="filter-square">
          <path
            d={svgPaths.p39e08e80}
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d={svgPaths.p1e16c800}
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function FilterSquare1() {
  return (
    <div className="relative shrink-0 size-5" data-name="filter-square">
      <VuesaxLinearFilterSquare />
    </div>
  );
}

function VuesaxLinearSort() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sort">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="sort">
          <path
            d="M2.5 5.83333H17.5"
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <path
            d="M5 10H15"
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <path
            d="M8.33333 14.1667H11.6667"
            id="Vector_3"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <g id="Vector_4" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function Sort1() {
  return (
    <div className="relative shrink-0 size-5" data-name="sort">
      <VuesaxLinearSort />
    </div>
  );
}

function VuesaxLinearSetting4() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/setting-4"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="setting-4">
          <path
            d="M18.3333 5.41667H13.3333"
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d="M5 5.41667H1.66667"
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d={svgPaths.p4126bf0}
            id="Vector_3"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d="M18.3333 14.5833H15"
            id="Vector_4"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d="M6.66667 14.5833H1.66667"
            id="Vector_5"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d={svgPaths.p14568d00}
            id="Vector_6"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <g id="Vector_7" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function Setting5() {
  return (
    <div className="relative shrink-0 size-5" data-name="setting-4">
      <VuesaxLinearSetting4 />
    </div>
  );
}

function VuesaxLinearPrinter() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/printer"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="printer">
          <path
            d={svgPaths.p1ccebb00}
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d={svgPaths.p23e01370}
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d={svgPaths.p30502a00}
            id="Vector_3"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d={svgPaths.p1caf6660}
            id="Vector_4"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d="M5.83333 9.16667H8.33333"
            id="Vector_5"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d="M19.5 0.5V19.5H0.5V0.5H19.5Z"
            id="Vector_6"
            opacity="0"
            stroke="var(--stroke-0, #333333)"
          />
        </g>
      </svg>
    </div>
  );
}

function Printer1() {
  return (
    <div className="relative shrink-0 size-5" data-name="printer">
      <VuesaxLinearPrinter />
    </div>
  );
}

function Frame1707478586({ onEdit }: { onEdit?: () => void }) {
  return (
    <button
      onClick={onEdit}
      className="bg-[#025864] box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-0.5 relative rounded-md shrink-0 hover:bg-[#003049] transition-colors"
      aria-label="Edit selected records"
    >
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Edit</p>
      </div>
    </button>
  );
}

function ActionBar({ 
  onSearch, 
  onFilter, 
  onSort, 
  onSettings, 
  onPrint, 
  onEdit 
}: {
  onSearch?: () => void;
  onFilter?: () => void;
  onSort?: () => void;
  onSettings?: () => void;
  onPrint?: () => void;
  onEdit?: () => void;
}) {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-3 items-center justify-start left-[895px] p-0 top-1">
      <button onClick={onSearch} className="hover:bg-gray-100 p-1 rounded transition-colors" aria-label="Search customers">
        <SearchNormal1 />
      </button>
      <button onClick={onFilter} className="hover:bg-gray-100 p-1 rounded transition-colors" aria-label="Filter options">
        <FilterSquare1 />
      </button>
      <button onClick={onSort} className="hover:bg-gray-100 p-1 rounded transition-colors" aria-label="Sort options">
        <Sort1 />
      </button>
      <button onClick={onSettings} className="hover:bg-gray-100 p-1 rounded transition-colors" aria-label="View settings">
        <Setting5 />
      </button>
      <button onClick={onPrint} className="hover:bg-gray-100 p-1 rounded transition-colors" aria-label="Print report">
        <Printer1 />
      </button>
      <Frame1707478586 onEdit={onEdit} />
    </div>
  );
}

export default function Group1000005071({ 
  schoolId, 
  selectedTerm, 
  transactions = [], 
  totalRevenue = 0, 
  totalCollected = 0, 
  outstandingBalance = 0, 
  loading = false 
}: { 
  schoolId?: string;
  selectedTerm?: string;
  transactions?: any[];
  totalRevenue?: number;
  totalCollected?: number;
  outstandingBalance?: number;
  loading?: boolean;
}) {
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Generate sample data with proper ZMW amounts
  const sampleData = [
    { revenue: 1500, collected: 1250, balance: 250 },
    { revenue: 2000, collected: 1800, balance: 200 },
    { revenue: 1750, collected: 1500, balance: 250 },
    { revenue: 1200, collected: 1000, balance: 200 },
    { revenue: 1800, collected: 1600, balance: 200 },
    { revenue: 1600, collected: 1400, balance: 200 },
    { revenue: 1400, collected: 1200, balance: 200 },
    { revenue: 1900, collected: 1700, balance: 200 },
    { revenue: 1300, collected: 1100, balance: 200 },
    { revenue: 1700, collected: 1500, balance: 200 },
    { revenue: 1550, collected: 1350, balance: 200 }
  ];

  const handleFilterChange = (filter: string) => {
    setActiveFilter(filter);
    console.log(`Filter changed to: ${filter}`);
  };

  const handleSearchChange = (term: string) => {
    setSearchTerm(term);
    console.log(`Search term: ${term}`);
  };

  const handleSearch = () => {
    console.log('Opening search functionality');
  };

  const handleFilter = () => {
    console.log('Opening advanced filter options');
  };

  const handleSort = () => {
    console.log('Opening sort options');
  };

  const handleSettings = () => {
    console.log('Opening table settings');
  };

  const handlePrint = () => {
    console.log('Generating printable report');
  };

  const handleEdit = () => {
    console.log('Opening bulk edit mode');
  };

  return (
    <div className="relative size-full">
      <Frame1707478584 sampleData={sampleData} />
      <FilterBar 
        activeFilter={activeFilter}
        onFilterChange={handleFilterChange}
        searchTerm={searchTerm}
        onSearchChange={handleSearchChange}
      />
      <ActionBar 
        onSearch={handleSearch}
        onFilter={handleFilter}
        onSort={handleSort}
        onSettings={handleSettings}
        onPrint={handlePrint}
        onEdit={handleEdit}
      />
      
      {loading && (
        <div className="absolute inset-0 bg-white/50 flex items-center justify-center z-10">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#025864] mx-auto mb-2"></div>
            <div className="text-gray-600 text-sm">Loading customer details...</div>
          </div>
        </div>
      )}
    </div>
  );
}