import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from "sonner@2.0.3";
import svgPaths from "./svg-gosb69krsa";

interface TransactionData {
  id: string;
  studentName: string;
  class: string;
  feeType: string;
  amount: number;
  status: 'paid' | 'pending' | 'overdue';
  dueDate: string;
  paymentDate?: string;
  term: string;
  studentId?: string;
  guardianName?: string;
  guardianPhone?: string;
  balance?: number;
}

interface CustomerTableProps {
  customers: TransactionData[];
  totalCustomers: number;
  loading: boolean;
  onCustomerSelect?: (customer: TransactionData) => void;
  onBulkAction?: (action: string, customers: TransactionData[]) => void;
  onViewDetails?: (customerId: string) => void;
  onEditCustomer?: (customer: TransactionData) => void;
  onDeleteCustomer?: (customerId: string) => void;
  onPaymentAction?: (customerId: string, action: 'pay' | 'remind' | 'adjust') => void;
}

export default function Frame1707478602({
  customers = [],
  totalCustomers = 0,
  loading = false,
  onCustomerSelect,
  onBulkAction,
  onViewDetails,
  onEditCustomer,
  onDeleteCustomer,
  onPaymentAction
}: CustomerTableProps) {
  const [selectedCustomers, setSelectedCustomers] = useState<Set<string>>(new Set());
  const [selectAll, setSelectAll] = useState(false);
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);
  const [showBulkActions, setShowBulkActions] = useState(false);

  // Handle select all functionality
  useEffect(() => {
    if (selectAll && customers.length > 0) {
      setSelectedCustomers(new Set(customers.map(c => c.id)));
    } else if (!selectAll) {
      setSelectedCustomers(new Set());
    }
  }, [selectAll, customers]);

  // Update select all state based on individual selections
  useEffect(() => {
    if (customers.length > 0) {
      const allSelected = customers.every(c => selectedCustomers.has(c.id));
      const noneSelected = customers.every(c => !selectedCustomers.has(c.id));
      
      if (allSelected && !selectAll) {
        setSelectAll(true);
      } else if (noneSelected && selectAll) {
        setSelectAll(false);
      }
    }
    
    setShowBulkActions(selectedCustomers.size > 0);
  }, [selectedCustomers, customers, selectAll]);

  const handleSelectAll = () => {
    setSelectAll(!selectAll);
  };

  const handleSelectCustomer = (customerId: string) => {
    const newSelected = new Set(selectedCustomers);
    if (newSelected.has(customerId)) {
      newSelected.delete(customerId);
    } else {
      newSelected.add(customerId);
    }
    setSelectedCustomers(newSelected);
    
    // Notify parent component
    const customer = customers.find(c => c.id === customerId);
    if (customer && onCustomerSelect) {
      onCustomerSelect(customer);
    }
  };

  const handleSort = (column: string) => {
    const newDirection = sortColumn === column && sortDirection === 'asc' ? 'desc' : 'asc';
    setSortColumn(column);
    setSortDirection(newDirection);
    
    toast.info(`Sorted by ${column} (${newDirection === 'asc' ? 'A-Z' : 'Z-A'})`);
  };

  const handleBulkAction = async (action: string) => {
    if (selectedCustomers.size === 0) return;
    
    const selectedCustomerData = customers.filter(c => selectedCustomers.has(c.id));
    
    try {
      await onBulkAction?.(action, selectedCustomerData);
      
      // Clear selections after successful action
      setSelectedCustomers(new Set());
      setSelectAll(false);
      
      toast.success(`${action} completed for ${selectedCustomers.size} customers`);
    } catch (error) {
      toast.error(`Failed to ${action} selected customers`);
    }
  };

  const handleRowClick = (customer: TransactionData) => {
    onViewDetails?.(customer.id);
  };

  const handlePaymentAction = async (customerId: string, action: 'pay' | 'remind' | 'adjust') => {
    try {
      await onPaymentAction?.(customerId, action);
      
      const actionMessages = {
        pay: 'Payment recorded successfully',
        remind: 'Payment reminder sent',
        adjust: 'Balance adjusted successfully'
      };
      
      toast.success(actionMessages[action]);
    } catch (error) {
      toast.error(`Failed to ${action} payment`);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'text-green-600 bg-green-50 border-green-200';
      case 'pending': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'overdue': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
        );
      case 'pending':
        return (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
          </svg>
        );
      case 'overdue':
        return (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
        );
      default:
        return null;
    }
  };

  // Sort customers based on current sort settings
  const sortedCustomers = [...customers].sort((a, b) => {
    if (!sortColumn) return 0;
    
    let aValue: any;
    let bValue: any;
    
    switch (sortColumn) {
      case 'name':
        aValue = a.studentName.toLowerCase();
        bValue = b.studentName.toLowerCase();
        break;
      case 'class':
        aValue = a.class.toLowerCase();
        bValue = b.class.toLowerCase();
        break;
      case 'amount':
        aValue = a.amount;
        bValue = b.amount;
        break;
      case 'status':
        aValue = a.status;
        bValue = b.status;
        break;
      case 'dueDate':
        aValue = new Date(a.dueDate);
        bValue = new Date(b.dueDate);
        break;
      default:
        return 0;
    }
    
    if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  if (loading) {
    return (
      <div className="bg-[#ffffff] relative rounded-md size-full">
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#003049] mx-auto mb-4"></div>
            <div className="text-gray-600 text-sm">Loading customer data...</div>
          </div>
        </div>
        <div className="absolute border border-[#cbd2e0] border-solid inset-0 pointer-events-none rounded-md" />
      </div>
    );
  }

  if (customers.length === 0) {
    return (
      <div className="bg-[#ffffff] relative rounded-md size-full">
        <div className="flex flex-col items-center justify-center h-full p-8">
          <div className="text-center">
            <svg className="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No customers found</h3>
            <p className="text-gray-500 text-sm mb-4">
              {totalCustomers > 0 
                ? "Try adjusting your search filters to see more results."
                : "Start by adding your first customer to the system."
              }
            </p>
            <button
              onClick={() => toast.info("Use the 'New Customer' button above to add customers")}
              className="bg-[#003049] text-white px-4 py-2 rounded-lg hover:bg-[#004060] transition-colors text-sm"
            >
              Add First Customer
            </button>
          </div>
        </div>
        <div className="absolute border border-[#cbd2e0] border-solid inset-0 pointer-events-none rounded-md" />
      </div>
    );
  }

  return (
    <div className="bg-[#ffffff] relative rounded-md size-full">
      <div className="box-border content-stretch flex flex-col items-start justify-start overflow-hidden pb-px pt-0 px-0 relative size-full">
        {/* Bulk Actions Bar */}
        <AnimatePresence>
          {showBulkActions && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="w-full bg-blue-50 border-b border-blue-200 px-6 py-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-sm text-blue-700 font-medium">
                    {selectedCustomers.size} customer{selectedCustomers.size !== 1 ? 's' : ''} selected
                  </span>
                  <button
                    onClick={() => {
                      setSelectedCustomers(new Set());
                      setSelectAll(false);
                    }}
                    className="text-blue-600 hover:text-blue-800 text-sm underline"
                  >
                    Clear selection
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleBulkAction('send-reminders')}
                    className="bg-orange-600 text-white px-3 py-1.5 rounded text-sm hover:bg-orange-700 transition-colors"
                  >
                    Send Reminders
                  </button>
                  <button
                    onClick={() => handleBulkAction('export')}
                    className="bg-green-600 text-white px-3 py-1.5 rounded text-sm hover:bg-green-700 transition-colors"
                  >
                    Export Selected
                  </button>
                  <button
                    onClick={() => handleBulkAction('archive')}
                    className="bg-gray-600 text-white px-3 py-1.5 rounded text-sm hover:bg-gray-700 transition-colors"
                  >
                    Archive
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Table Header */}
        <div className="bg-[#f6f7f9] h-[37px] mb-[-1px] relative shrink-0 w-full border-b border-[#cbd2e0]">
          <div className="flex flex-row items-center relative size-full">
            <div className="box-border content-stretch flex flex-row gap-6 h-[37px] items-center justify-start px-6 py-2 relative w-full">
              {/* Main Header Row */}
              <div className="flex flex-row gap-[50px] items-center justify-start w-full">
                {/* Selection + Student Info */}
                <div className="flex flex-row gap-2.5 items-center justify-start w-[387px]">
                  {/* Select All Checkbox */}
                  <div className="flex flex-row gap-0.5 items-center justify-start w-[105px]">
                    <button
                      onClick={handleSelectAll}
                      className="relative rounded-[3px] shrink-0 size-3 border border-[#b2bbcc] hover:border-[#003049] transition-colors flex items-center justify-center"
                      aria-label="Select all customers"
                    >
                      {selectAll && (
                        <svg className="w-2 h-2 text-[#003049]" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </button>
                    <button
                      onClick={() => handleSort('class')}
                      className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic text-[#b2bbcc] text-[12px] text-center w-[85px] hover:text-[#003049] transition-colors cursor-pointer"
                    >
                      <p className="block leading-[20px] flex items-center justify-center gap-1">
                        Class
                        {sortColumn === 'class' && (
                          <svg className={`w-3 h-3 transition-transform ${sortDirection === 'desc' ? 'rotate-180' : ''}`} fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
                          </svg>
                        )}
                      </p>
                    </button>
                  </div>
                  {/* Student Name */}
                  <button
                    onClick={() => handleSort('name')}
                    className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic text-[#b2bbcc] text-[12px] text-center w-[122px] hover:text-[#003049] transition-colors cursor-pointer"
                  >
                    <p className="block leading-[20px] flex items-center justify-center gap-1">
                      Student Name
                      {sortColumn === 'name' && (
                        <svg className={`w-3 h-3 transition-transform ${sortDirection === 'desc' ? 'rotate-180' : ''}`} fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
                        </svg>
                      )}
                    </p>
                  </button>
                </div>

                {/* Student ID */}
                <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic text-[#b2bbcc] text-[12px] text-center w-[100px]">
                  <p className="block leading-[20px]">Student ID</p>
                </div>

                {/* Amount/Balance */}
                <button
                  onClick={() => handleSort('amount')}
                  className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic text-[#b2bbcc] text-[12px] text-center w-[100px] hover:text-[#003049] transition-colors cursor-pointer"
                >
                  <p className="block leading-[20px] flex items-center justify-center gap-1">
                    Amount Due
                    {sortColumn === 'amount' && (
                      <svg className={`w-3 h-3 transition-transform ${sortDirection === 'desc' ? 'rotate-180' : ''}`} fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
                      </svg>
                    )}
                  </p>
                </button>

                {/* Status */}
                <button
                  onClick={() => handleSort('status')}
                  className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic text-[#b2bbcc] text-[12px] text-center w-[100px] hover:text-[#003049] transition-colors cursor-pointer"
                >
                  <p className="block leading-[20px] flex items-center justify-center gap-1">
                    Status
                    {sortColumn === 'status' && (
                      <svg className={`w-3 h-3 transition-transform ${sortDirection === 'desc' ? 'rotate-180' : ''}`} fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
                      </svg>
                    )}
                  </p>
                </button>

                {/* Actions */}
                <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic text-[#b2bbcc] text-[12px] text-center w-[100px]">
                  <p className="block leading-[20px]">Actions</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Table Rows */}
        <div className="flex-1 overflow-y-auto">
          {sortedCustomers.map((customer, index) => (
            <motion.div
              key={customer.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className={`h-10 mb-[-1px] relative shrink-0 w-full border-b border-[#eff1f5] transition-all hover:bg-gray-50 ${
                selectedCustomers.has(customer.id) ? 'bg-blue-50' : ''
              }`}
              onMouseEnter={() => setHoveredRow(customer.id)}
              onMouseLeave={() => setHoveredRow(null)}
            >
              <div className="flex flex-row items-center relative size-full">
                <div className="box-border content-stretch flex flex-row gap-7 h-10 items-center justify-start pl-6 pr-0 py-2 relative w-full">
                  {/* Main Data Row */}
                  <div className="flex flex-row gap-[50px] items-center justify-start w-full">
                    {/* Selection + Class + Name */}
                    <div className="flex flex-row gap-2.5 items-center justify-start w-[387px]">
                      {/* Checkbox + Class */}
                      <div className="flex flex-row gap-0.5 items-center justify-start w-[105px]">
                        <button
                          onClick={() => handleSelectCustomer(customer.id)}
                          className="relative rounded-[3px] shrink-0 size-3 border border-[#cbd2e0] hover:border-[#003049] transition-colors flex items-center justify-center"
                          aria-label={`Select ${customer.studentName}`}
                        >
                          {selectedCustomers.has(customer.id) && (
                            <svg className="w-2 h-2 text-[#003049]" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                            </svg>
                          )}
                        </button>
                        <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic text-[#000000] text-[12px] text-center w-[89px]">
                          <p className="block leading-[20px] truncate">{customer.class}</p>
                        </div>
                      </div>
                      {/* Student Name */}
                      <button
                        onClick={() => handleRowClick(customer)}
                        className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic text-[#000000] text-[12px] text-left w-[122px] hover:text-[#003049] transition-colors cursor-pointer"
                      >
                        <p className="block leading-[20px] truncate">{customer.studentName}</p>
                      </button>
                    </div>

                    {/* Student ID */}
                    <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic text-[#000000] text-[12px] text-center w-[100px]">
                      <p className="block leading-[20px]">{customer.studentId || customer.id.slice(-8)}</p>
                    </div>

                    {/* Amount Due */}
                    <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic text-[#000000] text-[12px] text-center w-[100px]">
                      <p className={`block leading-[20px] font-medium ${
                        customer.status === 'overdue' ? 'text-red-600' : 
                        customer.status === 'paid' ? 'text-green-600' : 'text-orange-600'
                      }`}>
                        {customer.status === 'paid' ? 'ZMW 0' : formatCurrency(customer.amount)}
                      </p>
                    </div>

                    {/* Status */}
                    <div className="flex flex-col justify-center leading-[0] not-italic text-center w-[100px]">
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] border ${getStatusColor(customer.status)}`}>
                        {getStatusIcon(customer.status)}
                        <span className="capitalize font-medium">{customer.status}</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-center gap-1 w-[100px]">
                      {/* View Details */}
                      <button
                        onClick={() => handleRowClick(customer)}
                        className="p-1.5 text-gray-500 hover:text-[#003049] hover:bg-gray-100 rounded transition-colors"
                        title="View Details"
                        aria-label={`View details for ${customer.studentName}`}
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                      </button>

                      {/* Payment Action */}
                      {customer.status !== 'paid' && (
                        <button
                          onClick={() => handlePaymentAction(customer.id, 'pay')}
                          className="p-1.5 text-green-500 hover:text-green-700 hover:bg-green-50 rounded transition-colors"
                          title="Record Payment"
                          aria-label={`Record payment for ${customer.studentName}`}
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                          </svg>
                        </button>
                      )}

                      {/* Send Reminder */}
                      {customer.status === 'overdue' && (
                        <button
                          onClick={() => handlePaymentAction(customer.id, 'remind')}
                          className="p-1.5 text-orange-500 hover:text-orange-700 hover:bg-orange-50 rounded transition-colors"
                          title="Send Reminder"
                          aria-label={`Send payment reminder to ${customer.studentName}`}
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.449l-6.928-7.05a1 1 0 00-1.424 0l-6.928 7.05C.67 16.333 1.632 18 3.172 18z" />
                          </svg>
                        </button>
                      )}

                      {/* More Actions Menu */}
                      <div className="relative">
                        <button
                          className="p-1.5 text-gray-500 hover:text-[#003049] hover:bg-gray-100 rounded transition-colors"
                          title="More Actions"
                          aria-label={`More actions for ${customer.studentName}`}
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Empty State for Filtered Results */}
        {sortedCustomers.length === 0 && customers.length > 0 && (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center">
              <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No customers match your criteria</h3>
              <p className="text-gray-500 text-sm">Try adjusting your search filters or sorting options.</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="absolute border border-[#cbd2e0] border-solid inset-0 pointer-events-none rounded-md" />
    </div>
  );
}