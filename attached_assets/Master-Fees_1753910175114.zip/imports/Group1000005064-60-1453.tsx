import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import svgPaths from "./svg-gdhkdelkk1";

interface WalletProps {
  balance: number;
  monthlyGrowth: number;
  totalTransactions: number;
  pendingWithdrawals: number;
  onWithdraw?: () => void;
  onViewHistory?: () => void;
  onDownloadStatement?: () => void;
  onWalletSettings?: () => void;
  onTransferFunds?: () => void;
  onViewBalanceDetails?: () => void;
}

function Frame1707478523({ balance }: { balance: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="absolute box-border content-stretch flex flex-col h-[69.641px] items-start justify-start leading-[0] left-[29px] not-italic p-0 text-left top-[81.557px] w-[353px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center relative shrink-0 text-[#5dfcaf] text-[16px] w-full">
        <p className="block leading-[24px]">Cash in wallet</p>
      </div>
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center relative shrink-0 text-[#ffffff] text-[40px] w-full">
        <p className="block leading-[42px]">{formatCurrency(balance)}</p>
      </div>
    </div>
  );
}

function Frame1707478623({ onWithdraw }: { onWithdraw?: () => void }) {
  return (
    <button
      onClick={onWithdraw}
      className="basis-0 bg-[#5dfcaf] grow min-h-px min-w-px relative rounded-[10px] shrink-0 hover:bg-[#4ae399] active:bg-[#3dd089] transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-[#5dfcaf] focus:ring-offset-2 focus:ring-offset-[#025864] disabled:opacity-50 disabled:cursor-not-allowed"
      disabled={!onWithdraw}
      aria-label="Withdraw funds from wallet"
    >
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-[10px] relative w-full">
          <div className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#003049] text-[16px] text-left text-nowrap">
            <p className="block leading-[normal] whitespace-pre">Withdraw</p>
          </div>
        </div>
      </div>
    </button>
  );
}

function VuesaxLinearMoreCircle() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="more-circle">
          <path
            d="M19.9945 12H20.0035"
            id="Vector"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="3"
          />
          <path
            d="M12.9945 12H13.0035"
            id="Vector_2"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="3"
          />
          <path
            d="M5.99451 12H6.00349"
            id="Vector_3"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="3"
          />
          <g id="Vector_4" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle1() {
  return (
    <div className="relative shrink-0 size-6" data-name="more-circle">
      <VuesaxLinearMoreCircle />
    </div>
  );
}

function Frame1707478625({ onViewHistory, onDownloadStatement, onWalletSettings, onTransferFunds, onViewBalanceDetails }: {
  onViewHistory?: () => void;
  onDownloadStatement?: () => void;
  onWalletSettings?: () => void;
  onTransferFunds?: () => void;
  onViewBalanceDetails?: () => void;
}) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleMenuItemClick = (action: (() => void) | undefined, actionName: string) => {
    setIsDropdownOpen(false);
    if (action) {
      action();
    } else {
      console.log(`${actionName} clicked - functionality to be implemented`);
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="bg-[#1b687a] box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative rounded-[9px] shrink-0 size-[43px] hover:bg-[#0f4a5a] active:bg-[#0a3847] transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-[#5dfcaf] focus:ring-offset-2 focus:ring-offset-[#025864]"
        aria-label="Wallet options menu"
        aria-expanded={isDropdownOpen}
        aria-haspopup="true"
      >
        <MoreCircle1 />
      </button>

      <AnimatePresence>
        {isDropdownOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -5 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -5 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="absolute right-0 top-12 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[200px] z-50"
            role="menu"
            aria-orientation="vertical"
          >
            <button
              onClick={() => handleMenuItemClick(onViewHistory, 'View Transaction History')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
              </svg>
              View Transaction History
            </button>

            <button
              onClick={() => handleMenuItemClick(onViewBalanceDetails, 'View Balance Details')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              View Balance Details
            </button>

            <div className="border-t border-gray-100 my-1"></div>

            <button
              onClick={() => handleMenuItemClick(onTransferFunds, 'Transfer Funds')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
              Transfer Funds
            </button>

            <button
              onClick={() => handleMenuItemClick(onDownloadStatement, 'Download Statement')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Download Statement
            </button>

            <div className="border-t border-gray-100 my-1"></div>

            <button
              onClick={() => handleMenuItemClick(onWalletSettings, 'Wallet Settings')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Wallet Settings
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Frame1707478624({ 
  onWithdraw, 
  onViewHistory, 
  onDownloadStatement, 
  onWalletSettings, 
  onTransferFunds, 
  onViewBalanceDetails 
}: { 
  onWithdraw?: () => void;
  onViewHistory?: () => void;
  onDownloadStatement?: () => void;
  onWalletSettings?: () => void;
  onTransferFunds?: () => void;
  onViewBalanceDetails?: () => void;
}) {
  return (
    <div className="absolute box-border content-stretch flex flex-row gap-2.5 h-[46.427px] items-center justify-center left-[899px] p-0 top-[93.164px] w-[162px]">
      <Frame1707478623 onWithdraw={onWithdraw} />
      <Frame1707478625 
        onViewHistory={onViewHistory}
        onDownloadStatement={onDownloadStatement}
        onWalletSettings={onWalletSettings}
        onTransferFunds={onTransferFunds}
        onViewBalanceDetails={onViewBalanceDetails}
      />
    </div>
  );
}

export default function Group1000005064({ 
  balance, 
  monthlyGrowth, 
  totalTransactions, 
  pendingWithdrawals, 
  onWithdraw,
  onViewHistory,
  onDownloadStatement,
  onWalletSettings,
  onTransferFunds,
  onViewBalanceDetails
}: WalletProps) {
  return (
    <div className="relative size-full">
      <div className="absolute bg-[#025864] h-[127.675px] left-0 rounded-[18px] top-[35px] w-[1099px]" />
      <div className="absolute flex h-[128.506px] items-center justify-center left-[440px] top-[76.281px] w-[148.437px]">
        <div className="flex-none rotate-[334.244deg] skew-x-[357.675deg]">
          <div
            className="h-[78.391px] relative w-[130.209px]"
            data-name="path60 (Stroke)"
          >
            <div className="absolute bottom-[-0.957%] left-[-0.576%] right-[-0.576%] top-[-0.957%]">
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 132 81"
              >
                <path
                  d={svgPaths.p77cda00}
                  id="path60 (Stroke)"
                  stroke="var(--stroke-0, #CCFAFF)"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeOpacity="0.07"
                  strokeWidth="1.5"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[80.67px] items-center justify-center left-[338px] top-[57.288px] w-[125.439px]">
        <div className="flex-none rotate-[170.728deg] skew-x-[359.07deg]">
          <div
            className="h-[62.341px] relative w-[117.947px]"
            data-name="path60"
          >
            <div className="absolute bottom-[-28.071%] left-[-14.837%] right-[-14.837%] top-[-28.071%]">
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 154 98"
              >
                <path
                  d={svgPaths.pd6e1900}
                  id="path60"
                  stroke="var(--stroke-0, #B2CCFF)"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeOpacity="0.05"
                  strokeWidth="35"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[117.876px] items-center justify-center left-[525.479px] top-0 w-[145.983px]">
        <div className="flex-none rotate-[160.725deg] skew-x-[358.163deg]">
          <div
            className="h-[78.691px] relative w-[129.672px]"
            data-name="path60 (Stroke)"
          >
            <div className="absolute bottom-[-0.953%] left-[-0.578%] right-[-0.578%] top-[-0.953%]">
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 132 81"
              >
                <path
                  d={svgPaths.p3d7ecd00}
                  id="path60 (Stroke)"
                  stroke="var(--stroke-0, #CCFAFF)"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeOpacity="0.07"
                  strokeWidth="1.5"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[116.294px] items-center justify-center left-[681.5px] top-[42.088px] w-[135.232px]">
        <div className="flex-none rotate-[336.334deg] scale-y-[-100%] skew-x-[2.178deg]">
          <div
            className="h-[74.063px] relative w-[118.044px]"
            data-name="path60"
          >
            <div className="absolute bottom-[-23.628%] left-[-14.825%] right-[-14.825%] top-[-23.628%]">
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 154 110"
              >
                <path
                  d={svgPaths.pec53f80}
                  id="path60"
                  stroke="var(--stroke-0, #B2CCFF)"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeOpacity="0.14"
                  strokeWidth="35"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame1707478523 balance={balance} />
      <Frame1707478624 
        onWithdraw={onWithdraw}
        onViewHistory={onViewHistory}
        onDownloadStatement={onDownloadStatement}
        onWalletSettings={onWalletSettings}
        onTransferFunds={onTransferFunds}
        onViewBalanceDetails={onViewBalanceDetails}
      />
    </div>
  );
}