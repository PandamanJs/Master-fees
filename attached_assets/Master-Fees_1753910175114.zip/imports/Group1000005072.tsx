function Frame1707478520() {
  return (
    <div className="box-border content-stretch flex flex-row font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] gap-[77px] items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#707479] text-[12px] text-center text-nowrap">
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Revenue
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Collected
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[24px] text-nowrap whitespace-pre">
          Balance
        </p>
      </div>
    </div>
  );
}

function Frame1707478521() {
  return (
    <div className="absolute box-border content-stretch flex flex-row items-center justify-between left-[39.072px] p-0 top-[30px] w-[884.928px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#707479] text-[12px] text-center text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Service Category</p>
      </div>
      <Frame1707478520 />
    </div>
  );
}

export default function Group1000005072() {
  return (
    <div className="relative size-full bg-[#f8f8f8] outline-none border-none">
      <Frame1707478521 />
      <div className="absolute font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] leading-[0] left-0 not-italic text-[#000000] text-[12px] text-left top-0 w-[221.76px]">
        <p className="block leading-[normal]">{`Product & Service Revenue Summary`}</p>
      </div>
    </div>
  );
}