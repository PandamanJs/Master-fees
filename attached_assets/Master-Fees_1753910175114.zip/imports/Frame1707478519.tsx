function Frame1707478527() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[122px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-left w-full">
        <p className="block leading-[20px]">Student Name</p>
      </div>
    </div>
  );
}

function Frame1707478528() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[122px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-full">
        <p className="block leading-[20px]">Grade</p>
      </div>
    </div>
  );
}

function Frame1707478517() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[220px] items-center justify-start p-0 relative shrink-0 w-[498px]">
      <Frame1707478527 />
      <Frame1707478528 />
    </div>
  );
}

function Frame1707478518() {
  return (
    <div className="box-border content-stretch flex flex-row font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] gap-[78px] items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-[#000000] text-[12px] text-center text-nowrap">
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[40px] text-nowrap whitespace-pre">
          Revenue
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[40px] text-nowrap whitespace-pre">
          Collected
        </p>
      </div>
      <div className="flex flex-col justify-center relative shrink-0">
        <p className="block leading-[40px] text-nowrap whitespace-pre">
          Balance
        </p>
      </div>
    </div>
  );
}

export default function Frame1707478519() {
  return (
    <div className="bg-[#ffffff] relative size-full">
      <div className="absolute border border-[#e1e3e3] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[42px] items-center justify-start px-6 py-2 relative size-full">
          <Frame1707478517 />
          <Frame1707478518 />
        </div>
      </div>
    </div>
  );
}