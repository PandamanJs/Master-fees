import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from "sonner@2.0.3";
import svgPaths from "./svg-kl17dbyo1a";

interface FilterProps {
  onSearchChange: (query: string) => void;
  onClassFilter: (className: string | null) => void;
  onStatusFilter: (status: string | null) => void;
  onDateRangeFilter: (range: string | null) => void;
  onSortChange: (column: string, direction: 'asc' | 'desc') => void;
  onClearFilters: () => void;
  totalResults: number;
  filteredResults: number;
}

export default function Frame1707478670({
  onSearchChange,
  onClassFilter,
  onStatusFilter,
  onDateRangeFilter,
  onSortChange,
  onClearFilters,
  totalResults = 0,
  filteredResults = 0
}: FilterProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
  const [selectedDateRange, setSelectedDateRange] = useState<string | null>(null);
  const [selectedSort, setSelectedSort] = useState<{ column: string; direction: 'asc' | 'desc' } | null>(null);
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);
  const [showSortDropdown, setShowSortDropdown] = useState(false);

  const filterDropdownRef = useRef<HTMLDivElement>(null);
  const sortDropdownRef = useRef<HTMLDivElement>(null);

  const classOptions = [
    'All',
    'Baby Class',
    'Reception',
    'Grade 1A',
    'Grade 1B',
    'Grade 2A',
    'Grade 2B',
    'Grade 3A',
    'Grade 3B',
    'Grade 4A',
    'Grade 4B',
    'Grade 5A',
    'Grade 5B'
  ];

  const statusOptions = [
    { label: 'All Statuses', value: null },
    { label: 'Paid', value: 'paid' },
    { label: 'Pending', value: 'pending' },
    { label: 'Overdue', value: 'overdue' }
  ];

  const dateRangeOptions = [
    { label: 'All Time', value: null },
    { label: 'This Week', value: 'week' },
    { label: 'This Month', value: 'month' },
    { label: 'Last 3 Months', value: '3months' },
    { label: 'This Year', value: 'year' }
  ];

  const sortOptions = [
    { label: 'Customer Name A-Z', column: 'name', direction: 'asc' as const },
    { label: 'Customer Name Z-A', column: 'name', direction: 'desc' as const },
    { label: 'Amount (Low to High)', column: 'amount', direction: 'asc' as const },
    { label: 'Amount (High to Low)', column: 'amount', direction: 'desc' as const },
    { label: 'Due Date (Newest)', column: 'dueDate', direction: 'desc' as const },
    { label: 'Due Date (Oldest)', column: 'dueDate', direction: 'asc' as const },
    { label: 'Class A-Z', column: 'class', direction: 'asc' as const },
    { label: 'Class Z-A', column: 'class', direction: 'desc' as const }
  ];

  // Handle clicks outside dropdowns
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (filterDropdownRef.current && !filterDropdownRef.current.contains(event.target as Node)) {
        setShowFilterDropdown(false);
      }
      if (sortDropdownRef.current && !sortDropdownRef.current.contains(event.target as Node)) {
        setShowSortDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    onSearchChange(value);
  };

  const handleClassClick = (className: string) => {
    const newClass = className === 'All' ? null : className;
    setSelectedClass(newClass);
    onClassFilter(newClass);
    if (newClass) {
      toast.info(`Filtering by class: ${className}`);
    }
  };

  const handleStatusFilter = (status: string | null) => {
    setSelectedStatus(status);
    onStatusFilter(status);
    setShowFilterDropdown(false);
    if (status) {
      toast.info(`Filtering by status: ${status}`);
    }
  };

  const handleDateRangeFilter = (range: string | null) => {
    setSelectedDateRange(range);
    onDateRangeFilter(range);
    setShowFilterDropdown(false);
    if (range) {
      const rangeLabel = dateRangeOptions.find(opt => opt.value === range)?.label;
      toast.info(`Filtering by date range: ${rangeLabel}`);
    }
  };

  const handleSortChange = (column: string, direction: 'asc' | 'desc') => {
    setSelectedSort({ column, direction });
    onSortChange(column, direction);
    setShowSortDropdown(false);
    const sortLabel = sortOptions.find(opt => opt.column === column && opt.direction === direction)?.label;
    toast.info(`Sorting by: ${sortLabel}`);
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedClass(null);
    setSelectedStatus(null);
    setSelectedDateRange(null);
    setSelectedSort(null);
    onClearFilters();
    toast.success('All filters cleared');
  };

  const hasActiveFilters = searchQuery || selectedClass || selectedStatus || selectedDateRange || selectedSort;

  const ClassFilterButton = ({ className }: { className: string }) => {
    const isSelected = selectedClass === className || (className === 'All' && !selectedClass);
    
    return (
      <button
        onClick={() => handleClassClick(className)}
        className={`box-border content-stretch flex flex-row gap-2.5 items-center justify-center px-4 py-1 relative rounded-[50px] shrink-0 transition-all duration-200 ${
          isSelected 
            ? 'bg-[#003049] shadow-md' 
            : 'bg-white border border-gray-200 hover:border-[#003049] hover:bg-gray-50'
        }`}
        aria-label={`Filter by ${className}`}
      >
        <div className={`flex flex-col font-['IBM_Plex_Sans_Devanagari:${isSelected ? 'SemiBold' : 'Medium'}',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-center text-nowrap ${
          isSelected ? 'text-white' : 'text-[#9ca0a4]'
        }`}>
          <p className="block leading-[24px] whitespace-pre">{className}</p>
        </div>
        {isSelected && className !== 'All' && (
          <svg className="w-3 h-3 text-white ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        )}
      </button>
    );
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-4 p-0 relative w-full">
      {/* Main Filter Row */}
      <div className="flex flex-row items-center justify-between w-full">
        {/* Class Filters */}
        <div className="flex flex-row gap-2 items-center justify-start shrink-0 max-w-[70%] overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
          {classOptions.slice(0, 7).map((className) => (
            <ClassFilterButton key={className} className={className} />
          ))}
        </div>

        {/* Search and Action Controls */}
        <div className="flex flex-row gap-3 items-center justify-end shrink-0">
          {/* Search Input */}
          <div className="relative">
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
              <SearchNormal1 />
            </div>
            <input
              type="text"
              placeholder="Search customers..."
              value={searchQuery}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#003049] focus:border-transparent w-64"
              aria-label="Search customers by name, class, or fee type"
            />
            {searchQuery && (
              <button
                onClick={() => handleSearchChange('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                aria-label="Clear search"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>

          {/* Filter Dropdown */}
          <div className="relative" ref={filterDropdownRef}>
            <button
              onClick={() => setShowFilterDropdown(!showFilterDropdown)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
                selectedStatus || selectedDateRange
                  ? 'bg-[#003049] text-white border-[#003049]'
                  : 'bg-white text-gray-700 border-gray-200 hover:border-[#003049] hover:bg-gray-50'
              }`}
              aria-label="Open filter options"
              aria-expanded={showFilterDropdown}
            >
              <FilterSquare1 />
              <span className="text-sm">Filter</span>
              {(selectedStatus || selectedDateRange) && (
                <span className="bg-white text-[#003049] px-1.5 py-0.5 rounded-full text-xs font-medium">
                  {(selectedStatus ? 1 : 0) + (selectedDateRange ? 1 : 0)}
                </span>
              )}
            </button>

            <AnimatePresence>
              {showFilterDropdown && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 top-12 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[200px] z-50"
                >
                  {/* Status Filters */}
                  <div className="px-3 py-2">
                    <div className="text-xs font-medium text-gray-500 mb-2">Payment Status</div>
                    <div className="space-y-1">
                      {statusOptions.map((option) => (
                        <button
                          key={option.label}
                          onClick={() => handleStatusFilter(option.value)}
                          className={`w-full text-left px-2 py-1.5 rounded text-sm transition-colors ${
                            selectedStatus === option.value
                              ? 'bg-[#003049] text-white'
                              : 'hover:bg-gray-50 text-gray-700'
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="border-t border-gray-100 my-2"></div>

                  {/* Date Range Filters */}
                  <div className="px-3 py-2">
                    <div className="text-xs font-medium text-gray-500 mb-2">Date Range</div>
                    <div className="space-y-1">
                      {dateRangeOptions.map((option) => (
                        <button
                          key={option.label}
                          onClick={() => handleDateRangeFilter(option.value)}
                          className={`w-full text-left px-2 py-1.5 rounded text-sm transition-colors ${
                            selectedDateRange === option.value
                              ? 'bg-[#003049] text-white'
                              : 'hover:bg-gray-50 text-gray-700'
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Sort Dropdown */}
          <div className="relative" ref={sortDropdownRef}>
            <button
              onClick={() => setShowSortDropdown(!showSortDropdown)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
                selectedSort
                  ? 'bg-[#003049] text-white border-[#003049]'
                  : 'bg-white text-gray-700 border-gray-200 hover:border-[#003049] hover:bg-gray-50'
              }`}
              aria-label="Sort options"
              aria-expanded={showSortDropdown}
            >
              <Sort1 />
              <span className="text-sm">Sort</span>
              {selectedSort && (
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
                    d={selectedSort.direction === 'asc' ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} 
                  />
                </svg>
              )}
            </button>

            <AnimatePresence>
              {showSortDropdown && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 top-12 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[220px] z-50"
                >
                  <div className="px-3 py-2">
                    <div className="text-xs font-medium text-gray-500 mb-2">Sort Options</div>
                    <div className="space-y-1">
                      {sortOptions.map((option) => (
                        <button
                          key={`${option.column}-${option.direction}`}
                          onClick={() => handleSortChange(option.column, option.direction)}
                          className={`w-full text-left px-2 py-1.5 rounded text-sm transition-colors flex items-center justify-between ${
                            selectedSort?.column === option.column && selectedSort?.direction === option.direction
                              ? 'bg-[#003049] text-white'
                              : 'hover:bg-gray-50 text-gray-700'
                          }`}
                        >
                          <span>{option.label}</span>
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
                              d={option.direction === 'asc' ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} 
                            />
                          </svg>
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Filter Summary Row */}
      {(hasActiveFilters || filteredResults !== totalResults) && (
        <div className="flex items-center justify-between bg-gray-50 px-4 py-2 rounded-lg">
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">
              Showing {filteredResults.toLocaleString()} of {totalResults.toLocaleString()} customers
            </span>
            
            {hasActiveFilters && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">Active filters:</span>
                <div className="flex gap-1">
                  {searchQuery && (
                    <span className="bg-[#003049] text-white px-2 py-1 rounded-full text-xs">
                      Search: "{searchQuery}"
                    </span>
                  )}
                  {selectedClass && (
                    <span className="bg-[#003049] text-white px-2 py-1 rounded-full text-xs">
                      Class: {selectedClass}
                    </span>
                  )}
                  {selectedStatus && (
                    <span className="bg-[#003049] text-white px-2 py-1 rounded-full text-xs">
                      Status: {selectedStatus}
                    </span>
                  )}
                  {selectedDateRange && (
                    <span className="bg-[#003049] text-white px-2 py-1 rounded-full text-xs">
                      Date: {dateRangeOptions.find(opt => opt.value === selectedDateRange)?.label}
                    </span>
                  )}
                  {selectedSort && (
                    <span className="bg-[#003049] text-white px-2 py-1 rounded-full text-xs">
                      Sort: {sortOptions.find(opt => opt.column === selectedSort.column && opt.direction === selectedSort.direction)?.label}
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {hasActiveFilters && (
            <button
              onClick={handleClearFilters}
              className="text-sm text-gray-500 hover:text-[#003049] transition-colors flex items-center gap-1"
              aria-label="Clear all filters"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
              Clear all
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// Icon Components
function VuesaxLinearSearchNormal() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/search-normal"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="search-normal">
          <path
            d={svgPaths.p14d5dec0}
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d={svgPaths.p355f1080}
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function SearchNormal1() {
  return (
    <div className="relative shrink-0 size-5" data-name="search-normal">
      <VuesaxLinearSearchNormal />
    </div>
  );
}

function VuesaxLinearFilterSquare() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/filter-square"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="filter-square">
          <path
            d={svgPaths.p39e08e80}
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d={svgPaths.p1e16c800}
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function FilterSquare1() {
  return (
    <div className="relative shrink-0 size-5" data-name="filter-square">
      <VuesaxLinearFilterSquare />
    </div>
  );
}

function VuesaxLinearSort() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sort">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="sort">
          <path
            d="M2.5 5.83333H17.5"
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <path
            d="M5 10H15"
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <path
            d="M8.33333 14.1667H11.6667"
            id="Vector_3"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <g id="Vector_4" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function Sort1() {
  return (
    <div className="relative shrink-0 size-5" data-name="sort">
      <VuesaxLinearSort />
    </div>
  );
}