import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from "sonner@2.0.3";
import svgPaths from "./svg-oqneq731d1";

interface TransactionData {
  id: string;
  studentName: string;
  class: string;
  feeType: string;
  amount: number;
  status: 'paid' | 'pending' | 'overdue';
  dueDate: string;
  paymentDate?: string;
  term: string;
}

interface WalletTransactionProps {
  transactions: TransactionData[];
  walletBalance: number;
  loading: boolean;
  onViewTransaction: (transactionId: string) => void;
  onExportTransactions?: () => void;
  onFilterTransactions?: (filter: string) => void;
  onSortTransactions?: (sortBy: string, order: 'asc' | 'desc') => void;
}

function Frame1707478528({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  const isActive = sortBy === 'date';
  
  return (
    <button
      onClick={() => onSort && onSort('date')}
      className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px] hover:bg-gray-50 transition-colors rounded-sm group"
      aria-label="Sort by date"
    >
      <div className={`flex items-center gap-1 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-left w-[67px] ${
        isActive ? 'text-[#025864]' : 'text-[#000000] group-hover:text-[#025864]'
      }`}>
        <p className="block leading-[20px]">Date</p>
        {isActive && (
          <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
              d={sortOrder === 'asc' ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} 
            />
          </svg>
        )}
      </div>
    </button>
  );
}

function Frame1707478529() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478531({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  const isActive = sortBy === 'type';
  
  return (
    <button
      onClick={() => onSort && onSort('type')}
      className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px] hover:bg-gray-50 transition-colors rounded-sm group"
      aria-label="Sort by transaction type"
    >
      <div className={`flex items-center gap-1 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-center w-[67px] ${
        isActive ? 'text-[#025864]' : 'text-[#000000] group-hover:text-[#025864]'
      }`}>
        <p className="block leading-[20px]">Txn Type</p>
        {isActive && (
          <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
              d={sortOrder === 'asc' ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} 
            />
          </svg>
        )}
      </div>
    </button>
  );
}

function Frame1707478541({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478528 onSort={onSort} sortBy={sortBy} sortOrder={sortOrder} />
      <Frame1707478529 />
      <Frame1707478531 onSort={onSort} sortBy={sortBy} sortOrder={sortOrder} />
    </div>
  );
}

function Frame1707478530() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478533({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  const isActive = sortBy === 'status';
  
  return (
    <button
      onClick={() => onSort && onSort('status')}
      className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px] hover:bg-gray-50 transition-colors rounded-sm group"
      aria-label="Sort by status"
    >
      <div className={`flex items-center gap-1 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-center w-[67px] ${
        isActive ? 'text-[#025864]' : 'text-[#000000] group-hover:text-[#025864]'
      }`}>
        <p className="block leading-[20px]">Status</p>
        {isActive && (
          <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
              d={sortOrder === 'asc' ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} 
            />
          </svg>
        )}
      </div>
    </button>
  );
}

function Frame1707478532({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  const isActive = sortBy === 'amount';
  
  return (
    <button
      onClick={() => onSort && onSort('amount')}
      className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px] hover:bg-gray-50 transition-colors rounded-sm group"
      aria-label="Sort by amount"
    >
      <div className={`flex items-center gap-1 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-center w-[67px] ${
        isActive ? 'text-[#025864]' : 'text-[#000000] group-hover:text-[#025864]'
      }`}>
        <p className="block leading-[20px]">Amount</p>
        {isActive && (
          <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
              d={sortOrder === 'asc' ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} 
            />
          </svg>
        )}
      </div>
    </button>
  );
}

function Frame1707478534({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  const isActive = sortBy === 'balance';
  
  return (
    <button
      onClick={() => onSort && onSort('balance')}
      className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px] hover:bg-gray-50 transition-colors rounded-sm group"
      aria-label="Sort by balance"
    >
      <div className={`flex items-center gap-1 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-center w-[67px] ${
        isActive ? 'text-[#025864]' : 'text-[#000000] group-hover:text-[#025864]'
      }`}>
        <p className="block leading-[20px]">Balance</p>
        {isActive && (
          <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" 
              d={sortOrder === 'asc' ? "M5 15l7-7 7 7" : "M19 9l-7 7-7-7"} 
            />
          </svg>
        )}
      </div>
    </button>
  );
}

function Frame1707478626({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative shrink-0 w-[284px]">
      <Frame1707478533 onSort={onSort} sortBy={sortBy} sortOrder={sortOrder} />
      <Frame1707478532 onSort={onSort} sortBy={sortBy} sortOrder={sortOrder} />
      <Frame1707478534 onSort={onSort} sortBy={sortBy} sortOrder={sortOrder} />
    </div>
  );
}

function Frame1707478518({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1002px]">
      <Frame1707478541 onSort={onSort} sortBy={sortBy} sortOrder={sortOrder} />
      <Frame1707478530 />
      <Frame1707478626 onSort={onSort} sortBy={sortBy} sortOrder={sortOrder} />
    </div>
  );
}

function Frame1707478519({ onSort, sortBy, sortOrder }: { 
  onSort?: (column: string) => void; 
  sortBy?: string; 
  sortOrder?: 'asc' | 'desc' 
}) {
  return (
    <div className="bg-[#ffffff] h-[37px] mb-[-1px] relative shrink-0 w-full border-b border-gray-200">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[42px] h-[37px] items-center justify-start pl-[30px] pr-6 py-2 relative w-full">
          <Frame1707478518 onSort={onSort} sortBy={sortBy} sortOrder={sortOrder} />
        </div>
      </div>
    </div>
  );
}

function Frame1707478539() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-center justify-center p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0b5e6c] text-[10px] text-center text-nowrap">
        <p className="block leading-[20px] whitespace-pre">July - 2025</p>
      </div>
    </div>
  );
}

function Frame1707478540() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478543() {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478539 />
      {[...Array(2).keys()].map((_, i) => (
        <Frame1707478540 key={i} />
      ))}
    </div>
  );
}

function Frame1707478544() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478545() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478517() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478543 />
      <Frame1707478544 />
      {[...Array(2).keys()].map((_, i) => (
        <Frame1707478545 key={i} />
      ))}
    </div>
  );
}

function VuesaxOutlineMoreCircle() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle1({ transactionId, onAction }: { 
  transactionId?: string; 
  onAction?: (action: string, transactionId?: string) => void 
}) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleActionClick = (action: string) => {
    setIsDropdownOpen(false);
    if (onAction) {
      onAction(action, transactionId);
    } else {
      toast.info(`${action} functionality will be available in the next update`);
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="relative size-5 hover:bg-gray-100 rounded-sm transition-colors p-0.5"
        data-name="more-circle"
        aria-label="Transaction actions menu"
        aria-expanded={isDropdownOpen}
        aria-haspopup="true"
      >
        <VuesaxOutlineMoreCircle />
      </button>

      <AnimatePresence>
        {isDropdownOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -5 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -5 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="absolute right-0 top-6 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[160px] z-50"
            role="menu"
            aria-orientation="vertical"
          >
            <button
              onClick={() => handleActionClick('View Details')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              View Details
            </button>

            <button
              onClick={() => handleActionClick('Download Receipt')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Download Receipt
            </button>

            <div className="border-t border-gray-100 my-1"></div>

            <button
              onClick={() => handleActionClick('Mark as Reviewed')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              Mark as Reviewed
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Frame1707478520({ onAction }: { onAction?: (action: string, transactionId?: string) => void }) {
  return (
    <div className="bg-[#eef6f7] mb-[-1px] relative shrink-0 w-full hover:bg-[#e1f0f1] transition-colors">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478517 />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px]">
            <div className="flex-none">
              <MoreCircle1 transactionId="month_summary_july_2025" onAction={onAction} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1707478547({ date = "28/07/25" }: { date?: string }) {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{date}</p>
      </div>
    </div>
  );
}

function Frame1707478548() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478549({ type = "Income" }: { type?: string }) {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{type}</p>
      </div>
    </div>
  );
}

function Frame1707478550({ date, type }: { date?: string; type?: string }) {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478547 date={date} />
      <Frame1707478548 />
      <Frame1707478549 type={type} />
    </div>
  );
}

function Frame1707478551() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478552({ status = "Cleared" }: { status?: string }) {
  const statusColor = {
    'Cleared': 'text-green-600',
    'Pending': 'text-yellow-600',
    'Failed': 'text-red-600',
    'Processing': 'text-blue-600'
  }[status] || 'text-[#000000]';

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className={`flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-center w-[67px] ${statusColor}`}>
        <p className="block leading-[20px]">{status}</p>
      </div>
    </div>
  );
}

function Frame1707478553({ amount }: { amount: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{formatCurrency(amount)}</p>
      </div>
    </div>
  );
}

function Frame1707478554({ balance }: { balance: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{formatCurrency(balance)}</p>
      </div>
    </div>
  );
}

function Frame1707478627({ amount, balance, status }: { amount: number; balance: number; status?: string }) {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative shrink-0 w-[284px]">
      <Frame1707478552 status={status} />
      <Frame1707478553 amount={amount} />
      <Frame1707478554 balance={balance} />
    </div>
  );
}

function Frame1707478555({ 
  amount, 
  balance, 
  date = "28/07/25", 
  type = "Income", 
  status = "Cleared" 
}: { 
  amount: number; 
  balance: number;
  date?: string;
  type?: string;
  status?: string;
}) {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478550 date={date} type={type} />
      <Frame1707478551 />
      <Frame1707478627 amount={amount} balance={balance} status={status} />
    </div>
  );
}

function VuesaxOutlineMoreCircle1() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle3({ transactionId, onAction }: { 
  transactionId?: string; 
  onAction?: (action: string, transactionId?: string) => void 
}) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleActionClick = (action: string) => {
    setIsDropdownOpen(false);
    if (onAction) {
      onAction(action, transactionId);
    } else {
      toast.info(`${action} functionality will be available in the next update`);
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="relative size-5 hover:bg-gray-200 rounded-sm transition-colors p-0.5"
        data-name="more-circle"
        aria-label="Transaction actions menu"
        aria-expanded={isDropdownOpen}
        aria-haspopup="true"
      >
        <VuesaxOutlineMoreCircle1 />
      </button>

      <AnimatePresence>
        {isDropdownOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -5 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -5 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="absolute right-0 top-6 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[160px] z-50"
            role="menu"
            aria-orientation="vertical"
          >
            <button
              onClick={() => handleActionClick('View Details')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              View Details
            </button>

            <button
              onClick={() => handleActionClick('Download Receipt')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Download Receipt
            </button>

            <div className="border-t border-gray-100 my-1"></div>

            <button
              onClick={() => handleActionClick('Flag Transaction')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 2h7a2 2 0 012 2v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
              </svg>
              Flag Transaction
            </button>

            <button
              onClick={() => handleActionClick('Export Transaction')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Export Transaction
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Frame1707478521({ 
  mockTransactions, 
  index, 
  onRowClick, 
  onAction 
}: { 
  mockTransactions: any[]; 
  index: number;
  onRowClick?: (transactionId: string) => void;
  onAction?: (action: string, transactionId?: string) => void;
}) {
  const transaction = mockTransactions[index] || { 
    id: `transaction_${index}_${Date.now()}`,
    amount: 1500 + (index * 250), 
    balance: 5000 + (index * 1500),
    date: `2025-07-${28 - index}`,
    type: 'Income',
    status: 'Cleared'
  };
  
  return (
    <button
      onClick={() => onRowClick && onRowClick(transaction.id)}
      className="mb-[-1px] relative shrink-0 w-full hover:bg-gray-50 transition-colors cursor-pointer group"
      aria-label={`View transaction details for ${transaction.date}`}
    >
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478555 
            amount={transaction.amount} 
            balance={transaction.balance}
            date={transaction.date}
            type={transaction.type}
            status={transaction.status}
          />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px] opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="flex-none" onClick={(e) => e.stopPropagation()}>
              <MoreCircle3 transactionId={transaction.id} onAction={onAction} />
            </div>
          </div>
        </div>
      </div>
    </button>
  );
}

function Frame1707478556({ date = "27/07/25" }: { date?: string }) {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{date}</p>
      </div>
    </div>
  );
}

function Frame1707478557() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478558({ type = "Income" }: { type?: string }) {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{type}</p>
      </div>
    </div>
  );
}

function Frame1707478559({ date, type }: { date?: string; type?: string }) {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478556 date={date} />
      <Frame1707478557 />
      <Frame1707478558 type={type} />
    </div>
  );
}

function Frame1707478560() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478561({ status = "Cleared" }: { status?: string }) {
  const statusColor = {
    'Cleared': 'text-green-600',
    'Pending': 'text-yellow-600',
    'Failed': 'text-red-600',
    'Processing': 'text-blue-600'
  }[status] || 'text-[#000000]';

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className={`flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-center w-[67px] ${statusColor}`}>
        <p className="block leading-[20px]">{status}</p>
      </div>
    </div>
  );
}

function Frame1707478562({ amount }: { amount: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{formatCurrency(amount)}</p>
      </div>
    </div>
  );
}

function Frame1707478563({ balance }: { balance: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{formatCurrency(balance)}</p>
      </div>
    </div>
  );
}

function Frame1707478628({ amount, balance, status }: { amount: number; balance: number; status?: string }) {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative shrink-0 w-[284px]">
      <Frame1707478561 status={status} />
      <Frame1707478562 amount={amount} />
      <Frame1707478563 balance={balance} />
    </div>
  );
}

function Frame1707478564({ 
  amount, 
  balance, 
  date = "27/07/25", 
  type = "Income", 
  status = "Cleared" 
}: { 
  amount: number; 
  balance: number;
  date?: string;
  type?: string;
  status?: string;
}) {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478559 date={date} type={type} />
      <Frame1707478560 />
      <Frame1707478628 amount={amount} balance={balance} status={status} />
    </div>
  );
}

function VuesaxOutlineMoreCircle2() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle5({ transactionId, onAction }: { 
  transactionId?: string; 
  onAction?: (action: string, transactionId?: string) => void 
}) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleActionClick = (action: string) => {
    setIsDropdownOpen(false);
    if (onAction) {
      onAction(action, transactionId);
    } else {
      toast.info(`${action} functionality will be available in the next update`);
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="relative size-5 hover:bg-gray-200 rounded-sm transition-colors p-0.5"
        data-name="more-circle"
        aria-label="Transaction actions menu"
        aria-expanded={isDropdownOpen}
        aria-haspopup="true"
      >
        <VuesaxOutlineMoreCircle2 />
      </button>

      <AnimatePresence>
        {isDropdownOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -5 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -5 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="absolute right-0 top-6 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[160px] z-50"
            role="menu"
            aria-orientation="vertical"
          >
            <button
              onClick={() => handleActionClick('View Details')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              View Details
            </button>

            <button
              onClick={() => handleActionClick('Download Receipt')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Download Receipt
            </button>

            <div className="border-t border-gray-100 my-1"></div>

            <button
              onClick={() => handleActionClick('Flag Transaction')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 2h7a2 2 0 012 2v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
              </svg>
              Flag Transaction
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Frame1707478522({ 
  mockTransactions, 
  index, 
  onRowClick, 
  onAction 
}: { 
  mockTransactions: any[]; 
  index: number;
  onRowClick?: (transactionId: string) => void;
  onAction?: (action: string, transactionId?: string) => void;
}) {
  const transaction = mockTransactions[index] || { 
    id: `transaction_${index + 1}_${Date.now()}`,
    amount: 1250 + (index * 300), 
    balance: 4500 + (index * 1200),
    date: `2025-07-${27 - index}`,
    type: 'Income',
    status: 'Cleared'
  };
  
  return (
    <button
      onClick={() => onRowClick && onRowClick(transaction.id)}
      className="mb-[-1px] relative shrink-0 w-full hover:bg-gray-50 transition-colors cursor-pointer group"
      aria-label={`View transaction details for ${transaction.date}`}
    >
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478564 
            amount={transaction.amount} 
            balance={transaction.balance}
            date={transaction.date}
            type={transaction.type}
            status={transaction.status}
          />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px] opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="flex-none" onClick={(e) => e.stopPropagation()}>
              <MoreCircle5 transactionId={transaction.id} onAction={onAction} />
            </div>
          </div>
        </div>
      </div>
    </button>
  );
}

function Frame1707478565({ date = "26/07/25" }: { date?: string }) {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{date}</p>
      </div>
    </div>
  );
}

function Frame1707478566() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478567({ type = "Income" }: { type?: string }) {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{type}</p>
      </div>
    </div>
  );
}

function Frame1707478568({ date, type }: { date?: string; type?: string }) {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478565 date={date} />
      <Frame1707478566 />
      <Frame1707478567 type={type} />
    </div>
  );
}

function Frame1707478569() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478570({ status = "Cleared" }: { status?: string }) {
  const statusColor = {
    'Cleared': 'text-green-600',
    'Pending': 'text-yellow-600',
    'Failed': 'text-red-600',
    'Processing': 'text-blue-600'
  }[status] || 'text-[#000000]';

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className={`flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-center w-[67px] ${statusColor}`}>
        <p className="block leading-[20px]">{status}</p>
      </div>
    </div>
  );
}

function Frame1707478571({ amount }: { amount: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{formatCurrency(amount)}</p>
      </div>
    </div>
  );
}

function Frame1707478572({ balance }: { balance: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{formatCurrency(balance)}</p>
      </div>
    </div>
  );
}

function Frame1707478629({ amount, balance, status }: { amount: number; balance: number; status?: string }) {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative shrink-0 w-[284px]">
      <Frame1707478570 status={status} />
      <Frame1707478571 amount={amount} />
      <Frame1707478572 balance={balance} />
    </div>
  );
}

function Frame1707478573({ 
  amount, 
  balance, 
  date = "26/07/25", 
  type = "Income", 
  status = "Cleared" 
}: { 
  amount: number; 
  balance: number;
  date?: string;
  type?: string;
  status?: string;
}) {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478568 date={date} type={type} />
      <Frame1707478569 />
      <Frame1707478629 amount={amount} balance={balance} status={status} />
    </div>
  );
}

function VuesaxOutlineMoreCircle3() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle7({ transactionId, onAction }: { 
  transactionId?: string; 
  onAction?: (action: string, transactionId?: string) => void 
}) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleActionClick = (action: string) => {
    setIsDropdownOpen(false);
    if (onAction) {
      onAction(action, transactionId);
    } else {
      toast.info(`${action} functionality will be available in the next update`);
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="relative size-5 hover:bg-gray-200 rounded-sm transition-colors p-0.5"
        data-name="more-circle"
        aria-label="Transaction actions menu"
        aria-expanded={isDropdownOpen}
        aria-haspopup="true"
      >
        <VuesaxOutlineMoreCircle3 />
      </button>

      <AnimatePresence>
        {isDropdownOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -5 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -5 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="absolute right-0 top-6 bg-white rounded-lg shadow-lg border border-gray-200 py-2 min-w-[160px] z-50"
            role="menu"
            aria-orientation="vertical"
          >
            <button
              onClick={() => handleActionClick('View Details')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 616 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              View Details
            </button>

            <button
              onClick={() => handleActionClick('Download Receipt')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Download Receipt
            </button>

            <div className="border-t border-gray-100 my-1"></div>

            <button
              onClick={() => handleActionClick('Export Transaction')}
              className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors"
              role="menuitem"
            >
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Export Transaction
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Frame1707478523({ 
  mockTransactions, 
  index, 
  onRowClick, 
  onAction 
}: { 
  mockTransactions: any[]; 
  index: number;
  onRowClick?: (transactionId: string) => void;
  onAction?: (action: string, transactionId?: string) => void;
}) {
  const transaction = mockTransactions[index] || { 
    id: `transaction_${index + 2}_${Date.now()}`,
    amount: 1000 + (index * 400), 
    balance: 3500 + (index * 900),
    date: `2025-07-${26 - index}`,
    type: 'Income',
    status: 'Cleared'
  };
  
  return (
    <button
      onClick={() => onRowClick && onRowClick(transaction.id)}
      className="mb-[-1px] relative shrink-0 w-full hover:bg-gray-50 transition-colors cursor-pointer group"
      aria-label={`View transaction details for ${transaction.date}`}
    >
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478573 
            amount={transaction.amount} 
            balance={transaction.balance}
            date={transaction.date}
            type={transaction.type}
            status={transaction.status}
          />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px] opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="flex-none" onClick={(e) => e.stopPropagation()}>
              <MoreCircle7 transactionId={transaction.id} onAction={onAction} />
            </div>
          </div>
        </div>
      </div>
    </button>
  );
}

function Frame1707478574() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">25/07/25</p>
      </div>
    </div>
  );
}

function Frame1707478575() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478576() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">Income</p>
      </div>
    </div>
  );
}

function Frame1707478577() {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478574 />
      <Frame1707478575 />
      <Frame1707478576 />
    </div>
  );
}

function Frame1707478578() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478579() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">Cleared</p>
      </div>
    </div>
  );
}

function Frame1707478580({ amount }: { amount: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{formatCurrency(amount)}</p>
      </div>
    </div>
  );
}

function Frame1707478581({ balance }: { balance: number }) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">{formatCurrency(balance)}</p>
      </div>
    </div>
  );
}

function Frame1707478630({ amount, balance }: { amount: number; balance: number }) {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative shrink-0 w-[284px]">
      <Frame1707478579 />
      <Frame1707478580 amount={amount} />
      <Frame1707478581 balance={balance} />
    </div>
  );
}

function Frame1707478582({ amount, balance }: { amount: number; balance: number }) {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478577 />
      <Frame1707478578 />
      <Frame1707478630 amount={amount} balance={balance} />
    </div>
  );
}

function VuesaxOutlineMoreCircle4() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle9() {
  return (
    <div className="relative size-5" data-name="more-circle">
      <VuesaxOutlineMoreCircle4 />
    </div>
  );
}

function Frame1707478524({ 
  mockTransactions, 
  index, 
  onRowClick, 
  onAction 
}: { 
  mockTransactions: any[]; 
  index: number;
  onRowClick?: (transactionId: string) => void;
  onAction?: (action: string, transactionId?: string) => void;
}) {
  const transaction = mockTransactions[index] || { 
    id: `transaction_${index + 3}_${Date.now()}`,
    amount: 800 + (index * 500), 
    balance: 2800 + (index * 600),
    date: `2025-07-${25 - index}`,
    type: 'Income',
    status: 'Cleared'
  };
  
  return (
    <button
      onClick={() => onRowClick && onRowClick(transaction.id)}
      className="mb-[-1px] relative shrink-0 w-full hover:bg-gray-50 transition-colors cursor-pointer group"
      aria-label={`View transaction details for ${transaction.date}`}
    >
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478582 
            amount={transaction.amount} 
            balance={transaction.balance}
            date={transaction.date}
            type={transaction.type}
            status={transaction.status}
          />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px] opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="flex-none" onClick={(e) => e.stopPropagation()}>
              <MoreCircle9 transactionId={transaction.id} onAction={onAction} />
            </div>
          </div>
        </div>
      </div>
    </button>
  );
}

function Frame1707478583() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">23/07/25</p>
      </div>
    </div>
  );
}

function Frame1707478584() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478585() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">Income</p>
      </div>
    </div>
  );
}

function Frame1707478586() {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478583 />
      <Frame1707478584 />
      <Frame1707478585 />
    </div>
  );
}

function Frame1707478587() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478588() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">Cleared</p>
      </div>
    </div>
  );
}

function Frame1707478589() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">K5,000</p>
      </div>
    </div>
  );
}

function Frame1707478590() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">K1,497,000</p>
      </div>
    </div>
  );
}

function Frame1707478631() {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative shrink-0 w-[284px]">
      <Frame1707478588 />
      <Frame1707478589 />
      <Frame1707478590 />
    </div>
  );
}

function Frame1707478591() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478586 />
      <Frame1707478587 />
      <Frame1707478631 />
    </div>
  );
}

function VuesaxOutlineMoreCircle5() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle11() {
  return (
    <div className="relative size-5" data-name="more-circle">
      <VuesaxOutlineMoreCircle5 />
    </div>
  );
}

function Frame1707478525() {
  return (
    <div className="mb-[-1px] relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478591 />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px]">
            <div className="flex-none">
              <MoreCircle11 />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1707478592() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478595() {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      {[...Array(3).keys()].map((_, i) => (
        <Frame1707478592 key={i} />
      ))}
    </div>
  );
}

function Frame1707478596() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478597() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478599() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478595 />
      <Frame1707478596 />
      {[...Array(2).keys()].map((_, i) => (
        <Frame1707478597 key={i} />
      ))}
    </div>
  );
}

function VuesaxOutlineMoreCircle6() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle13() {
  return (
    <div className="relative size-5" data-name="more-circle">
      <VuesaxOutlineMoreCircle6 />
    </div>
  );
}

function Frame1707478526() {
  return (
    <div className="bg-[#ffffff] mb-[-1px] relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478599 />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px]">
            <div className="flex-none">
              <MoreCircle13 />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1707478600() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-center justify-center p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0b5e6c] text-[10px] text-center text-nowrap">
        <p className="block leading-[20px] whitespace-pre">June - 2025</p>
      </div>
    </div>
  );
}

function Frame1707478601() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478603() {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478600 />
      {[...Array(2).keys()].map((_, i) => (
        <Frame1707478601 key={i} />
      ))}
    </div>
  );
}

function Frame1707478604() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478605() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478607() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478603 />
      <Frame1707478604 />
      {[...Array(2).keys()].map((_, i) => (
        <Frame1707478605 key={i} />
      ))}
    </div>
  );
}

function VuesaxOutlineMoreCircle7() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle15() {
  return (
    <div className="relative size-5" data-name="more-circle">
      <VuesaxOutlineMoreCircle7 />
    </div>
  );
}

function Frame1707478527() {
  return (
    <div className="bg-[#eef6f7] mb-[-1px] relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478607 />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px]">
            <div className="flex-none">
              <MoreCircle15 />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1707478608() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">28/06/25</p>
      </div>
    </div>
  );
}

function Frame1707478609() {
  return <div className="h-5 shrink-0 w-[67px]" />;
}

function Frame1707478610() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">Income</p>
      </div>
    </div>
  );
}

function Frame1707478611() {
  return (
    <div className="box-border content-stretch flex flex-row gap-8 items-center justify-start p-0 relative shrink-0">
      <Frame1707478608 />
      <Frame1707478609 />
      <Frame1707478610 />
    </div>
  );
}

function Frame1707478612() {
  return <div className="h-5 shrink-0 w-[131px]" />;
}

function Frame1707478613() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">Cleared</p>
      </div>
    </div>
  );
}

function Frame1707478614() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">k10,000</p>
      </div>
    </div>
  );
}

function Frame1707478615() {
  return (
    <div className="box-border content-stretch flex flex-col gap-0.5 items-start justify-start p-0 relative shrink-0 w-[67px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#000000] text-[12px] text-center w-[67px]">
        <p className="block leading-[20px]">K1,532,000</p>
      </div>
    </div>
  );
}

function Frame1707478632() {
  return (
    <div className="box-border content-stretch flex flex-row items-center justify-between p-0 relative shrink-0 w-[284px]">
      <Frame1707478613 />
      <Frame1707478614 />
      <Frame1707478615 />
    </div>
  );
}

function Frame1707478616() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[150px] items-center justify-start p-0 relative shrink-0 w-[1046px]">
      <Frame1707478611 />
      <Frame1707478612 />
      <Frame1707478632 />
    </div>
  );
}

function VuesaxOutlineMoreCircle8() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/outline/more-circle"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="more-circle">
          <g id="Vector"></g>
          <path
            d={svgPaths.pa32f200}
            fill="var(--fill-0, #171717)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2ac6100}
            fill="var(--fill-0, #171717)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p342f6680}
            fill="var(--fill-0, #171717)"
            id="Vector_4"
          />
          <g id="Vector_5" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function MoreCircle17() {
  return (
    <div className="relative size-5" data-name="more-circle">
      <VuesaxOutlineMoreCircle8 />
    </div>
  );
}

function Frame1707478617() {
  return (
    <div className="mb-[-1px] relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-start pl-6 pr-0 py-1 relative w-full">
          <Frame1707478616 />
          <div className="flex h-[20px] items-center justify-center relative shrink-0 w-[20px]">
            <div className="flex-none">
              <MoreCircle17 />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1707478731() {
  return (
    <div className="absolute bg-[#ffffff] h-[636px] left-0 rounded-[5px] top-[30px] w-[1099px]">
      <div className="box-border content-stretch flex flex-col h-[636px] items-start justify-start overflow-clip pb-px pt-0 px-0 relative w-[1099px]">
        <Frame1707478519 />
        <Frame1707478520 />
        <Frame1707478521 />
        <Frame1707478522 />
        <Frame1707478523 />
        <Frame1707478524 />
        <Frame1707478525 />
        <Frame1707478526 />
        <Frame1707478527 />
        {[...Array(11).keys()].map((_, i) => (
          <Frame1707478617 key={i} />
        ))}
      </div>
      <div className="absolute border border-[#e1e3e3] border-solid inset-0 pointer-events-none rounded-[5px]" />
    </div>
  );
}

function VuesaxLinearSearchNormal() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/search-normal"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="search-normal">
          <path
            d={svgPaths.p14d5dec0}
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d={svgPaths.p355f1080}
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function SearchNormal1() {
  return (
    <div className="relative shrink-0 size-5" data-name="search-normal">
      <VuesaxLinearSearchNormal />
    </div>
  );
}

function VuesaxLinearFilterSquare() {
  return (
    <div
      className="absolute contents inset-0"
      data-name="vuesax/linear/filter-square"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="filter-square">
          <path
            d={svgPaths.p39e08e80}
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeMiterlimit="10"
          />
          <path
            d={svgPaths.p1e16c800}
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <g id="Vector_3" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function FilterSquare1() {
  return (
    <div className="relative shrink-0 size-5" data-name="filter-square">
      <VuesaxLinearFilterSquare />
    </div>
  );
}

function VuesaxLinearSort() {
  return (
    <div className="absolute contents inset-0" data-name="vuesax/linear/sort">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="sort">
          <path
            d="M2.5 5.83333H17.5"
            id="Vector"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <path
            d="M5 10H15"
            id="Vector_2"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <path
            d="M8.33333 14.1667H11.6667"
            id="Vector_3"
            stroke="var(--stroke-0, #333333)"
            strokeLinecap="round"
          />
          <g id="Vector_4" opacity="0"></g>
        </g>
      </svg>
    </div>
  );
}

function Sort1() {
  return (
    <div className="relative shrink-0 size-5" data-name="sort">
      <VuesaxLinearSort />
    </div>
  );
}

function Frame1707478732({ 
  onSearch, 
  onFilter, 
  onSort,
  searchQuery = '',
  activeFilters = {},
  sortConfig
}: { 
  onSearch?: (query: string) => void;
  onFilter?: (filters: any) => void;
  onSort?: (column: string, direction: 'asc' | 'desc') => void;
  searchQuery?: string;
  activeFilters?: any;
  sortConfig?: { column: string; direction: 'asc' | 'desc' } | null;
}) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isSortOpen, setIsSortOpen] = useState(false);
  const [localSearchQuery, setLocalSearchQuery] = useState(searchQuery);
  
  const searchRef = useRef<HTMLDivElement>(null);
  const filterRef = useRef<HTMLDivElement>(null);
  const sortRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
      if (filterRef.current && !filterRef.current.contains(event.target as Node)) {
        setIsFilterOpen(false);
      }
      if (sortRef.current && !sortRef.current.contains(event.target as Node)) {
        setIsSortOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(localSearchQuery);
    }
    toast.info(localSearchQuery ? `Searching for "${localSearchQuery}"` : 'Cleared search filter');
  };

  const handleFilterSelect = (filterType: string, value: string) => {
    const newFilters = { ...activeFilters, [filterType]: value };
    if (onFilter) {
      onFilter(newFilters);
    }
    setIsFilterOpen(false);
    toast.info(`Applied ${filterType} filter: ${value}`);
  };

  const handleSortSelect = (column: string, direction: 'asc' | 'desc') => {
    if (onSort) {
      onSort(column, direction);
    }
    setIsSortOpen(false);
    toast.info(`Sorted by ${column} (${direction === 'asc' ? 'ascending' : 'descending'})`);
  };

  const clearAllFilters = () => {
    setLocalSearchQuery('');
    if (onSearch) onSearch('');
    if (onFilter) onFilter({});
    if (onSort) onSort('', 'asc');
    toast.success('All filters and search cleared');
  };

  const hasActiveFilters = Object.keys(activeFilters).length > 0 || localSearchQuery || sortConfig;

  return (
    <div className="absolute box-border content-stretch flex flex-row gap-3 items-center justify-start left-[900px] p-0 top-0">
      {/* Clear Filters Button */}
      {hasActiveFilters && (
        <button
          onClick={clearAllFilters}
          className="bg-red-50 text-red-600 px-2 py-1 rounded-md hover:bg-red-100 transition-colors text-xs"
          title="Clear all filters"
          aria-label="Clear all applied filters and search"
        >
          Clear All
        </button>
      )}

      {/* Search */}
      <div className="relative" ref={searchRef}>
        <button
          onClick={() => {
            setIsSearchOpen(!isSearchOpen);
            setIsFilterOpen(false);
            setIsSortOpen(false);
          }}
          className={`w-5 h-5 transition-colors hover:text-[#025864] ${
            isSearchOpen || localSearchQuery ? 'text-[#025864]' : 'text-gray-400'
          }`}
          title="Search transactions"
          aria-label="Search transactions"
          aria-expanded={isSearchOpen}
          aria-haspopup="true"
        >
          <svg className="block size-full" fill="none" stroke="currentColor" viewBox="0 0 20 20">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </button>

        <AnimatePresence>
          {isSearchOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -5 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -5 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className="absolute right-0 top-8 bg-white rounded-lg shadow-lg border border-gray-200 p-4 min-w-[280px] z-50"
              role="menu"
              aria-orientation="vertical"
            >
              <form onSubmit={handleSearchSubmit} className="space-y-3">
                <div>
                  <label htmlFor="search-input" className="block text-sm font-medium text-gray-700 mb-1">
                    Search Transactions
                  </label>
                  <input
                    id="search-input"
                    type="text"
                    value={localSearchQuery}
                    onChange={(e) => setLocalSearchQuery(e.target.value)}
                    placeholder="Search by amount, type, or date..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent text-sm"
                    autoFocus
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="bg-[#025864] text-white px-3 py-1.5 rounded-md hover:bg-[#003049] transition-colors text-sm flex-1"
                  >
                    Search
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLocalSearchQuery('');
                      if (onSearch) onSearch('');
                      setIsSearchOpen(false);
                    }}
                    className="bg-gray-100 text-gray-600 px-3 py-1.5 rounded-md hover:bg-gray-200 transition-colors text-sm"
                  >
                    Clear
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Filter */}
      <div className="relative" ref={filterRef}>
        <button
          onClick={() => {
            setIsFilterOpen(!isFilterOpen);
            setIsSearchOpen(false);
            setIsSortOpen(false);
          }}
          className={`w-5 h-5 transition-colors hover:text-[#025864] ${
            isFilterOpen || Object.keys(activeFilters).length > 0 ? 'text-[#025864]' : 'text-gray-400'
          }`}
          title="Filter transactions"
          aria-label="Filter transactions"
          aria-expanded={isFilterOpen}
          aria-haspopup="true"
        >
          <svg className="block size-full" fill="none" stroke="currentColor" viewBox="0 0 20 20">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-.293.707L12 11.414V19a1 1 0 01-.447.894l-2 1A1 1 0 018 20v-8.586L3.293 6.707A1 1 0 013 6V4z" />
          </svg>
        </button>

        <AnimatePresence>
          {isFilterOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -5 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -5 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className="absolute right-0 top-8 bg-white rounded-lg shadow-lg border border-gray-200 p-4 min-w-[240px] z-50"
              role="menu"
              aria-orientation="vertical"
            >
              <h3 className="text-sm font-medium text-gray-700 mb-3">Filter Transactions</h3>
              
              {/* Status Filter */}
              <div className="mb-4">
                <label className="block text-xs font-medium text-gray-600 mb-2">Status</label>
                <div className="space-y-1">
                  {['All Statuses', 'Cleared', 'Pending', 'Failed', 'Processing'].map((status) => (
                    <button
                      key={status}
                      onClick={() => handleFilterSelect('status', status === 'All Statuses' ? '' : status)}
                      className={`w-full text-left px-2 py-1 rounded text-sm transition-colors ${
                        (activeFilters.status === status) || (status === 'All Statuses' && !activeFilters.status)
                          ? 'bg-[#025864] text-white' 
                          : 'hover:bg-gray-50 text-gray-700'
                      }`}
                      role="menuitem"
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>

              {/* Transaction Type Filter */}
              <div className="mb-4">
                <label className="block text-xs font-medium text-gray-600 mb-2">Transaction Type</label>
                <div className="space-y-1">
                  {['All Types', 'Income', 'Expense', 'Transfer', 'Refund'].map((type) => (
                    <button
                      key={type}
                      onClick={() => handleFilterSelect('type', type === 'All Types' ? '' : type)}
                      className={`w-full text-left px-2 py-1 rounded text-sm transition-colors ${
                        (activeFilters.type === type) || (type === 'All Types' && !activeFilters.type)
                          ? 'bg-[#025864] text-white' 
                          : 'hover:bg-gray-50 text-gray-700'
                      }`}
                      role="menuitem"
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Date Range Filter */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-2">Date Range</label>
                <div className="space-y-1">
                  {['All Time', 'Today', 'This Week', 'This Month', 'Last 3 Months'].map((range) => (
                    <button
                      key={range}
                      onClick={() => handleFilterSelect('dateRange', range === 'All Time' ? '' : range)}
                      className={`w-full text-left px-2 py-1 rounded text-sm transition-colors ${
                        (activeFilters.dateRange === range) || (range === 'All Time' && !activeFilters.dateRange)
                          ? 'bg-[#025864] text-white' 
                          : 'hover:bg-gray-50 text-gray-700'
                      }`}
                      role="menuitem"
                    >
                      {range}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Sort */}
      <div className="relative" ref={sortRef}>
        <button
          onClick={() => {
            setIsSortOpen(!isSortOpen);
            setIsSearchOpen(false);
            setIsFilterOpen(false);
          }}
          className={`w-5 h-5 transition-colors hover:text-[#025864] ${
            isSortOpen || sortConfig ? 'text-[#025864]' : 'text-gray-400'
          }`}
          title="Sort transactions"
          aria-label="Sort transactions"
          aria-expanded={isSortOpen}
          aria-haspopup="true"
        >
          <svg className="block size-full" fill="none" stroke="currentColor" viewBox="0 0 20 20">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
          </svg>
        </button>

        <AnimatePresence>
          {isSortOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -5 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -5 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
              className="absolute right-0 top-8 bg-white rounded-lg shadow-lg border border-gray-200 p-4 min-w-[200px] z-50"
              role="menu"
              aria-orientation="vertical"
            >
              <h3 className="text-sm font-medium text-gray-700 mb-3">Sort By</h3>
              
              {[
                { label: 'Date (Newest)', column: 'date', direction: 'desc' as const },
                { label: 'Date (Oldest)', column: 'date', direction: 'asc' as const },
                { label: 'Amount (High to Low)', column: 'amount', direction: 'desc' as const },
                { label: 'Amount (Low to High)', column: 'amount', direction: 'asc' as const },
                { label: 'Status (A-Z)', column: 'status', direction: 'asc' as const },
                { label: 'Type (A-Z)', column: 'type', direction: 'asc' as const },
              ].map(({ label, column, direction }) => (
                <button
                  key={`${column}-${direction}`}
                  onClick={() => handleSortSelect(column, direction)}
                  className={`w-full text-left px-2 py-1.5 rounded text-sm transition-colors flex items-center justify-between ${
                    sortConfig?.column === column && sortConfig?.direction === direction
                      ? 'bg-[#025864] text-white' 
                      : 'hover:bg-gray-50 text-gray-700'
                  }`}
                  role="menuitem"
                >
                  {label}
                  {sortConfig?.column === column && sortConfig?.direction === direction && (
                    <svg className="w-3 h-3 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default function Group1000005063({ 
  transactions = [], 
  walletBalance = 0, 
  loading = false, 
  onViewTransaction = () => {},
  onExportTransactions,
  onFilterTransactions,
  onSortTransactions
}: WalletTransactionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState<any>({});
  const [sortConfig, setSortConfig] = useState<{ column: string; direction: 'asc' | 'desc' } | null>(null);
  const [filteredTransactions, setFilteredTransactions] = useState<any[]>([]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Generate mock transaction data for the table display with proper ZMW amounts
  const generateMockTransactions = () => {
    const baseTransactions = [
      { id: 'txn_001', date: '28/07/25', type: 'Income', status: 'Cleared', amount: 10000, balance: walletBalance },
      { id: 'txn_002', date: '27/07/25', type: 'Income', status: 'Cleared', amount: 15000, balance: walletBalance - 10000 },
      { id: 'txn_003', date: '26/07/25', type: 'Income', status: 'Pending', amount: 10000, balance: walletBalance - 25000 },
      { id: 'txn_004', date: '25/07/25', type: 'Transfer', status: 'Cleared', amount: 5000, balance: walletBalance - 35000 },
      { id: 'txn_005', date: '24/07/25', type: 'Income', status: 'Failed', amount: 8000, balance: walletBalance - 40000 },
      { id: 'txn_006', date: '23/07/25', type: 'Expense', status: 'Cleared', amount: 3000, balance: walletBalance - 48000 }
    ];
    return baseTransactions;
  };

  const mockTransactions = generateMockTransactions();

  // Apply search, filter, and sort to transactions
  useEffect(() => {
    let filtered = [...mockTransactions];

    // Apply search
    if (searchQuery) {
      filtered = filtered.filter(transaction => 
        transaction.date.toLowerCase().includes(searchQuery.toLowerCase()) ||
        transaction.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
        transaction.status.toLowerCase().includes(searchQuery.toLowerCase()) ||
        transaction.amount.toString().includes(searchQuery) ||
        formatCurrency(transaction.amount).toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply filters
    if (activeFilters.status) {
      filtered = filtered.filter(transaction => 
        transaction.status.toLowerCase() === activeFilters.status.toLowerCase()
      );
    }
    if (activeFilters.type) {
      filtered = filtered.filter(transaction => 
        transaction.type.toLowerCase() === activeFilters.type.toLowerCase()
      );
    }
    if (activeFilters.dateRange) {
      // Simple date range filtering (can be expanded with actual date logic)
      const today = new Date();
      const filterDate = new Date();
      
      switch (activeFilters.dateRange) {
        case 'Today':
          // Filter for today (simplified)
          filtered = filtered.filter(transaction => 
            transaction.date.includes(today.getDate().toString().padStart(2, '0'))
          );
          break;
        case 'This Week':
          // Filter for this week (simplified)
          filtered = filtered.slice(0, 3);
          break;
        case 'This Month':
          // Filter for this month (simplified)
          filtered = filtered.slice(0, 4);
          break;
        case 'Last 3 Months':
          // Show all for last 3 months
          break;
      }
    }

    // Apply sorting
    if (sortConfig) {
      filtered.sort((a, b) => {
        let aValue: any = a[sortConfig.column as keyof typeof a];
        let bValue: any = b[sortConfig.column as keyof typeof b];

        // Handle different data types
        if (sortConfig.column === 'amount' || sortConfig.column === 'balance') {
          aValue = Number(aValue);
          bValue = Number(bValue);
        } else if (sortConfig.column === 'date') {
          // Simple date comparison (can be improved with proper date parsing)
          aValue = new Date(aValue.split('/').reverse().join('-'));
          bValue = new Date(bValue.split('/').reverse().join('-'));
        } else {
          aValue = String(aValue).toLowerCase();
          bValue = String(bValue).toLowerCase();
        }

        if (aValue < bValue) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }

    setFilteredTransactions(filtered);
  }, [searchQuery, activeFilters, sortConfig, walletBalance]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (onFilterTransactions) {
      onFilterTransactions(query);
    }
  };

  const handleFilter = (filters: any) => {
    setActiveFilters(filters);
    if (onFilterTransactions) {
      onFilterTransactions(JSON.stringify(filters));
    }
  };

  const handleSort = (column: string, direction: 'asc' | 'desc') => {
    if (column === '') {
      setSortConfig(null);
    } else {
      setSortConfig({ column, direction });
    }
    if (onSortTransactions) {
      onSortTransactions(column, direction);
    }
  };

  const handleRowClick = (transactionId: string) => {
    onViewTransaction(transactionId);
    toast.info(`Viewing details for transaction: ${transactionId}`);
  };

  const handleTransactionAction = (action: string, transactionId?: string) => {
    switch (action) {
      case 'View Details':
        if (transactionId) {
          onViewTransaction(transactionId);
          toast.info(`Opening transaction details: ${transactionId}`);
        }
        break;
      case 'Download Receipt':
        toast.success(`Receipt download initiated for transaction: ${transactionId}`);
        break;
      case 'Flag Transaction':
        toast.warning(`Transaction flagged for review: ${transactionId}`);
        break;
      case 'Export Transaction':
        toast.info(`Exporting transaction data: ${transactionId}`);
        break;
      case 'Mark as Reviewed':
        toast.success(`Transaction marked as reviewed: ${transactionId}`);
        break;
      default:
        toast.info(`${action} functionality will be available in the next update`);
    }
  };

  if (loading) {
    return (
      <div className="relative size-full flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#025864] mx-auto mb-2"></div>
          <div className="text-gray-600 text-sm">Loading transactions...</div>
        </div>
      </div>
    );
  }

  // Show message when no transactions match filters
  const displayTransactions = filteredTransactions.length > 0 ? filteredTransactions : mockTransactions;
  const showNoResults = filteredTransactions.length === 0 && (searchQuery || Object.keys(activeFilters).length > 0);

  return (
    <div className="relative size-full">
      <div className="absolute bg-[#ffffff] h-[636px] left-0 rounded-[5px] top-[30px] w-[1099px]">
        <div className="box-border content-stretch flex flex-col h-[636px] items-start justify-start overflow-clip pb-px pt-0 px-0 relative w-[1099px]">
          <Frame1707478519 
            onSort={(column) => {
              const newDirection = sortConfig?.column === column && sortConfig?.direction === 'asc' ? 'desc' : 'asc';
              handleSort(column, newDirection);
            }}
            sortBy={sortConfig?.column}
            sortOrder={sortConfig?.direction}
          />
          <Frame1707478520 onAction={handleTransactionAction} />
          
          {showNoResults ? (
            <div className="flex-1 flex items-center justify-center w-full">
              <div className="text-center py-8">
                <svg className="w-12 h-12 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
                <h3 className="text-sm font-medium text-gray-700 mb-1">No transactions found</h3>
                <p className="text-xs text-gray-500">
                  Try adjusting your search terms or filters to find transactions.
                </p>
              </div>
            </div>
          ) : (
            <>
              {displayTransactions.slice(0, 4).map((transaction, index) => {
                if (index === 0) {
                  return (
                    <Frame1707478521 
                      key={transaction.id}
                      mockTransactions={[transaction]} 
                      index={0}
                      onRowClick={handleRowClick}
                      onAction={handleTransactionAction}
                    />
                  );
                } else if (index === 1) {
                  return (
                    <Frame1707478522 
                      key={transaction.id}
                      mockTransactions={[transaction]} 
                      index={0}
                      onRowClick={handleRowClick}
                      onAction={handleTransactionAction}
                    />
                  );
                } else if (index === 2) {
                  return (
                    <Frame1707478523 
                      key={transaction.id}
                      mockTransactions={[transaction]} 
                      index={0}
                      onRowClick={handleRowClick}
                      onAction={handleTransactionAction}
                    />
                  );
                } else {
                  return (
                    <Frame1707478524 
                      key={transaction.id}
                      mockTransactions={[transaction]} 
                      index={0}
                      onRowClick={handleRowClick}
                      onAction={handleTransactionAction}
                    />
                  );
                }
              })}
            </>
          )}
        </div>
        <div className="absolute border border-[#e1e3e3] border-solid inset-0 pointer-events-none rounded-[5px]" />
      </div>
      
      <div className="absolute font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] leading-[0] left-[30px] not-italic text-[#000000] text-[16px] text-left text-nowrap top-0">
        <p className="block leading-[normal] whitespace-pre">
          Master Wallet Account Balance History
        </p>
        {(searchQuery || Object.keys(activeFilters).length > 0 || sortConfig) && (
          <p className="block text-xs text-gray-500 mt-1">
            {filteredTransactions.length} of {mockTransactions.length} transactions shown
          </p>
        )}
      </div>
      
      <Frame1707478732 
        onSearch={handleSearch}
        onFilter={handleFilter}
        onSort={handleSort}
        searchQuery={searchQuery}
        activeFilters={activeFilters}
        sortConfig={sortConfig}
      />
    </div>
  );
}