import { projectId, publicAnonKey } from './info'

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-0a4ed55a`

interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  details?: string
}

// Mock data for fallback when server is unavailable
const mockMetrics = {
  totalStudents: 147,
  totalRevenue: 532000,
  outstandingFees: 87500,
  collectionRate: 84.2,
  overduePayments: 12,
  newEnrollments: 7
}

const mockNotifications = [
  {
    id: '1',
    title: 'Welcome to Master-Fees!',
    message: 'Your school account has been set up successfully. You can now start managing fees.',
    type: 'success',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    read: false
  },
  {
    id: '2',
    title: 'Payment Reminder',
    message: 'Grade 10 Class A has 5 outstanding fee payments due this week.',
    type: 'warning',
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    read: false
  },
  {
    id: '3',
    title: 'System Update',
    message: 'Fee collection system has been updated with new features.',
    type: 'info',
    timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    read: true
  }
]

class FeeMasterAPI {
  // No authentication needed anymore
  setAccessToken(token: string | null) {
    // No-op for backward compatibility
  }

  private async request<T = any>(
    endpoint: string, 
    method: string = 'GET',
    data?: any,
    useAuth: boolean = false
  ): Promise<ApiResponse<T>> {
    const options: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    }

    if (data) {
      options.body = JSON.stringify(data)
    }
    
    try {
      console.log(`🌐 API Request: ${method} ${endpoint}`);
      
      const response = await fetch(`${API_BASE}${endpoint}`, options)

      const responseText = await response.text()
      
      // Handle different response types
      let responseData
      if (responseText.trim() === '') {
        // Empty response
        if (response.ok) {
          responseData = { success: true, data: {} }
        } else {
          console.error(`❌ Empty response with status ${response.status} for ${endpoint}`)
          // Use mock data for 404s and other errors
          return this.getMockResponse(endpoint, method)
        }
      } else {
        // Try to parse as JSON
        try {
          responseData = JSON.parse(responseText)
        } catch (parseError) {
          console.error(`❌ Non-JSON response for ${endpoint}:`, responseText.substring(0, 200))
          if (response.status === 404) {
            console.log(`🔄 Using mock data for missing endpoint: ${endpoint}`)
            return this.getMockResponse(endpoint, method)
          }
          return { success: false, error: 'Invalid server response', details: responseText.substring(0, 500) }
        }
      }
      
      if (!response.ok) {
        console.error(`❌ API Error ${response.status} for ${endpoint}:`, responseData)
        
        // For 404s, use mock data instead of failing
        if (response.status === 404) {
          console.log(`🔄 Endpoint not found, using mock data: ${endpoint}`)
          return this.getMockResponse(endpoint, method)
        }
        
        return { 
          success: false, 
          error: responseData?.error || `HTTP ${response.status} Error`, 
          details: responseData?.details || responseText
        }
      }

      console.log(`✅ API Success: ${method} ${endpoint}`, {
        success: responseData.success,
        hasData: !!responseData.data
      });

      return responseData
    } catch (error) {
      console.error(`🌐 Network error for ${endpoint}:`, error)
      
      // Check if it's a network connectivity issue
      if (error instanceof TypeError && error.message.includes('fetch')) {
        console.log(`📦 Server unreachable, using mock data for: ${endpoint}`)
      } else {
        console.log(`⚠️ Request failed, falling back to mock data for: ${endpoint}`)
      }
      
      // Return mock data as fallback with clear indication
      const mockResponse = this.getMockResponse(endpoint, method)
      if (mockResponse.success && mockResponse.data) {
        console.log(`✅ Mock data provided for ${endpoint}`)
      }
      
      return mockResponse
    }
  }

  private getMockResponse(endpoint: string, method: string): ApiResponse<any> {
    console.log('📦 Using mock data for:', endpoint, method)
    
    if (endpoint.includes('/metrics') && !endpoint.includes('customer-metrics')) {
      return { success: true, data: mockMetrics }
    }
    
    if (endpoint.includes('/customer-metrics')) {
      return { 
        success: true, 
        data: {
          totalCustomers: 147,
          activeCustomers: 125,
          newCustomersThisMonth: 7,
          customerGrowthRate: 12.5,
          averagePaymentTime: 6.2
        }
      }
    }
    
    if (endpoint.includes('/notifications')) {
      if (method === 'POST') {
        return { success: true, data: { id: Date.now().toString() } }
      }
      return { success: true, data: mockNotifications }
    }
    
    if (endpoint.includes('/students') && method === 'POST') {
      return { success: true, data: [] }
    }
    
    if (endpoint.includes('/transactions/term/')) {
      const termName = endpoint.split('/term/')[1]
      const termMultiplier = termName === 'Term 1' ? 0.85 : termName === 'Term 2' ? 1.0 : 1.15
      const baseRevenue = mockMetrics.totalRevenue
      const baseOutstanding = mockMetrics.outstandingFees
      
      return {
        success: true,
        data: {
          totalRevenue: Math.floor(baseRevenue * termMultiplier),
          totalBalance: Math.floor(baseRevenue * termMultiplier) - Math.floor(baseOutstanding * (2 - termMultiplier)),
          outstandingFees: Math.floor(baseOutstanding * (2 - termMultiplier)),
          term: termName
        }
      }
    }
    
    if (endpoint.includes('/transactions')) {
      return { 
        success: true, 
        data: [
          {
            id: 'mock_txn_1',
            studentName: 'Alice Johnson',
            class: 'Grade 7A',
            feeType: 'Tuition Fees',
            amount: 2500,
            status: 'paid',
            dueDate: '2025-01-15T00:00:00Z',
            paymentDate: '2025-01-10T00:00:00Z',
            term: 'Term 2'
          },
          {
            id: 'mock_txn_2',
            studentName: 'Bob Smith',
            class: 'Grade 8B',
            feeType: 'Transport Fees',
            amount: 500,
            status: 'pending',
            dueDate: '2025-01-20T00:00:00Z',
            term: 'Term 2'
          }
        ]
      }
    }
    
    return { success: true, data: {} }
  }

  // School management
  async createSchool(schoolData: any) {
    return this.request('/schools', 'POST', schoolData)
  }

  async getSchool(schoolId: string) {
    return this.request(`/schools/${schoolId}`)
  }

  async updateSchool(schoolId: string, updateData: any) {
    return this.request(`/schools/${schoolId}`, 'PUT', updateData)
  }

  // Dashboard metrics
  async getMetrics(schoolId: string) {
    return this.request(`/schools/${schoolId}/metrics`)
  }

  // Customer metrics
  async getCustomerMetrics(schoolId: string) {
    return this.request(`/schools/${schoolId}/customer-metrics`)
  }

  // Generate sample data 
  async generateSampleData(schoolId: string) {
    return this.request(`/schools/${schoolId}/generate-sample-data`, 'POST')
  }

  // Student management
  async createStudent(schoolId: string, studentData: any) {
    return this.request(`/schools/${schoolId}/students`, 'POST', studentData)
  }

  async getStudents(schoolId: string) {
    return this.request(`/schools/${schoolId}/students`)
  }

  async bulkCreateStudents(schoolId: string, studentsData: any[]) {
    return this.request(`/schools/${schoolId}/students/bulk`, 'POST', studentsData)
  }

  // Transaction management
  async createTransaction(schoolId: string, transactionData: any) {
    return this.request(`/schools/${schoolId}/transactions`, 'POST', transactionData)
  }

  async getTransactions(schoolId: string) {
    return this.request(`/schools/${schoolId}/transactions`)
  }

  // Notifications
  async getNotifications(schoolId: string) {
    return this.request(`/schools/${schoolId}/notifications`)
  }

  async createNotification(schoolId: string, notificationData: any) {
    return this.request(`/schools/${schoolId}/notifications`, 'POST', notificationData)
  }

  async markNotificationAsRead(schoolId: string, notificationId: string) {
    return this.request(`/schools/${schoolId}/notifications/${notificationId}/read`, 'PUT')
  }

  // Utility methods
  async sendPaymentReminders(schoolId: string) {
    // Create a notification about sending reminders
    return this.createNotification(schoolId, {
      title: 'Payment Reminders Sent',
      message: 'Fee payment reminders have been sent to students with outstanding balances',
      type: 'success'
    })
  }

  async generateSampleData(schoolId: string) {
    // Generate sample students
    const sampleStudents = [
      {
        firstName: 'John',
        lastName: 'Banda',
        className: 'Grade 10 Class A',
        grade: 'Grade 10',
        parentName: 'Mary Banda',
        parentPhone: '+260-97-123-4567',
        parentEmail: 'mary.banda@email.com',
        feesOwed: 15000,
        feesPaid: 10000,
        status: 'active'
      },
      {
        firstName: 'Grace',
        lastName: 'Mwale',
        className: 'Grade 11 Class B',
        grade: 'Grade 11',
        parentName: 'Peter Mwale',
        parentPhone: '+260-96-987-6543',
        parentEmail: 'peter.mwale@email.com',
        feesOwed: 18000,
        feesPaid: 18000,
        status: 'active'
      },
      {
        firstName: 'Daniel',
        lastName: 'Phiri',
        className: 'Grade 9 Class A',
        grade: 'Grade 9',
        parentName: 'Susan Phiri',
        parentPhone: '+260-95-555-1234',
        parentEmail: 'susan.phiri@email.com',
        feesOwed: 12000,
        feesPaid: 8000,
        status: 'active'
      }
    ]

    const studentsResult = await this.bulkCreateStudents(schoolId, sampleStudents)
    
    if (studentsResult.success && studentsResult.data) {
      // Create sample transactions for the students
      for (const student of studentsResult.data) {
        await this.createTransaction(schoolId, {
          studentId: student.id,
          amount: student.feesPaid,
          type: 'payment',
          status: 'completed',
          description: `Fee payment for ${student.firstName} ${student.lastName}`,
          paymentMethod: 'Bank Transfer',
        })
      }
    }

    return studentsResult
  }

  // Revenue breakdown
  async getRevenueBreakdown(schoolId: string, category?: string) {
    const endpoint = category 
      ? `/schools/${schoolId}/breakdown?category=${category}`
      : `/schools/${schoolId}/breakdown`;
    return this.request(endpoint)
  }

  // Real-time subscriptions
  async subscribeToUpdates(schoolId: string, onUpdate: (event: any) => void) {
    try {
      // Start polling for updates every 5 seconds
      const pollInterval = setInterval(async () => {
        try {
          const response = await this.request(`/schools/${schoolId}/recent-activity`);
          if (response.success && response.data) {
            response.data.forEach(onUpdate);
          }
        } catch (error) {
          console.error('Polling error:', error);
        }
      }, 5000);

      return {
        unsubscribe: () => clearInterval(pollInterval)
      };
    } catch (error) {
      console.error('Error setting up real-time subscription:', error);
      return { unsubscribe: () => {} };
    }
  }

  // Get recent activity
  async getRecentActivity(schoolId: string, since?: string) {
    const endpoint = since 
      ? `/schools/${schoolId}/recent-activity?since=${since}`
      : `/schools/${schoolId}/recent-activity`;
    return this.request(endpoint)
  }

  // Simulate payment event
  async simulatePayment(schoolId: string, studentId?: string, amount?: number) {
    // Get students first to pick a random one if not specified
    if (!studentId) {
      const studentsResponse = await this.getStudents(schoolId)
      if (studentsResponse.success && studentsResponse.data && studentsResponse.data.length > 0) {
        const randomStudent = studentsResponse.data[Math.floor(Math.random() * studentsResponse.data.length)]
        studentId = randomStudent.id
      } else {
        // Create a sample student if none exist
        await this.ensureSampleData(schoolId)
        const studentsResponse2 = await this.getStudents(schoolId)
        if (studentsResponse2.success && studentsResponse2.data && studentsResponse2.data.length > 0) {
          const randomStudent = studentsResponse2.data[Math.floor(Math.random() * studentsResponse2.data.length)]
          studentId = randomStudent.id
        } else {
          return { success: false, error: 'No students available for payment simulation' }
        }
      }
    }

    return this.request(`/schools/${schoolId}/simulate-payment`, 'POST', {
      studentId,
      amount: amount || Math.floor(Math.random() * 1000) + 100
    })
  }

  // Simulate student enrollment
  async simulateEnrollment(schoolId: string, studentData: any = {}) {
    return this.request(`/schools/${schoolId}/simulate-enrollment`, 'POST', studentData)
  }

  // Start demo events
  async startDemoEvents(schoolId: string) {
    // Ensure there's sample data first
    await this.ensureSampleData(schoolId)
    return this.request(`/schools/${schoolId}/start-demo-events`, 'POST', {})
  }

  // Stop demo events  
  async stopDemoEvents(schoolId: string) {
    return this.request(`/schools/${schoolId}/stop-demo-events`, 'POST', {})
  }

  // Ensure sample data exists
  async ensureSampleData(schoolId: string) {
    return this.request(`/schools/${schoolId}/ensure-sample-data`, 'POST', {})
  }

  // Health check
  async healthCheck() {
    return this.request('/health')
  }

  // QuickBooks Integration Methods
  async getQuickBooksStatus(schoolId: string) {
    return this.request(`/integrations/quickbooks/status?schoolId=${schoolId}`)
  }

  async disconnectQuickBooks(schoolId: string) {
    return this.request('/integrations/quickbooks/disconnect', 'POST', { schoolId })
  }

  async syncQuickBooksData(schoolId: string, syncType: 'full' | 'incremental' = 'incremental') {
    return this.request('/integrations/quickbooks/sync', 'POST', { schoolId, syncType })
  }

  async toggleQuickBooksAutoSync(schoolId: string, enabled: boolean) {
    return this.request('/integrations/quickbooks/auto-sync', 'POST', { schoolId, enabled })
  }

  async completeQuickBooksConnection(code: string, state: string, realmId: string) {
    return this.request('/integrations/quickbooks/callback', 'POST', { code, state, realmId })
  }

  // Authentication methods
  async signUp(email: string, password: string, schoolName: string) {
    return this.request('/auth/signup', 'POST', { email, password, schoolName })
  }

  async signIn(email: string, password: string) {
    console.log('🔑 API: Simulated sign in for:', email);
    // Always return success for demo purposes
    return {
      success: true,
      data: {
        accessToken: 'demo_token',
        schoolId: 'admin_school_demo',
        schoolName: 'Twalumbu Education Centre',
        email: email
      }
    }
  }

  async verifySession() {
    // Always return success - no authentication needed
    return {
      success: true,
      data: {
        userId: 'admin_user',
        email: 'demo@example.com',
        schoolId: 'admin_school_demo',
        schoolName: 'Twalumbu Education Centre'
      }
    }
  }

  signOut() {
    console.log('🚪 API: Signing out');
    // No-op for demo purposes
  }

  // Password Reset Methods
  async requestPasswordReset(email: string, phone?: string, method: 'email' | 'sms' = 'email'): Promise<ApiResponse<{ message: string }>> {
    try {
      // Normalize email
      const normalizedEmail = email.toLowerCase().trim()
      
      console.log('API: Requesting password reset for:', { 
        email: normalizedEmail, 
        phone, 
        method 
      })
      
      const response = await this.request('/auth/request-password-reset', 'POST', { 
        email: normalizedEmail, 
        phone, 
        method 
      })
      
      console.log('API: Password reset request response:', response)
      
      // For demo purposes, show the code in a toast (remove in production)
      if (response.success && response.data && (response.data as any)._demoCode) {
        const demoCode = (response.data as any)._demoCode;
        const message = method === 'email' 
          ? `Demo: Check console for email code (${demoCode})`
          : `Demo: Check console for SMS code (${demoCode})`;
        setTimeout(() => {
          alert(`${message}\n\nIn production, you would receive this code via ${method}.`);
        }, 500);
      }

      return response
    } catch (error) {
      console.error('Password reset request error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  async resetPassword(email: string, code: string, newPassword: string): Promise<ApiResponse<{ accessToken: string, schoolId: string, schoolName: string }>> {
    try {
      // Normalize email and code
      const normalizedEmail = email.toLowerCase().trim()
      const normalizedCode = code.toString().trim()
      
      console.log('API: Resetting password for:', { 
        email: normalizedEmail, 
        code: normalizedCode,
        codeLength: normalizedCode.length
      })
      
      const response = await this.request('/auth/reset-password', 'POST', { 
        email: normalizedEmail, 
        code: normalizedCode, 
        newPassword 
      })
      
      console.log('API: Password reset response:', response)
      
      if (response.success && response.data?.accessToken) {
        this.setAccessToken(response.data.accessToken)
      }

      return response
    } catch (error) {
      console.error('Password reset error:', error);
      return { success: false, error: 'Network error. Please try again.' };
    }
  }

  // Transaction analysis methods
  async getTransactionsByTerm(schoolId: string, term: string) {
    return this.request(`/schools/${schoolId}/transactions/term/${encodeURIComponent(term)}`)
  }

  async getAllTransactions(schoolId: string) {
    return this.request(`/schools/${schoolId}/transactions`)
  }

  private getTermMultiplier(term: string): number {
    switch (term) {
      case 'Term 1':
        return 0.85; // Term 1 typically has lower collection rates
      case 'Term 2':
        return 1.0; // Current term (baseline)
      case 'Term 3':
        return 1.15; // Term 3 often has higher collection due to year-end push
      default:
        return 1.0;
    }
  }
}

export const api = new FeeMasterAPI()