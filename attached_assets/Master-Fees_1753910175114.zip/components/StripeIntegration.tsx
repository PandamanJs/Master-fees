import { useState } from 'react';
import { toast } from "sonner@2.0.3";

interface StripeIntegrationProps {
  schoolId: string;
  onConnectionChange: (connected: boolean) => void;
}

export default function StripeIntegration({ schoolId, onConnectionChange }: StripeIntegrationProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      // Simulate connection process
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsConnected(true);
      onConnectionChange(true);
      toast.success("Stripe integration connected successfully! You can now process payments directly from Master-Fees.");
    } catch (error) {
      toast.error("Failed to connect to Stripe. Please check your credentials and try again.");
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      setIsConnected(false);
      onConnectionChange(false);
      toast.info("Stripe integration disconnected");
    } catch (error) {
      toast.error("Failed to disconnect Stripe integration");
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#635bff] rounded-lg flex items-center justify-center">
            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M13.976 9.15c-2.172-.806-3.356-1.426-3.356-2.409 0-.831.683-1.305 1.901-1.305 2.227 0 4.515.858 6.09 1.631l.89-5.494C18.252.975 15.697 0 12.165 0 9.667 0 7.589.654 6.104 1.872 4.56 3.147 3.757 4.992 3.757 7.218c0 4.039 2.467 5.76 6.476 7.219 2.585.92 3.445 1.574 3.445 2.583 0 .98-.84 1.545-2.354 1.545-1.875 0-4.965-.921-6.99-2.109l-.9 5.555C5.175 22.99 8.385 24 11.714 24c2.641 0 4.843-.624 6.328-1.813 1.664-1.305 2.525-3.236 2.525-5.732 0-4.128-2.524-5.851-6.594-7.305h.003z"/>
            </svg>
          </div>
          <div>
            <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-lg mb-1">
              Stripe
            </h3>
            <p className="text-gray-600 text-sm mb-2">
              Accept online payments with credit cards, debit cards, and digital wallets
            </p>
            <div className="flex items-center gap-2">
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                isConnected 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {isConnected ? 'Connected' : 'Not Connected'}
              </span>
              <span className="text-gray-400 text-xs">•</span>
              <span className="text-gray-500 text-xs">Payment Processing</span>
            </div>
          </div>
        </div>
        <div>
          {isConnected ? (
            <button
              onClick={handleDisconnect}
              className="bg-red-50 text-red-700 px-4 py-2 rounded-md hover:bg-red-100 transition-colors text-sm"
            >
              Disconnect
            </button>
          ) : (
            <button
              onClick={handleConnect}
              disabled={isConnecting}
              className="bg-[#635bff] text-white px-4 py-2 rounded-md hover:bg-[#5751e6] transition-colors text-sm disabled:opacity-50"
            >
              {isConnecting ? 'Connecting...' : 'Connect'}
            </button>
          )}
        </div>
      </div>
      
      {isConnected && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-[#635bff]">2.9%</div>
              <div className="text-xs text-gray-500">Processing Fee</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">24/7</div>
              <div className="text-xs text-gray-500">Support</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">150+</div>
              <div className="text-xs text-gray-500">Currencies</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}