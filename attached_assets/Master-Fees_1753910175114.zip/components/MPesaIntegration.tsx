import { useState } from 'react';
import { toast } from "sonner@2.0.3";

interface MPesaIntegrationProps {
  schoolId: string;
  onConnectionChange: (connected: boolean) => void;
}

export default function MPesaIntegration({ schoolId, onConnectionChange }: MPesaIntegrationProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsConnected(true);
      onConnectionChange(true);
      toast.success("M-Pesa integration connected! Parents can now pay fees using mobile money.");
    } catch (error) {
      toast.error("Failed to connect to M-Pesa. Please verify your till number and API credentials.");
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      setIsConnected(false);
      onConnectionChange(false);
      toast.info("M-Pesa integration disconnected");
    } catch (error) {
      toast.error("Failed to disconnect M-Pesa integration");
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#00a651] rounded-lg flex items-center justify-center">
            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          </div>
          <div>
            <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-lg mb-1">
              M-Pesa
            </h3>
            <p className="text-gray-600 text-sm mb-2">
              Accept mobile money payments from Safaricom M-Pesa users
            </p>
            <div className="flex items-center gap-2">
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                isConnected 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {isConnected ? 'Connected' : 'Not Connected'}
              </span>
              <span className="text-gray-400 text-xs">•</span>
              <span className="text-gray-500 text-xs">Mobile Money</span>
            </div>
          </div>
        </div>
        <div>
          {isConnected ? (
            <button
              onClick={handleDisconnect}
              className="bg-red-50 text-red-700 px-4 py-2 rounded-md hover:bg-red-100 transition-colors text-sm"
            >
              Disconnect
            </button>
          ) : (
            <button
              onClick={handleConnect}
              disabled={isConnecting}
              className="bg-[#00a651] text-white px-4 py-2 rounded-md hover:bg-[#008f47] transition-colors text-sm disabled:opacity-50"
            >
              {isConnecting ? 'Connecting...' : 'Connect'}
            </button>
          )}
        </div>
      </div>
      
      {isConnected && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-[#00a651]">Instant</div>
              <div className="text-xs text-gray-500">Payments</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">24/7</div>
              <div className="text-xs text-gray-500">Available</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">SMS</div>
              <div className="text-xs text-gray-500">Confirmations</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}