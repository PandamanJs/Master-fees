import { useState } from 'react';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export default function SupportFAQ() {
  const [expandedItem, setExpandedItem] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const faqItems: FAQItem[] = [
    {
      id: 'setup-1',
      question: 'How do I set up Master-Fees for my school?',
      answer: 'Setting up Master-Fees is simple. After signing up, follow our onboarding wizard to configure your school details, grade levels, and fee structures. The process typically takes 10-15 minutes.',
      category: 'setup'
    },
    {
      id: 'payments-1',
      question: 'What payment methods does Master-Fees support?',
      answer: 'Master-Fees supports multiple payment methods including credit/debit cards via Stripe, PayPal, mobile money (M-Pesa), bank transfers, and cash payments recorded manually.',
      category: 'payments'
    },
    {
      id: 'reports-1',
      question: 'How can I generate financial reports?',
      answer: 'Navigate to the Dashboard and click on "Generate Report" or go to Settings > Reports. You can create custom reports by date range, grade level, fee type, and payment status.',
      category: 'reports'
    },
    {
      id: 'integration-1',
      question: 'Can Master-Fees integrate with my existing accounting software?',
      answer: 'Yes! Master-Fees integrates with popular accounting platforms like QuickBooks, Xero, Sage, and Wave. Visit the Integrations page to connect your preferred software.',
      category: 'integrations'
    },
    {
      id: 'students-1',
      question: 'How do I add new students to the system?',
      answer: 'Go to Customer Management and click "Add New Customer". Fill in the student details, assign them to a grade/class, and set up their fee structure. You can also bulk import students via CSV.',
      category: 'students'
    },
    {
      id: 'security-1',
      question: 'Is my school\'s financial data secure?',
      answer: 'Absolutely. Master-Fees uses bank-level encryption, secure cloud storage, and complies with international data protection standards. All financial transactions are processed through certified payment processors.',
      category: 'security'
    },
    {
      id: 'notifications-1',
      question: 'How do payment reminders work?',
      answer: 'Master-Fees automatically sends payment reminders via email and SMS based on your configured schedule. You can customize reminder timing, frequency, and messaging in the Settings.',
      category: 'payments'
    },
    {
      id: 'backup-1',
      question: 'How is my data backed up?',
      answer: 'Your data is automatically backed up daily to secure cloud servers with 99.9% uptime guarantee. You can also export your data anytime for additional backup or migration purposes.',
      category: 'security'
    }
  ];

  const categories = [
    { id: 'all', label: 'All Topics', count: faqItems.length },
    { id: 'setup', label: 'Setup & Configuration', count: faqItems.filter(item => item.category === 'setup').length },
    { id: 'payments', label: 'Payments & Billing', count: faqItems.filter(item => item.category === 'payments').length },
    { id: 'students', label: 'Student Management', count: faqItems.filter(item => item.category === 'students').length },
    { id: 'reports', label: 'Reports & Analytics', count: faqItems.filter(item => item.category === 'reports').length },
    { id: 'integrations', label: 'Integrations', count: faqItems.filter(item => item.category === 'integrations').length },
    { id: 'security', label: 'Security & Privacy', count: faqItems.filter(item => item.category === 'security').length }
  ];

  const filteredFAQs = selectedCategory === 'all' 
    ? faqItems 
    : faqItems.filter(item => item.category === selectedCategory);

  const toggleExpanded = (itemId: string) => {
    setExpandedItem(expandedItem === itemId ? null : itemId);
  };

  return (
    <div className="bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-2xl text-[#1f1f20] mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Find quick answers to common questions about Master-Fees features and functionality.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Category Filter */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg p-6 shadow-sm sticky top-6">
              <h3 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] text-lg mb-4">
                Categories
              </h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-left px-3 py-2 rounded-md transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-[#025864] text-white'
                        : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm">{category.label}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        selectedCategory === category.id
                          ? 'bg-white/20 text-white'
                          : 'bg-gray-200 text-gray-600'
                      }`}>
                        {category.count}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* FAQ Items */}
          <div className="lg:col-span-3">
            <div className="space-y-4">
              {filteredFAQs.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden"
                >
                  <button
                    onClick={() => toggleExpanded(item.id)}
                    className="w-full px-6 py-4 text-left hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] text-[#1f1f20] text-base pr-4">
                        {item.question}
                      </h4>
                      <svg
                        className={`w-5 h-5 text-gray-500 transition-transform ${
                          expandedItem === item.id ? 'rotate-180' : ''
                        }`}
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                      </svg>
                    </div>
                  </button>
                  
                  {expandedItem === item.id && (
                    <div className="px-6 pb-4 border-t border-gray-100">
                      <p className="text-gray-600 text-sm leading-relaxed pt-4">
                        {item.answer}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {filteredFAQs.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.034 0-3.9.785-5.291 2.062M6.343 6.343A8 8 0 1021.657 21.657 8 8 0 006.343 6.343z" />
                  </svg>
                </div>
                <p className="text-gray-500">No questions found for this category.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}