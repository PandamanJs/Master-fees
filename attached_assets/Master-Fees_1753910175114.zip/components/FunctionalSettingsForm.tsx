import React, { useState } from 'react';
import Group1000005065 from "../imports/Group1000005065-97-1544";
import { toast } from "sonner@2.0.3";

interface FunctionalSettingsFormProps {
  schoolName: string;
  contactEmail: string;
  phoneNumber: string;
  address: string;
  website: string;
  organizationalCategory: string;
  onSchoolNameChange: (value: string) => void;
  onContactEmailChange: (value: string) => void;
  onPhoneNumberChange: (value: string) => void;
  onAddressChange: (value: string) => void;
  onWebsiteChange: (value: string) => void;
  onOrganizationalCategoryChange: (value: string) => void;
  onPasswordChange: (currentPassword: string, newPassword: string) => void;
  onLogoUpload: (file: File) => void;
  onSave: () => void;
  isUpdating: boolean;
  onSectionChange: (section: string) => void;
}

export default function FunctionalSettingsForm({
  schoolName,
  contactEmail,
  phoneNumber,
  address,
  website,
  organizationalCategory,
  onSchoolNameChange,
  onContactEmailChange,
  onPhoneNumberChange,
  onAddressChange,
  onWebsiteChange,
  onOrganizationalCategoryChange,
  onPasswordChange,
  onLogoUpload,
  onSave,
  isUpdating,
  onSectionChange
}: FunctionalSettingsFormProps) {
  const [activeTab, setActiveTab] = useState('account');
  const [localPassword, setLocalPassword] = useState('xxxxxxxxxxxxx');
  const [isEditingPassword, setIsEditingPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
    onSectionChange(tabId);
    
    const tabLabels = {
      'account': 'Account Info',
      'users': 'Users',
      'banking': 'Banking Info',
      'pricing': 'Pricing Structure',
      'verification': 'Account Verification',
      'billing': 'Subscription & Billing'
    };
    
    const label = tabLabels[tabId as keyof typeof tabLabels] || tabId;
    toast.info(`Viewing ${label} settings`);
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('Logo file size must be less than 5MB');
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        toast.error('Please upload a valid image file');
        return;
      }
      
      onLogoUpload(file);
      toast.success('School logo uploaded successfully');
    }
  };

  const handlePasswordUpdate = () => {
    if (!isEditingPassword) {
      setIsEditingPassword(true);
      setLocalPassword('');
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    if (newPassword.length < 8) {
      toast.error('Password must be at least 8 characters long');
      return;
    }

    onPasswordChange('current', newPassword);
    setIsEditingPassword(false);
    setLocalPassword('xxxxxxxxxxxxx');
    setNewPassword('');
    setConfirmPassword('');
    toast.success('Password updated successfully');
  };

  const handleSaveChanges = () => {
    // Validate required fields
    if (!schoolName.trim()) {
      toast.error('School name is required');
      return;
    }

    if (!contactEmail.trim()) {
      toast.error('Contact email is required');
      return;
    }

    if (!phoneNumber.trim()) {
      toast.error('Phone number is required');
      return;
    }

    onSave();
  };

  return (
    <div className="relative w-full">
      {/* Navigation Tabs */}
      <div className="absolute top-0 left-0 right-0 z-10">
        <div className="flex items-center gap-5 px-6 py-3">
          {[
            { id: 'account', label: 'Account Info' },
            { id: 'users', label: 'Users' },
            { id: 'banking', label: 'Banking Info' },
            { id: 'pricing', label: 'Pricing Structure' },
            { id: 'verification', label: 'Account Verification' },
            { id: 'billing', label: 'Subscription & billing' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              className={`px-4 py-2 text-sm font-medium transition-colors rounded-md ${
                activeTab === tab.id
                  ? 'text-[#025864] bg-white shadow-sm font-bold'
                  : 'text-[#c8ccd3] hover:text-[#025864] hover:bg-gray-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        
        {/* Active tab indicator line */}
        <div className="relative">
          <div className={`absolute h-1 bg-[#3ED4AF] rounded-full transition-all duration-300 ${
            activeTab === 'account' ? 'left-6 w-[110px]' :
            activeTab === 'users' ? 'left-[146px] w-[110px]' :
            activeTab === 'banking' ? 'left-[286px] w-[110px]' :
            activeTab === 'pricing' ? 'left-[426px] w-[165px]' :
            activeTab === 'verification' ? 'left-[611px] w-[165px]' :
            'left-[796px] w-[165px]'
          }`} style={{ top: '-2px' }} />
        </div>
      </div>

      {/* Main Form Container */}
      <div className="mt-16 bg-white rounded-2xl border border-[#e4e7ec] p-6">
        <h2 className="font-['Hanken_Grotesk:Bold',_sans-serif] font-bold text-[#000000] text-[18px] mb-6">
          Account Info
        </h2>
        
        <div className="grid grid-cols-3 gap-9">
          {/* Left Column - Email & Password */}
          <div className="flex flex-col gap-7">
            {/* Organization Email */}
            <div className="flex flex-col gap-2">
              <label className="font-['Hanken_Grotesk:Regular',_sans-serif] text-[#353b45] text-[14px]">
                Organization Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={contactEmail}
                  onChange={(e) => onContactEmailChange(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-white border border-[#bbd2ec] rounded-md text-[#98a2b3] text-[14px] font-['Hanken_Grotesk:Regular',_sans-serif] focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent"
                  placeholder="Enter organization email"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <svg className="w-5 h-5 text-[#667185]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Password */}
            <div className="flex flex-col gap-2">
              <label className="font-['Hanken_Grotesk:Regular',_sans-serif] text-[#353b45] text-[14px]">
                Password
              </label>
              <div className="relative">
                {isEditingPassword ? (
                  <div className="space-y-2">
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full h-10 px-3 py-2 bg-white border border-[#bbd2ec] rounded-md text-[#353b45] text-[14px] font-['Hanken_Grotesk:Regular',_sans-serif] focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent"
                      placeholder="Enter new password"
                    />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full h-10 px-3 py-2 bg-white border border-[#bbd2ec] rounded-md text-[#353b45] text-[14px] font-['Hanken_Grotesk:Regular',_sans-serif] focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent"
                      placeholder="Confirm new password"
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={handlePasswordUpdate}
                        className="px-3 py-1 bg-[#025864] text-white text-xs rounded hover:bg-[#034854] transition-colors"
                      >
                        Update
                      </button>
                      <button
                        onClick={() => {
                          setIsEditingPassword(false);
                          setLocalPassword('xxxxxxxxxxxxx');
                          setNewPassword('');
                          setConfirmPassword('');
                        }}
                        className="px-3 py-1 bg-gray-300 text-gray-700 text-xs rounded hover:bg-gray-400 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={handlePasswordUpdate}
                    className="w-full h-10 px-3 py-2 bg-white border border-[#bbd2ec] rounded-md text-[#98a2b3] text-[14px] font-['Hanken_Grotesk:Regular',_sans-serif] focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent text-left hover:bg-gray-50 transition-colors"
                  >
                    {localPassword}
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                      <svg className="w-5 h-5 text-[#667185]" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </div>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Middle Column - Institution & Logo */}
          <div className="flex flex-col gap-7">
            {/* Institution Name */}
            <div className="flex flex-col gap-2">
              <label className="font-['Hanken_Grotesk:Regular',_sans-serif] text-[#353b45] text-[14px]">
                Name of Institution
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={schoolName}
                  onChange={(e) => onSchoolNameChange(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-white border border-[#bbd2ec] rounded-md text-[#98a2b3] text-[14px] font-['Hanken_Grotesk:Regular',_sans-serif] focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent"
                  placeholder="Enter institution name"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <svg className="w-5 h-5 text-[#667185]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </div>

            {/* School Logo Upload */}
            <div className="flex flex-col gap-2">
              <label className="font-['Hanken_Grotesk:Regular',_sans-serif] text-[#353b45] text-[14px]">
                School Logo Upload
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                <div className="h-[210px] bg-white border border-[#bbd2ec] rounded-md flex items-center justify-center hover:bg-gray-50 transition-colors cursor-pointer">
                  <div className="text-center">
                    <div className="w-10 h-10 mx-auto mb-3 text-[#C3D7EE]">
                      <svg className="w-full h-full" fill="currentColor" viewBox="0 0 40 40">
                        <path fillRule="evenodd" d="M8.333 10A4.17 4.17 0 004.167 14.167v11.666A4.17 4.17 0 008.333 30h23.334a4.17 4.17 0 004.166-4.167V14.167A4.17 4.17 0 0031.667 10H8.333zm0 2.5h23.334a1.67 1.67 0 011.666 1.667v11.666a1.67 1.67 0 01-1.666 1.667H8.333a1.67 1.67 0 01-1.666-1.667V14.167A1.67 1.67 0 018.333 12.5z" clipRule="evenodd" />
                        <path fillRule="evenodd" d="M16.667 18.333a2.5 2.5 0 100-5 2.5 2.5 0 000 5zm0-1.666a.833.833 0 100-1.667.833.833 0 000 1.667z" clipRule="evenodd" />
                        <path fillRule="evenodd" d="M6.667 23.819l4.714-4.714a1.667 1.667 0 012.357 0l8.929 8.928A1.67 1.67 0 0121.488 30H8.333a1.67 1.67 0 01-1.666-1.667v-4.514zm2.5 1.848v.5a1.67 1.67 0 001.666 1.666h9.821L12.5 19.679l-3.333 3.333v2.655z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <p className="text-[#98a2b3] text-sm">Click to upload logo</p>
                    <p className="text-[#98a2b3] text-xs mt-1">PNG, JPG up to 5MB</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Address & Contact */}
          <div className="flex flex-col gap-7">
            {/* Business Address */}
            <div className="flex flex-col gap-2">
              <label className="font-['Hanken_Grotesk:Regular',_sans-serif] text-[#353b45] text-[14px]">
                Business Physical Address
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={address}
                  onChange={(e) => onAddressChange(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-white border border-[#bbd2ec] rounded-md text-[#98a2b3] text-[14px] font-['Hanken_Grotesk:Regular',_sans-serif] focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent"
                  placeholder="Enter business address"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <svg className="w-5 h-5 text-[#667185]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Phone Number */}
            <div className="flex flex-col gap-2">
              <label className="font-['Hanken_Grotesk:Regular',_sans-serif] text-[#353b45] text-[14px]">
                Official Telephone Number
              </label>
              <div className="relative">
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => onPhoneNumberChange(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-white border border-[#bbd2ec] rounded-md text-[#98a2b3] text-[14px] font-['Hanken_Grotesk:Regular',_sans-serif] focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent"
                  placeholder="Enter phone number"
                />
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <svg className="w-5 h-5 text-[#667185]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Organizational Category */}
            <div className="flex flex-col gap-2">
              <label className="font-['Hanken_Grotesk:Regular',_sans-serif] text-[#353b45] text-[14px]">
                Organizational Category
              </label>
              <div className="relative">
                <select
                  value={organizationalCategory}
                  onChange={(e) => onOrganizationalCategoryChange(e.target.value)}
                  className="w-full h-10 px-3 py-2 bg-white border border-[#bbd2ec] rounded-md text-[#98a2b3] text-[14px] font-['Hanken_Grotesk:Regular',_sans-serif] focus:outline-none focus:ring-2 focus:ring-[#025864] focus:border-transparent appearance-none cursor-pointer"
                >
                  <option value="Primary School">Primary School</option>
                  <option value="Secondary School">Secondary School</option>
                  <option value="High School">High School</option>
                  <option value="University">University</option>
                  <option value="College">College</option>
                  <option value="Vocational Institute">Vocational Institute</option>
                  <option value="Training Center">Training Center</option>
                </select>
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                  <svg className="w-5 h-5 text-[#667185]" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="mt-8 flex items-center justify-between">
          <div className="text-sm text-gray-500">
            Fields marked with * are required
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => {
                toast.info('Reset feature will be available in the next update');
              }}
              className="px-6 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors font-['Hanken_Grotesk:Medium',_sans-serif] text-[14px]"
              disabled={isUpdating}
            >
              Reset
            </button>
            <button
              onClick={handleSaveChanges}
              disabled={isUpdating}
              className="px-6 py-2 bg-[#025864] text-white rounded-md hover:bg-[#034854] transition-colors font-['Hanken_Grotesk:Medium',_sans-serif] text-[14px] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}