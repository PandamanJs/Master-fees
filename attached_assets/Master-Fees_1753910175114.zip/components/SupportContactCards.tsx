import { toast } from "sonner@2.0.3";

export default function SupportContactCards() {
  const contactMethods = [
    {
      id: 'live-chat',
      title: 'Live Chat',
      description: 'Get instant help from our support team',
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-3.582 8-8 8a8.959 8.959 0 01-4.906-1.436L3 21l2.436-5.094A8.959 8.959 0 013 12c0-4.418 3.582-8 8-8s8 3.582 8 8z" />
        </svg>
      ),
      availability: 'Available now',
      status: 'online',
      action: () => toast.info('Live chat will be available in the next update')
    },
    {
      id: 'email',
      title: 'Email Support',
      description: 'Send us a detailed message',
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 3.26a2 2 0 001.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
      availability: 'Response within 2 hours',
      status: 'available',
      action: () => window.open('mailto:support@master-fees.com', '_blank')
    },
    {
      id: 'phone',
      title: 'Phone Support',
      description: 'Speak directly with our experts',
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
        </svg>
      ),
      availability: 'Mon-Fri, 8AM-6PM',
      status: 'available',
      action: () => window.open('tel:+260-XXX-XXXX', '_blank')
    },
    {
      id: 'remote',
      title: 'Remote Assistance',
      description: 'Screen sharing for complex issues',
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
      availability: 'By appointment',
      status: 'appointment',
      action: () => toast.info('Remote assistance can be scheduled by contacting support')
    }
  ];

  return (
    <div className="bg-white py-12">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-2xl text-[#1f1f20] mb-4">
            Contact Our Support Team
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Choose the best way to reach us. Our dedicated support team is here to help you succeed with Master-Fees.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {contactMethods.map((method) => (
            <div
              key={method.id}
              className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all hover:border-[#025864] cursor-pointer group"
              onClick={method.action}
            >
              <div className={`inline-flex p-3 rounded-lg mb-4 ${
                method.status === 'online' ? 'bg-green-100 text-green-600' :
                method.status === 'available' ? 'bg-blue-100 text-blue-600' :
                'bg-orange-100 text-orange-600'
              } group-hover:scale-110 transition-transform`}>
                {method.icon}
              </div>
              
              <h3 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] text-lg mb-2">
                {method.title}
              </h3>
              
              <p className="text-gray-600 text-sm mb-4">
                {method.description}
              </p>
              
              <div className="flex items-center justify-between">
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                  method.status === 'online' ? 'bg-green-100 text-green-700' :
                  method.status === 'available' ? 'bg-blue-100 text-blue-700' :
                  'bg-orange-100 text-orange-700'
                }`}>
                  <div className={`w-2 h-2 rounded-full mr-1 ${
                    method.status === 'online' ? 'bg-green-500 animate-pulse' :
                    method.status === 'available' ? 'bg-blue-500' :
                    'bg-orange-500'
                  }`}></div>
                  {method.availability}
                </span>
                
                <svg className="w-4 h-4 text-gray-400 group-hover:text-[#025864] transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}