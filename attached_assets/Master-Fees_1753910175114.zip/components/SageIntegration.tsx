import { useState } from 'react';
import { toast } from "sonner@2.0.3";

interface SageIntegrationProps {
  schoolId: string;
  onConnectionChange: (connected: boolean) => void;
}

export default function SageIntegration({ schoolId, onConnectionChange }: SageIntegrationProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsConnected(true);
      onConnectionChange(true);
      toast.success("Sage Business Cloud connected! Enterprise accounting features are now available.");
    } catch (error) {
      toast.error("Failed to connect to Sage. Please verify your enterprise credentials.");
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      setIsConnected(false);
      onConnectionChange(false);
      toast.info("Sage integration disconnected");
    } catch (error) {
      toast.error("Failed to disconnect Sage integration");
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#00a651] rounded-lg flex items-center justify-center">
            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19.5 3h-15A1.5 1.5 0 003 4.5v15A1.5 1.5 0 004.5 21h15a1.5 1.5 0 001.5-1.5v-15A1.5 1.5 0 0019.5 3zM12 18c-3.3 0-6-2.7-6-6s2.7-6 6-6 6 2.7 6 6-2.7 6-6 6z"/>
              <circle cx="12" cy="12" r="3"/>
            </svg>
          </div>
          <div>
            <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-lg mb-1">
              Sage Business Cloud
            </h3>
            <p className="text-gray-600 text-sm mb-2">
              Enterprise-grade accounting and financial management platform
            </p>
            <div className="flex items-center gap-2">
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                isConnected 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {isConnected ? 'Connected' : 'Not Connected'}
              </span>
              <span className="text-gray-400 text-xs">•</span>
              <span className="text-gray-500 text-xs">Enterprise Accounting</span>
            </div>
          </div>
        </div>
        <div>
          {isConnected ? (
            <button
              onClick={handleDisconnect}
              className="bg-red-50 text-red-700 px-4 py-2 rounded-md hover:bg-red-100 transition-colors text-sm"
            >
              Disconnect
            </button>
          ) : (
            <button
              onClick={handleConnect}
              disabled={isConnecting}
              className="bg-[#00a651] text-white px-4 py-2 rounded-md hover:bg-[#008f47] transition-colors text-sm disabled:opacity-50"
            >
              {isConnecting ? 'Connecting...' : 'Connect'}
            </button>
          )}
        </div>
      </div>
      
      {isConnected && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-[#00a651]">AI</div>
              <div className="text-xs text-gray-500">Insights</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">API</div>
              <div className="text-xs text-gray-500">First</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">Global</div>
              <div className="text-xs text-gray-500">Scale</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}