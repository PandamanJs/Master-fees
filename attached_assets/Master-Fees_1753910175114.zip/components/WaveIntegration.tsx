import { useState } from 'react';
import { toast } from "sonner@2.0.3";

interface WaveIntegrationProps {
  schoolId: string;
  onConnectionChange: (connected: boolean) => void;
}

export default function WaveIntegration({ schoolId, onConnectionChange }: WaveIntegrationProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsConnected(true);
      onConnectionChange(true);
      toast.success("Wave Accounting connected! Your financial data will sync automatically.");
    } catch (error) {
      toast.error("Failed to connect to Wave. Please check your account credentials.");
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      setIsConnected(false);
      onConnectionChange(false);
      toast.info("Wave Accounting integration disconnected");
    } catch (error) {
      toast.error("Failed to disconnect Wave integration");
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#2d77ff] rounded-lg flex items-center justify-center">
            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 9.94 5.16-.2 9-4.39 9-9.94V7l-10-5z"/>
            </svg>
          </div>
          <div>
            <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-lg mb-1">
              Wave Accounting
            </h3>
            <p className="text-gray-600 text-sm mb-2">
              Free accounting software for small business financial management
            </p>
            <div className="flex items-center gap-2">
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                isConnected 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {isConnected ? 'Connected' : 'Not Connected'}
              </span>
              <span className="text-gray-400 text-xs">•</span>
              <span className="text-gray-500 text-xs">Free Accounting</span>
            </div>
          </div>
        </div>
        <div>
          {isConnected ? (
            <button
              onClick={handleDisconnect}
              className="bg-red-50 text-red-700 px-4 py-2 rounded-md hover:bg-red-100 transition-colors text-sm"
            >
              Disconnect
            </button>
          ) : (
            <button
              onClick={handleConnect}
              disabled={isConnecting}
              className="bg-[#2d77ff] text-white px-4 py-2 rounded-md hover:bg-[#1e5bff] transition-colors text-sm disabled:opacity-50"
            >
              {isConnecting ? 'Connecting...' : 'Connect'}
            </button>
          )}
        </div>
      </div>
      
      {isConnected && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-[#2d77ff]">Free</div>
              <div className="text-xs text-gray-500">For Small Business</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">Auto</div>
              <div className="text-xs text-gray-500">Invoicing</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">Tax</div>
              <div className="text-xs text-gray-500">Ready</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}