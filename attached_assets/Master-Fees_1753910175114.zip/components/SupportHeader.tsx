import { useState } from 'react';
import { toast } from "sonner@2.0.3";

interface SupportHeaderProps {
  onSearch: (query: string) => void;
}

export default function SupportHeader({ onSearch }: SupportHeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery.trim());
      toast.info(`Searching for: ${searchQuery.trim()}`);
    }
  };

  return (
    <div className="bg-gradient-to-r from-[#003049] to-[#025864] text-white py-12 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-3xl mb-4">
          Master-Fees Support Center
        </h1>
        <p className="text-blue-100 text-lg mb-8 max-w-2xl mx-auto">
          Get help with your school fee management system. Find answers, contact support, and access resources.
        </p>
        
        {/* Search Bar */}
        <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for help articles, features, or common questions..."
              className="w-full px-6 py-4 rounded-lg text-gray-900 text-base placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
            <button
              type="submit"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-[#025864] text-white px-6 py-2 rounded-md hover:bg-[#003049] transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
          </div>
        </form>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-2xl font-bold mb-1">24/7</div>
            <div className="text-sm text-blue-100">Support Available</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-2xl font-bold mb-1">2 min</div>
            <div className="text-sm text-blue-100">Avg Response Time</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="text-2xl font-bold mb-1">98%</div>
            <div className="text-sm text-blue-100">Customer Satisfaction</div>
          </div>
        </div>
      </div>
    </div>
  );
}