import { useState } from 'react';
import { toast } from "sonner@2.0.3";

interface PayPalIntegrationProps {
  schoolId: string;
  onConnectionChange: (connected: boolean) => void;
}

export default function PayPalIntegration({ schoolId, onConnectionChange }: PayPalIntegrationProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsConnected(true);
      onConnectionChange(true);
      toast.success("PayPal integration connected! Parents can now pay fees using PayPal.");
    } catch (error) {
      toast.error("Failed to connect to PayPal. Please verify your merchant account details.");
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    try {
      setIsConnected(false);
      onConnectionChange(false);
      toast.info("PayPal integration disconnected");
    } catch (error) {
      toast.error("Failed to disconnect PayPal integration");
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#0070ba] rounded-lg flex items-center justify-center">
            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106zm14.146-14.42a.3.3 0 0 0-.294-.248h-.003c-.165 0-.296.126-.31.29-.943 5.04-4.194 6.75-8.297 6.75h-2.19c-.524 0-.968.382-1.05.9l-.69 4.37-.198 1.26c-.067.425.263.808.695.808h4.09c.459 0 .849-.334.922-.788l.038-.204.73-4.63.047-.254c.072-.454.462-.788.921-.788h.58c3.606 0 6.43-1.466 7.253-5.705.344-1.77.166-3.25-.698-4.298-.394-.477-.915-.838-1.539-1.073z"/>
            </svg>
          </div>
          <div>
            <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-lg mb-1">
              PayPal
            </h3>
            <p className="text-gray-600 text-sm mb-2">
              Accept payments via PayPal for convenient parent transactions
            </p>
            <div className="flex items-center gap-2">
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                isConnected 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {isConnected ? 'Connected' : 'Not Connected'}
              </span>
              <span className="text-gray-400 text-xs">•</span>
              <span className="text-gray-500 text-xs">Payment Processing</span>
            </div>
          </div>
        </div>
        <div>
          {isConnected ? (
            <button
              onClick={handleDisconnect}
              className="bg-red-50 text-red-700 px-4 py-2 rounded-md hover:bg-red-100 transition-colors text-sm"
            >
              Disconnect
            </button>
          ) : (
            <button
              onClick={handleConnect}
              disabled={isConnecting}
              className="bg-[#0070ba] text-white px-4 py-2 rounded-md hover:bg-[#005ea6] transition-colors text-sm disabled:opacity-50"
            >
              {isConnecting ? 'Connecting...' : 'Connect'}
            </button>
          )}
        </div>
      </div>
      
      {isConnected && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-[#0070ba]">2.9%</div>
              <div className="text-xs text-gray-500">+ $0.30 Fee</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">200+</div>
              <div className="text-xs text-gray-500">Markets</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">Buyer</div>
              <div className="text-xs text-gray-500">Protection</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}