import { toast } from "sonner@2.0.3";

export default function SupportResources() {
  const resources = [
    {
      id: 'getting-started',
      title: 'Getting Started Guide',
      description: 'Complete setup guide for new schools',
      type: 'PDF Guide',
      size: '2.3 MB',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      ),
      downloads: 1247
    },
    {
      id: 'video-tutorials',
      title: 'Video Tutorial Series',
      description: 'Step-by-step video walkthroughs',
      type: 'Video Playlist',
      size: '12 videos',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1.586a1 1 0 01.707.293l2.414 2.414a1 1 0 00.707.293H15M9 10V9a2 2 0 012-2h2a2 2 0 012 2v1M9 10v5a2 2 0 002 2h2a2 2 0 002-2v-5m-6 0h6" />
        </svg>
      ),
      downloads: 892
    },
    {
      id: 'api-docs',
      title: 'API Documentation',
      description: 'Technical documentation for developers',
      type: 'Online Docs',
      size: 'Web Portal',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
        </svg>
      ),
      downloads: 345
    },
    {
      id: 'csv-templates',
      title: 'CSV Import Templates',
      description: 'Pre-formatted templates for bulk data import',
      type: 'Excel Files',
      size: '156 KB',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
      ),
      downloads: 543
    },
    {
      id: 'troubleshooting',
      title: 'Troubleshooting Guide',
      description: 'Common issues and solutions',
      type: 'PDF Guide',
      size: '1.8 MB',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>
      ),
      downloads: 678
    },
    {
      id: 'mobile-app',
      title: 'Mobile App Guide',
      description: 'Using Master-Fees on mobile devices',
      type: 'PDF Guide',
      size: '1.2 MB',
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
      ),
      downloads: 234
    }
  ];

  const handleDownload = (resource: typeof resources[0]) => {
    toast.success(`Downloading ${resource.title}...`);
    // In production, this would trigger an actual download
    console.log(`Downloading resource: ${resource.id}`);
  };

  const handleViewOnline = (resource: typeof resources[0]) => {
    if (resource.type === 'Online Docs') {
      toast.info('Opening API documentation in new tab...');
      // In production, this would open the actual documentation
    } else if (resource.type === 'Video Playlist') {
      toast.info('Opening video tutorials...');
      // In production, this would open video platform
    } else {
      handleDownload(resource);
    }
  };

  return (
    <div className="bg-white py-12">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-2xl text-[#1f1f20] mb-4">
            Resources & Downloads
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Access helpful guides, templates, and documentation to get the most out of Master-Fees.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource) => (
            <div
              key={resource.id}
              className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-all hover:border-[#025864] group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-[#025864]/10 text-[#025864] rounded-lg group-hover:bg-[#025864] group-hover:text-white transition-colors">
                    {resource.icon}
                  </div>
                  <div>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-600">
                      {resource.type}
                    </span>
                  </div>
                </div>
              </div>

              <h3 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] text-lg mb-2">
                {resource.title}
              </h3>
              
              <p className="text-gray-600 text-sm mb-4">
                {resource.description}
              </p>
              
              <div className="flex items-center justify-between mb-4">
                <div className="text-sm text-gray-500">
                  Size: {resource.size}
                </div>
                <div className="text-sm text-gray-500">
                  {resource.downloads.toLocaleString()} downloads
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => handleViewOnline(resource)}
                  className="flex-1 bg-[#025864] text-white py-2 px-4 rounded-md hover:bg-[#003049] transition-colors text-sm"
                >
                  {resource.type === 'Online Docs' ? 'View Online' : 
                   resource.type === 'Video Playlist' ? 'Watch Videos' : 
                   'Download'}
                </button>
                {resource.type !== 'Online Docs' && resource.type !== 'Video Playlist' && (
                  <button
                    onClick={() => toast.info('Quick preview will be available in the next update')}
                    className="px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
                    title="Quick Preview"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Additional Help Section */}
        <div className="mt-12 bg-gradient-to-r from-[#f8f9fa] to-[#e9ecef] rounded-xl p-8 text-center">
          <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-xl text-[#1f1f20] mb-4">
            Need More Help?
          </h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            Can't find what you're looking for? Our support team is ready to help you with personalized assistance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => toast.info('Contact form will be available in the next update')}
              className="bg-[#025864] text-white px-6 py-3 rounded-lg hover:bg-[#003049] transition-colors"
            >
              Contact Support Team
            </button>
            <button
              onClick={() => toast.info('Training request feature will be available in the next update')}
              className="border border-[#025864] text-[#025864] px-6 py-3 rounded-lg hover:bg-[#025864] hover:text-white transition-colors"
            >
              Request Training Session
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}