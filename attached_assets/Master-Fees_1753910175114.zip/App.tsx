import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import svgPaths from "./imports/svg-2g3736nywj";
import { toast } from "sonner@2.0.3";
import { api } from "./utils/supabase/api";
import { useRealTimeNotifications } from "./utils/hooks/useRealTimeNotifications";
import Group1000005059 from "./imports/Group1000005059";
import Frame1707478532 from "./imports/Frame1707478532";
import Frame1707478528 from "./imports/Frame1707478528";
import Group1000005071 from "./imports/Group1000005071";
import Group1000005071New from "./imports/Group1000005071-85-572";
import FeeMasterLoginPage from "./imports/FeeMasterLoginPage-62-2995";
import OnboardingPage from "./components/OnboardingPage";
import DetailedOnboardingPage from "./components/DetailedOnboardingPage";
import FinalOnboardingPage from "./components/FinalOnboardingPage";
import PricingStructurePage from "./components/PricingStructurePage";
import ClassSelectionPage from "./components/ClassSelectionPage";
import ProductGroupPage from "./components/ProductGroupPage";
import SignupPage from "./components/SignupPage";
import ForgotPasswordPage from "./components/ForgotPasswordPage";
import ResetPasswordPage from "./components/ResetPasswordPage";
import UserManagement from "./imports/UserManagement";
import Frame1707478669 from "./imports/Frame1707478669";
import Frame1707478670 from "./imports/Frame1707478670";
import Frame1707478602 from "./imports/Frame1707478528-42-1664";
import PaginationContainer from "./imports/PaginationContainer";
import Frame11 from "./imports/Frame11";
import Checkbox from "./imports/Checkbox-42-1932";
import Tasks from "./imports/Tasks-46-578";
import Frame1707478755 from "./imports/Frame1707478755";
import Frame1707478757 from "./imports/Frame1707478757";
import Frame1707478770 from "./imports/Frame1707478770";
import Frame1707478778 from "./imports/Frame1707478778";
import Frame1707478778New from "./imports/Frame1707478778-62-2031";
import Group1000005064 from "./imports/Group1000005064";
import Group1000005058 from "./imports/Group1000005058";
import Group1000005058New from "./imports/Group1000005058-62-1905";
import Group1000005064Wallet from "./imports/Group1000005064-60-1453";
import Group1000005063 from "./imports/Group1000005063";
import ConnectionsContainer from "./imports/ConnectionsContainer";
import FunctionalSettingsForm from "./components/FunctionalSettingsForm";
import Group1000005066 from "./imports/Group1000005066";
import QuickBooksIntegration from "./components/QuickBooksIntegration";
import StripeIntegration from "./components/StripeIntegration";
import XeroIntegration from "./components/XeroIntegration";
import GoogleWorkspaceIntegration from "./components/GoogleWorkspaceIntegration";
import SlackIntegration from "./components/SlackIntegration";
import PayPalIntegration from "./components/PayPalIntegration";
import MPesaIntegration from "./components/MPesaIntegration";
import WaveIntegration from "./components/WaveIntegration";
import SageIntegration from "./components/SageIntegration";
import SupportHeader from "./components/SupportHeader";
import SupportContactCards from "./components/SupportContactCards";
import SupportFAQ from "./components/SupportFAQ";
import SupportResources from "./components/SupportResources";
import LogoutConfirmationModal from "./components/LogoutConfirmationModal";
import Frame1707478525 from "./imports/Frame1707478525";
import Frame1707478519 from "./imports/Frame1707478519";
import Group1000005072 from "./imports/Group1000005072";

interface NavItem {
  id: string;
  label: string;
  icon: string;
  category: 'general' | 'support';
}

interface FormData {
  schoolName: string;
  institutionType: string;
  country: string;
  state: string;
  town: string;
}

interface ExtendedFormData {
  schoolName: string;
  institutionType: string;
  country: string;
  state: string;
  town: string;
  schoolEmail: string;
  contactNumbers: string;
  physicalAddress: string;
  schoolCategories: string;
  schoolLogo: File | null;
}

interface CompletePricingData {
  schoolName: string;
  institutionType: string;
  country: string;
  state: string;
  town: string;
  schoolEmail: string;
  contactNumbers: string;
  physicalAddress: string;
  schoolCategories: string;
  schoolLogo: File | null;
  selectedGrades: string[];
  classesPerGrade: number;
  exceptions: string;
}

interface ClassSelectionData {
  schoolName: string;
  institutionType: string;
  country: string;
  state: string;
  town: string;
  schoolEmail: string;
  contactNumbers: string;
  physicalAddress: string;
  schoolCategories: string;
  schoolLogo: File | null;
  selectedGrades: string[];
  classesPerGrade: number;
  exceptions: string;
  selectedClasses: string[];
}

interface ProductGroup {
  id: string;
  name: string;
  classes: string[];
}

interface FinalOnboardingData {
  schoolName: string;
  institutionType: string;
  country: string;
  state: string;
  town: string;
  schoolEmail: string;
  contactNumbers: string;
  physicalAddress: string;
  schoolCategories: string;
  schoolLogo: File | null;
  selectedGrades: string[];
  classesPerGrade: number;
  exceptions: string;
  selectedClasses: string[];
  productGroups: ProductGroup[];
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'success' | 'error';
  timestamp: string;
  read: boolean;
  metadata?: {
    amount?: number;
    studentName?: string;
    term?: string;
  };
}

interface DashboardMetrics {
  totalStudents: number;
  totalRevenue: number;
  outstandingFees: number;
  collectionRate: number;
  overduePayments: number;
  newEnrollments: number;
  totalTransactions?: number;
  pendingTasks?: number;
  completedTasks?: number;
  walletBalance?: number;
  monthlyGrowth?: number;
  activeUsers?: number;
}

interface SessionData {
  schoolId: string;
  schoolName: string;
  accessToken: string;
  loginTime: number;
  keepLoggedIn: boolean;
}

interface TransactionData {
  id: string;
  studentName: string;
  class: string;
  feeType: string;
  amount: number;
  status: 'paid' | 'pending' | 'overdue';
  dueDate: string;
  paymentDate?: string;
  term: string;
}

interface CustomerData {
  totalCustomers: number;
  activeCustomers: number;
  newCustomersThisMonth: number;
  customerGrowthRate: number;
  averagePaymentTime: number;
}

// Session management constants
const SESSION_KEY = 'master_fees_session';
const SESSION_DURATION = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

function Dashboard({ onLogout, schoolName, schoolId }: { onLogout: () => void, schoolName: string, schoolId: string }) {
  const [activeNavItem, setActiveNavItem] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState('Term 2');
  const [selectedTransactionTerm, setSelectedTransactionTerm] = useState('Term 2');
  const [selectedYear, setSelectedYear] = useState('2025');
  const [loading, setLoading] = useState(true);
  const [isLoadingAction, setIsLoadingAction] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [termMetrics, setTermMetrics] = useState<{[key: string]: {revenue: number, balance: number, outstanding: number}}>({});
  const [loadingTermMetrics, setLoadingTermMetrics] = useState(false);
  const [showLogoutConfirmation, setShowLogoutConfirmation] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  // Settings state management
  const [settingsState, setSettingsState] = useState({
    // Account settings
    schoolProfile: {
      schoolName,
      schoolId,
      contactEmail: 'admin@twalumbu.edu.zm',
      phoneNumber: '+260-XXX-XXXX',
      address: 'Lusaka, Zambia',
      website: 'www.twalumbu.edu.zm',
      logo: null as File | null,
      timezone: 'Africa/Lusaka',
      currency: 'ZMW',
      language: 'English'
    },
    
    // Notification preferences
    notifications: {
      emailNotifications: true,
      smsNotifications: false,
      pushNotifications: true,
      paymentAlerts: true,
      overdueReminders: true,
      systemUpdates: true,
      weeklyReports: true,
      monthlyStatements: false
    },
    
    // Security settings
    security: {
      twoFactorAuth: false,
      sessionTimeout: 24, // hours
      passwordRequirements: 'medium', // low, medium, high
      apiAccess: false,
      auditLogs: true,
      loginNotifications: true,
      ipRestrictions: false,
      allowedIPs: ''
    },
    
    // System preferences
    system: {
      autoBackup: true,
      backupFrequency: 'daily', // daily, weekly, monthly
      dataRetention: 365, // days
      maintenanceWindow: '02:00-04:00',
      systemTheme: 'light', // light, dark, auto
      compactMode: false,
      advancedFeatures: true,
      debugMode: false
    },
    
    // Integration settings
    integrations: {
      quickbooksEnabled: false,
      stripeEnabled: false,
      mpesaEnabled: false,
      emailProvider: 'default',
      smsProvider: 'default',
      storageProvider: 'default'
    },
    
    // Loading and action states
    isUpdating: false,
    lastUpdated: new Date(),
    activeSection: 'account', // account, notifications, security, system, integrations
    searchQuery: '',
    isDirty: false // tracks if there are unsaved changes
  });

  // Quick access to settings values
  const {
    schoolProfile,
    notifications,
    security,
    system,
    integrations,
    isUpdating,
    activeSection,
    searchQuery,
    isDirty
  } = settingsState;

  // Unified Customer Management State
  const [customerManagement, setCustomerManagement] = useState({
    // Search and filter states
    searchQuery: '',
    classFilter: null as string | null,
    statusFilter: null as string | null,
    dateRangeFilter: null as string | null,
    sortConfig: null as { column: string; direction: 'asc' | 'desc' } | null,
    
    // Pagination states
    currentPage: 1,
    itemsPerPage: 10,
    
    // Data states
    filteredData: [] as TransactionData[],
    selectedCustomers: new Set<string>(),
    
    // Loading states
    isFiltering: false,
    isPaginating: false,
    isBulkActionInProgress: false,
    
    // Action states
    lastActionType: null as string | null,
    lastActionTimestamp: null as Date | null,
  });

  // Quick access to frequently used values
  const {
    searchQuery: customerSearchQuery,
    classFilter: customerClassFilter,
    statusFilter: customerStatusFilter,
    dateRangeFilter: customerDateRangeFilter,
    sortConfig: customerSort,
    currentPage,
    itemsPerPage,
    filteredData: filteredCustomerData,
    selectedCustomers,
    isFiltering,
    isPaginating,
    isBulkActionInProgress
  } = customerManagement;

  // Extended data states for functional statistics
  const [transactionData, setTransactionData] = useState<TransactionData[]>([]);
  const [customerData, setCustomerData] = useState<CustomerData>({
    totalCustomers: 0,
    activeCustomers: 0,
    newCustomersThisMonth: 0,
    customerGrowthRate: 0,
    averagePaymentTime: 0
  });

  // Data from Supabase
  const [dashboardMetrics, setDashboardMetrics] = useState<DashboardMetrics>({
    totalStudents: 0,
    totalRevenue: 0,
    outstandingFees: 0,
    collectionRate: 0,
    overduePayments: 0,
    newEnrollments: 0,
    totalTransactions: 0,
    pendingTasks: 0,
    completedTasks: 0,
    walletBalance: 0,
    monthlyGrowth: 0,
    activeUsers: 0
  });

  // Real-time notifications hook
  const {
    notifications: realtimeNotifications,
    unreadCount,
    isConnected,
    markAsRead,
    markAllAsRead,
    startDemoEvents,
    stopDemoEvents,
    simulatePayment,
    simulateEnrollment
  } = useRealTimeNotifications({
    schoolId,
    onNewNotification: (notification) => {
      // Auto-refresh dashboard metrics when payments are received
      if (notification.type === 'success' && notification.metadata?.amount) {
        setTimeout(() => {
          loadDashboardData();
          loadTransactionData();
          loadCustomerData();
        }, 1000);
      }
    },
    onPaymentReceived: (payment) => {
      // Update metrics immediately with the new payment
      setDashboardMetrics(prev => ({
        ...prev,
        totalRevenue: prev.totalRevenue + payment.amount,
        outstandingFees: Math.max(0, prev.outstandingFees - payment.amount),
        totalTransactions: (prev.totalTransactions || 0) + 1,
        walletBalance: (prev.walletBalance || 0) + payment.amount
      }));
      
      // Update term-specific metrics if payment relates to current term
      if (payment.term && payment.term === selectedTransactionTerm) {
        setTermMetrics(prev => ({
          ...prev,
          [payment.term]: {
            revenue: (prev[payment.term]?.revenue || 0) + payment.amount,
            balance: Math.max(0, ((prev[payment.term]?.revenue || 0) + payment.amount) - (prev[payment.term]?.outstanding || 0)),
            outstanding: Math.max(0, (prev[payment.term]?.outstanding || 0) - payment.amount)
          }
        }));
      }
      
      // Update transaction data
      setTransactionData(prev => [
        {
          id: `payment_${Date.now()}`,
          studentName: payment.studentName || 'Unknown Student',
          class: payment.class || 'N/A',
          feeType: payment.feeType || 'General Fee',
          amount: payment.amount,
          status: 'paid',
          dueDate: new Date().toISOString(),
          paymentDate: new Date().toISOString(),
          term: payment.term || selectedTransactionTerm
        },
        ...prev
      ].slice(0, 100)); // Keep only last 100 transactions
      
      setLastRefresh(new Date());
    },
    onStudentEnrolled: (student) => {
      // Update customer count immediately
      setDashboardMetrics(prev => ({
        ...prev,
        totalStudents: prev.totalStudents + 1,
        newEnrollments: prev.newEnrollments + 1,
        activeUsers: (prev.activeUsers || 0) + 1
      }));
      
      // Update customer data
      setCustomerData(prev => ({
        ...prev,
        totalCustomers: prev.totalCustomers + 1,
        activeCustomers: prev.activeCustomers + 1,
        newCustomersThisMonth: prev.newCustomersThisMonth + 1
      }));
      
      setLastRefresh(new Date());
    }
  });

  const generalNavItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard', category: 'general' },
    { id: 'transactions', label: 'Transactions', icon: 'receipt', category: 'general' },
    { id: 'customer-management', label: 'Customer Management', icon: 'user', category: 'general' },
    { id: 'tasks', label: 'Tasks', icon: 'magic', category: 'general' },
    { id: 'wallet', label: 'Wallet', icon: 'wallet', category: 'general' },
  ];

  const supportNavItems: NavItem[] = [
    { id: 'integrations', label: 'Integrations', icon: 'receipt', category: 'support' },
    { id: 'customer-care', label: 'Support Center', icon: 'grammerly', category: 'support' },
    { id: 'settings', label: 'Settings', icon: 'setting', category: 'support' },
    { id: 'logout', label: 'Logout', icon: 'logout', category: 'support' },
  ];

  // Load dashboard data on mount
  useEffect(() => {
    loadDashboardData();
    loadTransactionData();
    loadCustomerData();
  }, [schoolId]);

  // Unified customer data processing
  useEffect(() => {
    if (transactionData.length > 0 || customerSearchQuery || customerClassFilter || customerStatusFilter || customerDateRangeFilter || customerSort) {
      processCustomerData();
    }
  }, [transactionData, customerSearchQuery, customerClassFilter, customerStatusFilter, customerDateRangeFilter, customerSort]);

  // Load term-specific metrics when term changes
  useEffect(() => {
    if (schoolId && selectedTransactionTerm && !loading) {
      loadTermMetrics(selectedTransactionTerm);
    }
  }, [schoolId, selectedTransactionTerm, loading]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Load comprehensive metrics with extended data
      const metricsResponse = await api.getMetrics(schoolId);
      if (metricsResponse.success && metricsResponse.data) {
        // Calculate additional metrics from base data
        const baseMetrics = metricsResponse.data;
        const extendedMetrics = {
          ...baseMetrics,
          totalTransactions: Math.floor(baseMetrics.totalRevenue / 1500), // Estimate based on average fee
          pendingTasks: Math.floor(baseMetrics.overduePayments / 10), // Estimate pending tasks
          completedTasks: Math.floor(baseMetrics.totalStudents * 0.8), // 80% completion rate
          walletBalance: baseMetrics.totalRevenue, // Available balance equals total revenue
          monthlyGrowth: baseMetrics.collectionRate > 80 ? Math.random() * 15 + 5 : Math.random() * 10, // Growth based on collection rate
          activeUsers: Math.floor(baseMetrics.totalStudents * 0.85) // 85% of students are active
        };
        
        setDashboardMetrics(extendedMetrics);
      } else {
        console.warn('Failed to load metrics:', metricsResponse.error);
        toast.error('Unable to load dashboard metrics. Please refresh the page.');
      }

      // If no data exists, generate sample data for new schools
      if (metricsResponse.success && metricsResponse.data?.totalStudents === 0) {
        await initializeSchoolData();
      }

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      toast.error('Unable to connect to the server. Please check your internet connection.');
    } finally {
      setLoading(false);
    }
  };

  const loadTransactionData = async () => {
    try {
      const response = await api.getTransactions(schoolId);
      if (response.success && response.data && Array.isArray(response.data)) {
        // Ensure all transaction objects have required properties
        const validTransactions = response.data.map(transaction => ({
          id: transaction.id || `txn_${Date.now()}_${Math.random()}`,
          studentName: transaction.studentName || 'Unknown Student',
          class: transaction.class || 'N/A',
          feeType: transaction.feeType || 'General Fee',
          amount: Number(transaction.amount) || 0,
          status: transaction.status || 'pending',
          dueDate: transaction.dueDate || new Date().toISOString(),
          paymentDate: transaction.paymentDate,
          term: transaction.term || 'Term 2'
        }));
        setTransactionData(validTransactions);
      } else {
        // Generate sample transaction data if none exists
        const sampleTransactions: TransactionData[] = [
          {
            id: 'txn_001',
            studentName: 'Alice Johnson',
            class: 'Grade 7A',
            feeType: 'Tuition Fees',
            amount: 2500,
            status: 'paid',
            dueDate: '2025-01-15T00:00:00Z',
            paymentDate: '2025-01-10T00:00:00Z',
            term: 'Term 2'
          },
          {
            id: 'txn_002',
            studentName: 'Bob Smith',
            class: 'Grade 8B',
            feeType: 'Transport Fees',
            amount: 500,
            status: 'pending',
            dueDate: '2025-01-20T00:00:00Z',
            term: 'Term 2'
          },
          {
            id: 'txn_003',
            studentName: 'Carol Williams',
            class: 'Grade 6A',
            feeType: 'Library Fees',
            amount: 200,
            status: 'overdue',
            dueDate: '2025-01-01T00:00:00Z',
            term: 'Term 2'
          }
        ];
        setTransactionData(sampleTransactions);
      }
    } catch (error) {
      console.error('Error loading transaction data:', error);
      // Set empty array as fallback to prevent undefined errors
      setTransactionData([]);
      toast.error('Unable to load customer transaction data. Please refresh the page.');
    }
  };

  const loadCustomerData = async () => {
    try {
      const response = await api.getCustomerMetrics(schoolId);
      if (response.success && response.data) {
        setCustomerData(response.data);
        console.log('✅ Customer metrics loaded successfully');
      } else {
        console.warn('Failed to load customer metrics, using calculated fallback:', response.error);
        // Calculate customer metrics from dashboard metrics
        const totalCustomers = dashboardMetrics.totalStudents || 0;
        setCustomerData({
          totalCustomers,
          activeCustomers: Math.floor(totalCustomers * 0.85),
          newCustomersThisMonth: dashboardMetrics.newEnrollments || 0,
          customerGrowthRate: Math.random() * 20 + 5, // 5-25% growth rate
          averagePaymentTime: Math.random() * 10 + 3 // 3-13 days average
        });
      }
    } catch (error) {
      console.error('Error loading customer data:', error);
      // Provide fallback customer data to prevent UI errors
      setCustomerData({
        totalCustomers: dashboardMetrics.totalStudents || 147,
        activeCustomers: Math.floor((dashboardMetrics.totalStudents || 147) * 0.85),
        newCustomersThisMonth: dashboardMetrics.newEnrollments || 7,
        customerGrowthRate: 12.5,
        averagePaymentTime: 6.2
      });
      toast.error('Unable to load customer analytics. Please check your connection and try refreshing the page.');
    }
  };

  const initializeSchoolData = async () => {
    try {
      toast.info('Setting up your school account...');
      
      const result = await api.generateSampleData(schoolId);
      
      if (result.success) {
        toast.success('School account setup completed successfully!');
        
        // Add welcome notification
        await api.createNotification(schoolId, {
          title: 'Welcome to Master-Fees',
          message: 'Your school account has been successfully configured. You can now start managing customer fees and tracking payments.',
          type: 'success'
        });

        // Reload all data sources
        await loadDashboardData();
        await loadTermMetrics(selectedTransactionTerm);
        await loadTransactionData();
        await loadCustomerData();
      } else {
        toast.error('Failed to initialize school data. Please contact support if this issue persists.');
      }
    } catch (error) {
      console.error('Error initializing school data:', error);
      toast.error('Unable to complete school setup. Please try again or contact support.');
    }
  };

  const handleNavClick = (itemId: string) => {
    if (itemId === 'logout') {
      setShowLogoutConfirmation(true);
      return;
    }
    setActiveNavItem(itemId);
    
    // More professional navigation messages
    const navLabels = {
      'dashboard': 'Dashboard',
      'transactions': 'Transactions',
      'customer-management': 'Customer Management',
      'tasks': 'Tasks',
      'wallet': 'Wallet',
      'integrations': 'Integrations',
      'customer-care': 'Support Center',
      'settings': 'Settings'
    };
    
    const label = navLabels[itemId as keyof typeof navLabels] || itemId;
    console.log(`Navigated to ${label}`);
  };

  const handleWalletClick = () => {
    setActiveNavItem('wallet');
    console.log("Accessed wallet");
  };

  const handleWithdraw = () => {
    toast.success("Withdrawal request initiated. You will be redirected to the withdrawal form.");
  };

  const handleViewHistory = () => {
    setActiveNavItem('wallet');
    toast.info("Viewing wallet transaction history");
  };

  const handleDownloadStatement = () => {
    toast.success("Wallet statement download initiated. Your file will be ready shortly.");
  };

  const handleWalletSettings = () => {
    setActiveNavItem('settings');
    toast.info("Opening wallet settings configuration");
  };

  const handleTransferFunds = () => {
    toast.info("Transfer funds feature will be available in the next update");
  };

  const handleViewBalanceDetails = () => {
    const detailsMessage = `
Current Balance: ${formatCurrency(dashboardMetrics.walletBalance || 0)}
Total Transactions: ${dashboardMetrics.totalTransactions || 0}
Monthly Growth: ${dashboardMetrics.monthlyGrowth?.toFixed(1) || 0}%
Pending Withdrawals: ${formatCurrency(Math.floor((dashboardMetrics.walletBalance || 0) * 0.1))}
    `.trim();
    
    toast.info(detailsMessage, {
      duration: 5000,
    });
  };

  // Settings management functions
  const updateSettingsState = (updates: Partial<typeof settingsState>) => {
    setSettingsState(prev => ({
      ...prev,
      ...updates,
      isDirty: true,
      lastUpdated: new Date()
    }));
  };

  const handleSettingsSearch = (query: string) => {
    updateSettingsState({ searchQuery: query });
    console.log(`🔍 Searching settings for: "${query}"`);
  };

  const handleSettingsSectionChange = (section: string) => {
    updateSettingsState({ activeSection: section });
    console.log(`⚙️ Switched to ${section} settings`);
    toast.info(`Viewing ${section} settings`);
  };

  const handleAccountUpdate = async (updatedProfile: Partial<typeof schoolProfile>) => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log('🏫 Updating school profile:', updatedProfile);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Update school profile
      updateSettingsState({
        schoolProfile: { ...schoolProfile, ...updatedProfile },
        isUpdating: false,
        isDirty: false
      });
      
      // Update global school name if changed
      if (updatedProfile.schoolName && updatedProfile.schoolName !== schoolName) {
        setSchoolName(updatedProfile.schoolName);
      }
      
      toast.success('School profile updated successfully');
      console.log('✅ School profile update completed');
      
    } catch (error) {
      console.error('❌ Error updating school profile:', error);
      updateSettingsState({ isUpdating: false });
      toast.error('Failed to update school profile. Please try again.');
    }
  };

  const handleNotificationUpdate = async (updatedNotifications: Partial<typeof notifications>) => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log('🔔 Updating notification preferences:', updatedNotifications);
      
      await new Promise(resolve => setTimeout(resolve, 800));
      
      updateSettingsState({
        notifications: { ...notifications, ...updatedNotifications },
        isUpdating: false,
        isDirty: false
      });
      
      toast.success('Notification preferences updated successfully');
      console.log('✅ Notification settings update completed');
      
    } catch (error) {
      console.error('❌ Error updating notification preferences:', error);
      updateSettingsState({ isUpdating: false });
      toast.error('Failed to update notification preferences. Please try again.');
    }
  };

  const handleSecurityUpdate = async (updatedSecurity: Partial<typeof security>) => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log('🔒 Updating security settings:', updatedSecurity);
      
      // Simulate more processing time for security changes
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      updateSettingsState({
        security: { ...security, ...updatedSecurity },
        isUpdating: false,
        isDirty: false
      });
      
      // Special handling for critical security changes
      if (updatedSecurity.twoFactorAuth !== undefined) {
        const action = updatedSecurity.twoFactorAuth ? 'enabled' : 'disabled';
        toast.success(`Two-factor authentication ${action} successfully`);
        console.log(`🛡️ Two-factor authentication ${action}`);
      } else {
        toast.success('Security settings updated successfully');
      }
      
    } catch (error) {
      console.error('❌ Error updating security settings:', error);
      updateSettingsState({ isUpdating: false });
      toast.error('Failed to update security settings. Please contact support if this issue persists.');
    }
  };

  const handleSystemUpdate = async (updatedSystem: Partial<typeof system>) => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log('🔧 Updating system preferences:', updatedSystem);
      
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      updateSettingsState({
        system: { ...system, ...updatedSystem },
        isUpdating: false,
        isDirty: false
      });
      
      // Special handling for backup settings
      if (updatedSystem.autoBackup !== undefined) {
        const action = updatedSystem.autoBackup ? 'enabled' : 'disabled';
        toast.success(`Automatic backups ${action} successfully`);
        console.log(`💾 Automatic backups ${action}`);
      } else {
        toast.success('System preferences updated successfully');
      }
      
    } catch (error) {
      console.error('❌ Error updating system preferences:', error);
      updateSettingsState({ isUpdating: false });
      toast.error('Failed to update system preferences. Please try again.');
    }
  };

  const handlePasswordChange = async (currentPassword: string, newPassword: string) => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log('🔑 Processing password change request');
      
      // Simulate password validation and update
      await new Promise(resolve => setTimeout(resolve, 2500));
      
      // Update last updated timestamp
      updateSettingsState({
        isUpdating: false,
        isDirty: false
      });
      
      toast.success('Password changed successfully. Please log in again for security.');
      console.log('✅ Password change completed');
      
      // Could trigger logout for security
      setTimeout(() => {
        toast.info('For security purposes, you will be logged out in 30 seconds.');
      }, 3000);
      
    } catch (error) {
      console.error('❌ Error changing password:', error);
      updateSettingsState({ isUpdating: false });
      toast.error('Failed to change password. Please verify your current password and try again.');
    }
  };

  const handleBackupManagement = async (action: 'create' | 'restore' | 'download') => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log(`💾 Processing backup ${action} request`);
      
      switch (action) {
        case 'create':
          await new Promise(resolve => setTimeout(resolve, 3000));
          toast.success('System backup created successfully');
          console.log('✅ Manual backup completed');
          break;
          
        case 'restore':
          await new Promise(resolve => setTimeout(resolve, 4000));
          toast.success('System restored from backup successfully. Some changes may require a page refresh.');
          console.log('✅ System restore completed');
          break;
          
        case 'download':
          await new Promise(resolve => setTimeout(resolve, 2000));
          toast.success('Backup file prepared for download. Your download will begin shortly.');
          console.log('✅ Backup download initiated');
          break;
      }
      
      updateSettingsState({ isUpdating: false });
      
    } catch (error) {
      console.error(`❌ Error during backup ${action}:`, error);
      updateSettingsState({ isUpdating: false });
      toast.error(`Failed to ${action} backup. Please try again or contact support.`);
    }
  };

  const handleDataExport = async (format: 'csv' | 'excel' | 'pdf', dataType: 'all' | 'students' | 'transactions' | 'reports') => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log(`📊 Exporting ${dataType} data as ${format.toUpperCase()}`);
      
      // Simulate export processing
      await new Promise(resolve => setTimeout(resolve, 2500));
      
      const exportInfo = {
        format: format.toUpperCase(),
        dataType,
        recordCount: dataType === 'all' ? (transactionData.length + customerData.totalCustomers) : 
                     dataType === 'students' ? customerData.totalCustomers :
                     dataType === 'transactions' ? transactionData.length : 50,
        timestamp: new Date().toISOString()
      };
      
      updateSettingsState({ isUpdating: false });
      
      toast.success(`${exportInfo.dataType} data exported successfully as ${exportInfo.format} (${exportInfo.recordCount} records)`);
      console.log('✅ Data export completed:', exportInfo);
      
    } catch (error) {
      console.error('❌ Error exporting data:', error);
      updateSettingsState({ isUpdating: false });
      toast.error('Failed to export data. Please try again.');
    }
  };

  const handleSystemDiagnostics = async () => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log('🔍 Running system diagnostics');
      
      await new Promise(resolve => setTimeout(resolve, 3500));
      
      const diagnostics = {
        systemHealth: isConnected ? 'Excellent' : 'Poor',
        databaseConnection: 'Connected',
        apiStatus: 'Operational',
        backupStatus: system.autoBackup ? 'Enabled' : 'Disabled',
        lastBackup: new Date().toISOString(),
        userSessions: dashboardMetrics.activeUsers || 0,
        memoryUsage: '45%',
        diskSpace: '78%'
      };
      
      updateSettingsState({ isUpdating: false });
      
      const diagnosticMessage = `
System Health: ${diagnostics.systemHealth}
Database: ${diagnostics.databaseConnection}
API Status: ${diagnostics.apiStatus}
Active Sessions: ${diagnostics.userSessions}
Memory Usage: ${diagnostics.memoryUsage}
Disk Space: ${diagnostics.diskSpace}
      `.trim();
      
      toast.info(diagnosticMessage, { duration: 8000 });
      console.log('✅ System diagnostics completed:', diagnostics);
      
    } catch (error) {
      console.error('❌ Error running diagnostics:', error);
      updateSettingsState({ isUpdating: false });
      toast.error('Failed to run system diagnostics. Please try again.');
    }
  };

  const handleIntegrationToggle = async (integration: string, enabled: boolean) => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log(`🔗 ${enabled ? 'Enabling' : 'Disabling'} ${integration} integration`);
      
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const updatedIntegrations = { ...integrations, [`${integration}Enabled`]: enabled };
      
      updateSettingsState({
        integrations: updatedIntegrations,
        isUpdating: false,
        isDirty: false
      });
      
      const action = enabled ? 'enabled' : 'disabled';
      toast.success(`${integration} integration ${action} successfully`);
      console.log(`✅ ${integration} integration ${action}`);
      
    } catch (error) {
      console.error(`❌ Error toggling ${integration} integration:`, error);
      updateSettingsState({ isUpdating: false });
      toast.error(`Failed to update ${integration} integration. Please try again.`);
    }
  };

  const handleDiscardChanges = () => {
    // Reset to last saved state
    updateSettingsState({ isDirty: false });
    toast.info('Unsaved changes discarded');
    console.log('🔄 Settings changes discarded');
  };

  const handleSaveAllSettings = async () => {
    try {
      updateSettingsState({ isUpdating: true });
      
      console.log('💾 Saving all settings changes');
      
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      updateSettingsState({
        isUpdating: false,
        isDirty: false,
        lastUpdated: new Date()
      });
      
      toast.success('All settings saved successfully');
      console.log('✅ All settings saved');
      
    } catch (error) {
      console.error('❌ Error saving settings:', error);
      updateSettingsState({ isUpdating: false });
      toast.error('Failed to save settings. Please try again.');
    }
  };

  const handleLogout = () => {
    setShowLogoutConfirmation(true);
  };

  const handleConfirmLogout = async () => {
    setIsLoggingOut(true);
    
    try {
      // Add a smooth logout animation delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      toast.success("Successfully signed out. Thank you for using Master-Fees!");
      
      // Close the modal
      setShowLogoutConfirmation(false);
      
      // Small delay before calling onLogout to ensure toast is visible
      setTimeout(() => {
        onLogout();
      }, 500);
      
    } catch (error) {
      console.error('Error during logout:', error);
      toast.error("An error occurred while signing out. Please try again.");
      setIsLoggingOut(false);
    }
  };

  const handleCancelLogout = () => {
    setShowLogoutConfirmation(false);
    toast.info("Logout cancelled. You remain signed in.");
  };

  const handleMarkAllAsRead = async () => {
    try {
      await markAllAsRead();
      toast.success("All notifications marked as read");
    } catch (error) {
      toast.error("Failed to update notifications");
    }
  };

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await markAsRead(notificationId);
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const handleCompare = () => {
    const newPeriod = selectedPeriod === 'Term 2' ? 'Term 1' : 'Term 2';
    setSelectedPeriod(newPeriod);
    toast.info(`Comparing with ${newPeriod} data`);
  };

  const handleSettings = () => {
    toast.info("Opening chart configuration options");  
  };

  const handleMaximize = () => {
    toast.info("Expanding chart to detailed analytics view");
  };

  const handleQuickAction = async (action: string) => {
    if (isLoadingAction) return; // Prevent multiple simultaneous actions
    
    try {
      setIsLoadingAction(true);
      
      switch (action) {
        case 'send-reminders':
          const reminderResult = await api.sendPaymentReminders(schoolId);
          if (reminderResult.success) {
            toast.success("Payment reminders have been sent to customers with outstanding balances");
            await loadDashboardData();
          } else {
            throw new Error(reminderResult.error || 'Failed to send reminders');
          }
          break;
          
        case 'generate-report':
          toast.info("Generating financial report...");
          const reportResult = await api.createNotification(schoolId, {
            title: 'Financial Report Generated',
            message: 'Monthly financial report has been generated and is ready for download',
            type: 'success'
          });
          if (reportResult.success) {
            setTimeout(() => {
              toast.success("Financial report has been generated successfully");
              loadDashboardData();
            }, 2000);
          }
          break;
          
        case 'add-student':
          setActiveNavItem('customer-management');
          toast.info("Redirected to Customer Management for new enrollment");
          break;
          
        case 'process-payment':
          setActiveNavItem('transactions');
          toast.info("Redirected to Transactions for payment processing");
          break;
          
        default:
          toast.info(`${action} feature is currently under development`);
      }
    } catch (error) {
      console.error(`Error handling ${action}:`, error);
      toast.error(`Failed to ${action}. Please try again or contact support.`);
    } finally {
      setIsLoadingAction(false);
    }
  };

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZM', {
      style: 'currency',
      currency: 'ZMW',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays === 1) return '1 day ago';
    return `${diffInDays} days ago`;
  };

  const loadTermMetrics = async (term: string) => {
    if (!schoolId) return;
    
    try {
      setLoadingTermMetrics(true);
      
      const response = await api.getTransactionsByTerm(schoolId, term);
      
      if (response.success && response.data) {
        setTermMetrics(prev => ({
          ...prev,
          [term]: {
            revenue: response.data.totalRevenue || 0,
            balance: response.data.totalBalance || 0,
            outstanding: response.data.outstandingFees || 0
          }
        }));
        
        console.log(`✅ Loaded ${term} metrics:`, {
          revenue: response.data.totalRevenue,
          balance: response.data.totalBalance,
          outstanding: response.data.outstandingFees
        });
      } else {
        console.warn(`Failed to load metrics for ${term}:`, response.error);
        toast.info(`Unable to load ${term} financial data. Using cached data.`);
      }
    } catch (error) {
      console.error(`Error loading ${term} metrics:`, error);
      toast.error(`Unable to connect to server while loading ${term} data. Please check your connection.`);
    } finally {
      setLoadingTermMetrics(false);
    }
  };

  // Get real term-specific metrics from API data
  const getTermSpecificMetrics = (term: string) => {
    // Check if we have real data for this term
    if (termMetrics[term]) {
      return termMetrics[term];
    }
    
    // Fallback to calculated metrics if no real data yet
    const baseRevenue = dashboardMetrics.totalRevenue;
    const baseOutstanding = dashboardMetrics.outstandingFees;
    
    // Use realistic variations as fallback
    let termMultiplier = 1;
    switch (term) {
      case 'Term 1':
        termMultiplier = 0.85; // Term 1 typically has lower collection rates
        break;
      case 'Term 2':
        termMultiplier = 1.0; // Current term (baseline)
        break;
      case 'Term 3':
        termMultiplier = 1.15; // Term 3 often has higher collection due to year-end push
        break;
      default:
        termMultiplier = 1.0;
    }
    
    const termRevenue = Math.floor(baseRevenue * termMultiplier);
    const termOutstanding = Math.floor(baseOutstanding * (2 - termMultiplier)); // Inverse relationship
    const termBalance = Math.max(0, termRevenue - termOutstanding);
    
    return {
      revenue: termRevenue,
      outstanding: termOutstanding,
      balance: termBalance
    };
  };

  const refreshDashboard = async () => {
    try {
      setLoading(true);
      await loadDashboardData();
      await loadTransactionData();
      await loadCustomerData();
      toast.success("Dashboard data refreshed");
    } catch (error) {
      toast.error("Failed to refresh dashboard data");
    } finally {
      setLoading(false);
    }
  };

  // Unified customer management functions
  const updateCustomerManagement = (updates: Partial<typeof customerManagement>) => {
    setCustomerManagement(prev => ({
      ...prev,
      ...updates
    }));
  };

  const processCustomerData = async () => {
    try {
      updateCustomerManagement({ isFiltering: true });

      // Ensure we have valid transaction data
      if (!Array.isArray(transactionData)) {
        updateCustomerManagement({ 
          filteredData: [],
          isFiltering: false 
        });
        return;
      }

      let processed = [...transactionData];

      // Apply search filter
      if (customerSearchQuery) {
        const query = customerSearchQuery.toLowerCase().trim();
        if (query) {
          processed = processed.filter(customer => {
            const searchableFields = [
              customer?.studentName || '',
              customer?.class || '',
              customer?.feeType || '',
              (customer?.amount || 0).toString(),
              customer?.status || ''
            ];
            
            return searchableFields.some(field => 
              field.toString().toLowerCase().includes(query)
            );
          });
        }
      }

      // Apply class filter
      if (customerClassFilter) {
        const classFilter = customerClassFilter.toLowerCase().trim();
        processed = processed.filter(customer => {
          const className = (customer?.class || '').toString().toLowerCase();
          return className.includes(classFilter);
        });
      }

      // Apply status filter
      if (customerStatusFilter) {
        processed = processed.filter(customer => 
          customer?.status === customerStatusFilter
        );
      }

      // Apply date range filter
      if (customerDateRangeFilter) {
        const now = new Date();
        const cutoffDate = new Date();
        
        const dateRanges = {
          'week': () => cutoffDate.setDate(now.getDate() - 7),
          'month': () => cutoffDate.setMonth(now.getMonth() - 1),
          '3months': () => cutoffDate.setMonth(now.getMonth() - 3),
          'year': () => cutoffDate.setFullYear(now.getFullYear() - 1)
        };

        if (dateRanges[customerDateRangeFilter as keyof typeof dateRanges]) {
          dateRanges[customerDateRangeFilter as keyof typeof dateRanges]();
          
          processed = processed.filter(customer => {
            const dateToCheck = customer?.paymentDate || customer?.dueDate;
            if (!dateToCheck) return false;
            
            try {
              const customerDate = new Date(dateToCheck);
              return !isNaN(customerDate.getTime()) && customerDate >= cutoffDate;
            } catch {
              return false;
            }
          });
        }
      }

      // Apply sorting
      if (customerSort) {
        processed.sort((a, b) => {
          try {
            const getSortValue = (item: TransactionData, column: string) => {
              switch (column) {
                case 'name':
                  return (item?.studentName || '').toString().toLowerCase();
                case 'amount':
                  return Number(item?.amount || 0);
                case 'dueDate':
                  const date = new Date(item?.dueDate || 0);
                  return isNaN(date.getTime()) ? new Date(0) : date;
                case 'class':
                  return (item?.class || '').toString().toLowerCase();
                case 'status':
                  return item?.status || '';
                default:
                  return (item?.studentName || '').toString().toLowerCase();
              }
            };

            const aValue = getSortValue(a, customerSort.column);
            const bValue = getSortValue(b, customerSort.column);

            if (aValue < bValue) return customerSort.direction === 'asc' ? -1 : 1;
            if (aValue > bValue) return customerSort.direction === 'asc' ? 1 : -1;
            return 0;
          } catch (error) {
            console.warn('Error during sort comparison:', error);
            return 0;
          }
        });
      }

      // Update state with processed data
      updateCustomerManagement({
        filteredData: processed,
        isFiltering: false,
        lastActionType: 'data-processed',
        lastActionTimestamp: new Date()
      });

      // Clear selections if data changed significantly
      if (processed.length !== filteredCustomerData.length) {
        updateCustomerManagement({ selectedCustomers: new Set() });
      }

    } catch (error) {
      console.error('Error processing customer data:', error);
      updateCustomerManagement({ 
        isFiltering: false,
        lastActionType: 'processing-error',
        lastActionTimestamp: new Date()
      });
      toast.error('Unable to process customer data. Please try refreshing the page.');
    }
  };

  const synchronizeCustomerMetrics = () => {
    try {
      // Calculate real-time metrics from current data
      const totalCustomers = transactionData.length;
      const activeCustomers = transactionData.filter(c => c.status !== 'archived').length;
      const newThisMonth = transactionData.filter(c => {
        const date = new Date(c.paymentDate || c.dueDate);
        const monthAgo = new Date();
        monthAgo.setMonth(monthAgo.getMonth() - 1);
        return date >= monthAgo;
      }).length;

      const overdueCount = transactionData.filter(c => c.status === 'overdue').length;
      const pendingCount = transactionData.filter(c => c.status === 'pending').length;
      const paidCount = transactionData.filter(c => c.status === 'paid').length;

      // Update customer data with synchronized metrics
      setCustomerData(prev => ({
        ...prev,
        totalCustomers,
        activeCustomers,
        newCustomersThisMonth: newThisMonth,
        customerGrowthRate: prev.totalCustomers > 0 
          ? ((totalCustomers - prev.totalCustomers) / prev.totalCustomers) * 100 
          : 0
      }));

      // Update dashboard metrics for consistency
      setDashboardMetrics(prev => ({
        ...prev,
        totalStudents: totalCustomers,
        overduePayments: overdueCount,
        activeUsers: activeCustomers
      }));

    } catch (error) {
      console.error('Error synchronizing customer metrics:', error);
    }
  };

  // Unified customer management handlers
  const handleCustomerSearchChange = (query: string) => {
    updateCustomerManagement({
      searchQuery: query,
      currentPage: 1, // Reset pagination
      selectedCustomers: new Set(), // Clear selections
      lastActionType: 'search',
      lastActionTimestamp: new Date()
    });
  };

  const handleCustomerClassFilter = (className: string | null) => {
    updateCustomerManagement({
      classFilter: className,
      currentPage: 1,
      selectedCustomers: new Set(),
      lastActionType: 'class-filter',
      lastActionTimestamp: new Date()
    });
  };

  const handleCustomerStatusFilter = (status: string | null) => {
    updateCustomerManagement({
      statusFilter: status,
      currentPage: 1,
      selectedCustomers: new Set(),
      lastActionType: 'status-filter',
      lastActionTimestamp: new Date()
    });
  };

  const handleCustomerDateRangeFilter = (range: string | null) => {
    updateCustomerManagement({
      dateRangeFilter: range,
      currentPage: 1,
      selectedCustomers: new Set(),
      lastActionType: 'date-filter',
      lastActionTimestamp: new Date()
    });
  };

  const handleCustomerSortChange = (column: string, direction: 'asc' | 'desc') => {
    updateCustomerManagement({
      sortConfig: { column, direction },
      selectedCustomers: new Set(), // Clear selections when sorting
      lastActionType: 'sort',
      lastActionTimestamp: new Date()
    });
  };

  const handleCustomerClearFilters = () => {
    updateCustomerManagement({
      searchQuery: '',
      classFilter: null,
      statusFilter: null,
      dateRangeFilter: null,
      sortConfig: null,
      currentPage: 1,
      selectedCustomers: new Set(),
      lastActionType: 'clear-filters',
      lastActionTimestamp: new Date()
    });
    toast.success('All filters have been cleared');
  };

  // Unified pagination handlers
  const handlePageChange = async (newPage: number) => {
    try {
      updateCustomerManagement({ isPaginating: true });
      
      // Smooth page transition
      await new Promise(resolve => setTimeout(resolve, 200));
      
      updateCustomerManagement({
        currentPage: newPage,
        isPaginating: false,
        lastActionType: 'page-change',
        lastActionTimestamp: new Date()
      });
      
      console.log(`📄 Navigated to page ${newPage} of ${getTotalPages()}`);
      
    } catch (error) {
      console.error('Error changing page:', error);
      updateCustomerManagement({ isPaginating: false });
      throw error;
    }
  };

  const handleItemsPerPageChange = async (newItemsPerPage: number) => {
    try {
      updateCustomerManagement({ isPaginating: true });
      
      // Calculate optimal page to maintain user's position
      const currentFirstItem = (currentPage - 1) * itemsPerPage + 1;
      const newPage = Math.min(
        Math.ceil(currentFirstItem / newItemsPerPage),
        Math.ceil((filteredCustomerData.length || transactionData.length) / newItemsPerPage)
      );
      
      await new Promise(resolve => setTimeout(resolve, 300));
      
      updateCustomerManagement({
        itemsPerPage: newItemsPerPage,
        currentPage: newPage,
        isPaginating: false,
        selectedCustomers: new Set(), // Clear selections when changing page size
        lastActionType: 'page-size-change',
        lastActionTimestamp: new Date()
      });
      
      console.log(`📋 Page size changed to ${newItemsPerPage}, repositioned to page ${newPage}`);
      toast.success(`Now showing ${newItemsPerPage} customers per page`);
      
    } catch (error) {
      console.error('Error changing items per page:', error);
      updateCustomerManagement({ isPaginating: false });
      throw error;
    }
  };

  // Unified data access functions
  const getActiveCustomerData = () => {
    // Use filtered data if filters are active, otherwise use all transaction data
    const hasActiveFilters = !!(customerSearchQuery || customerClassFilter || customerStatusFilter || customerDateRangeFilter || customerSort);
    return hasActiveFilters ? filteredCustomerData : (transactionData || []);
  };

  const getPaginatedCustomerData = () => {
    const activeData = getActiveCustomerData();
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return activeData.slice(startIndex, endIndex);
  };

  const getTotalPages = () => {
    const activeData = getActiveCustomerData();
    return Math.ceil(activeData.length / itemsPerPage) || 1;
  };

  const getCustomerStats = () => {
    const activeData = getActiveCustomerData();
    return {
      total: activeData.length,
      filtered: filteredCustomerData.length,
      displayed: getPaginatedCustomerData().length,
      selected: selectedCustomers.size,
      hasFilters: !!(customerSearchQuery || customerClassFilter || customerStatusFilter || customerDateRangeFilter),
      currentRange: {
        start: activeData.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0,
        end: Math.min(currentPage * itemsPerPage, activeData.length)
      }
    };
  };

  // Auto-reset pagination when filters change
  useEffect(() => {
    if (currentPage !== 1) {
      updateCustomerManagement({
        currentPage: 1,
        lastActionType: 'filter-changed',
        lastActionTimestamp: new Date()
      });
    }
  }, [customerSearchQuery, customerClassFilter, customerStatusFilter, customerDateRangeFilter, customerSort]);

  // Real-time metrics synchronization
  useEffect(() => {
    synchronizeCustomerMetrics();
  }, [filteredCustomerData, transactionData, customerManagement.lastActionTimestamp]);

  // Customer management action handlers
  const handleAddCustomer = async (customerData: any) => {
    try {
      updateCustomerManagement({ isBulkActionInProgress: true });
      
      console.log('🆕 Adding new customer:', customerData.studentName);
      
      // Create comprehensive customer record
      const newTransaction: TransactionData = {
        id: `cust_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        studentName: customerData.studentName,
        class: customerData.class,
        feeType: 'Enrollment Fee',
        amount: calculateEnrollmentFee(customerData.feeStructure),
        status: 'pending',
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        term: selectedTransactionTerm
      };

      // Simulate API processing
      await new Promise(resolve => setTimeout(resolve, 1200));

      // Update all relevant data simultaneously
      const updatedTransactionData = [newTransaction, ...transactionData];
      setTransactionData(updatedTransactionData);

      // Update metrics
      const updatedCustomerData = {
        ...customerData,
        totalCustomers: customerData.totalCustomers + 1,
        activeCustomers: customerData.activeCustomers + 1,
        newCustomersThisMonth: customerData.newCustomersThisMonth + 1
      };
      setCustomerData(updatedCustomerData);

      const updatedDashboardMetrics = {
        ...dashboardMetrics,
        totalStudents: dashboardMetrics.totalStudents + 1,
        newEnrollments: dashboardMetrics.newEnrollments + 1,
        activeUsers: (dashboardMetrics.activeUsers || 0) + 1,
        outstandingFees: dashboardMetrics.outstandingFees + newTransaction.amount
      };
      setDashboardMetrics(updatedDashboardMetrics);

      // Update management state
      updateCustomerManagement({
        isBulkActionInProgress: false,
        selectedCustomers: new Set(),
        lastActionType: 'customer-added',
        lastActionTimestamp: new Date()
      });

      toast.success(`${customerData.studentName} has been successfully enrolled in ${customerData.class}`);
      console.log('✅ Customer enrollment completed:', {
        student: customerData.studentName,
        amount: formatCurrency(newTransaction.amount),
        totalCustomers: updatedCustomerData.totalCustomers
      });
      
    } catch (error) {
      console.error('❌ Error adding customer:', error);
      updateCustomerManagement({ isBulkActionInProgress: false });
      toast.error('Failed to enroll customer. Please try again.');
      throw error;
    }
  };

  const handleImportCustomerData = async (file: File) => {
    try {
      setIsLoadingAction(true);
      
      // Simulate file processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // For demo, simulate adding multiple customers
      const mockCustomerCount = Math.floor(Math.random() * 10) + 5; // 5-15 customers
      
      setCustomerData(prev => ({
        ...prev,
        totalCustomers: prev.totalCustomers + mockCustomerCount,
        activeCustomers: prev.activeCustomers + mockCustomerCount,
        newCustomersThisMonth: prev.newCustomersThisMonth + mockCustomerCount
      }));

      setDashboardMetrics(prev => ({
        ...prev,
        totalStudents: prev.totalStudents + mockCustomerCount,
        newEnrollments: prev.newEnrollments + mockCustomerCount
      }));

      console.log(`✅ Imported ${mockCustomerCount} customers from file:`, file.name);
    } catch (error) {
      console.error('Error importing customer data:', error);
      throw error;
    } finally {
      setIsLoadingAction(false);
    }
  };

  const handleExportCustomerData = async (format: 'csv' | 'excel' | 'pdf') => {
    try {
      setIsLoadingAction(true);
      
      // Simulate export processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Generate export data
      const exportData = {
        format,
        recordCount: filteredCustomerData.length || transactionData.length,
        timestamp: new Date().toISOString(),
        filename: `customer_data_${new Date().toISOString().split('T')[0]}.${format}`
      };

      console.log('✅ Customer data exported:', exportData);
      
      // Simulate file download trigger
      const downloadMessage = `Customer data (${exportData.recordCount} records) exported successfully as ${format.toUpperCase()}`;
      console.log(downloadMessage);
      
    } catch (error) {
      console.error('Error exporting customer data:', error);
      throw error;
    } finally {
      setIsLoadingAction(false);
    }
  };

  const handleSendPaymentReminders = async () => {
    try {
      setIsLoadingAction(true);
      
      // Count customers with outstanding payments
      const overdueCustomers = transactionData.filter(
        transaction => transaction.status === 'overdue' || transaction.status === 'pending'
      );

      // Simulate sending reminders
      await new Promise(resolve => setTimeout(resolve, 2000));

      console.log(`✅ Payment reminders sent to ${overdueCustomers.length} customers`);
      
      // Add notification for sent reminders
      const reminderNotification = {
        id: `reminder_${Date.now()}`,
        title: 'Payment Reminders Sent',
        message: `Successfully sent payment reminders to ${overdueCustomers.length} customers with outstanding balances`,
        type: 'success' as const,
        timestamp: new Date().toISOString(),
        read: false
      };

      // You could add this to a notifications system if available
      
    } catch (error) {
      console.error('Error sending payment reminders:', error);
      throw error;
    } finally {
      setIsLoadingAction(false);
    }
  };

  const handleBulkUpdate = async (action: string) => {
    try {
      setIsLoadingAction(true);
      
      // Simulate bulk operation
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const affectedRecords = Math.floor(Math.random() * 20) + 10; // 10-30 records
      
      console.log(`✅ Bulk ${action} completed for ${affectedRecords} customers`);
      
    } catch (error) {
      console.error(`Error performing bulk ${action}:`, error);
      throw error;
    } finally {
      setIsLoadingAction(false);
    }
  };

  // Helper function to calculate enrollment fee based on fee structure
  const calculateEnrollmentFee = (feeStructure: string): number => {
    const baseFee = 1500; // ZMW
    
    switch (feeStructure) {
      case 'Scholarship':
        return Math.floor(baseFee * 0.2); // 80% discount
      case 'Staff Discount':
        return Math.floor(baseFee * 0.5); // 50% discount
      case 'Sibling Discount':
        return Math.floor(baseFee * 0.8); // 20% discount
      case 'Custom':
        return Math.floor(baseFee * 0.9); // 10% discount
      default:
        return baseFee; // Standard fee
    }
  };

  // Enhanced unified customer action handlers
  const handleCustomerSelect = (customer: TransactionData) => {
    const newSelected = new Set(selectedCustomers);
    
    if (newSelected.has(customer.id)) {
      newSelected.delete(customer.id);
      toast.info(`Deselected ${customer.studentName}`);
    } else {
      newSelected.add(customer.id);
      toast.info(`Selected ${customer.studentName} from ${customer.class}`);
    }
    
    updateCustomerManagement({
      selectedCustomers: newSelected,
      lastActionType: 'customer-select',
      lastActionTimestamp: new Date()
    });
    
    console.log(`Customer selection changed: ${newSelected.size} customers selected`);
  };

  const handleSelectAllCustomers = (selectAll: boolean) => {
    const activeData = getPaginatedCustomerData(); // Only select current page
    const newSelected = new Set(selectedCustomers);
    
    if (selectAll) {
      activeData.forEach(customer => newSelected.add(customer.id));
      toast.success(`Selected all ${activeData.length} customers on current page`);
    } else {
      activeData.forEach(customer => newSelected.delete(customer.id));
      toast.info('Cleared current page selections');
    }
    
    updateCustomerManagement({
      selectedCustomers: newSelected,
      lastActionType: selectAll ? 'select-all' : 'deselect-all',
      lastActionTimestamp: new Date()
    });
  };

  const handleCustomerBulkAction = async (action: string, customers: TransactionData[]) => {
    try {
      updateCustomerManagement({ isBulkActionInProgress: true });
      
      const actionStartTime = new Date();
      console.log(`🔄 Starting bulk ${action} for ${customers.length} customers`);
      
      // Simulate processing time based on action complexity
      const processingTime = {
        'send-reminders': 1500,
        'export': 1000,
        'archive': 2000,
        'delete': 2500
      }[action] || 1000;
      
      await new Promise(resolve => setTimeout(resolve, processingTime));
      
      let updatedTransactionData = [...transactionData];
      let updatedDashboardMetrics = { ...dashboardMetrics };
      let updatedCustomerData = { ...customerData };
      
      switch (action) {
        case 'send-reminders':
          console.log(`📧 Sending payment reminders to ${customers.length} customers`);
          
          // Update reminder count in metrics
          updatedDashboardMetrics = {
            ...updatedDashboardMetrics,
            overduePayments: Math.max(0, updatedDashboardMetrics.overduePayments - Math.floor(customers.length * 0.15))
          };
          
          toast.success(`Payment reminders sent to ${customers.length} customers`);
          break;
          
        case 'export':
          console.log(`📄 Exporting data for ${customers.length} customers`);
          
          const exportData = {
            customers: customers.map(c => ({
              id: c.id,
              name: c.studentName,
              class: c.class,
              feeType: c.feeType,
              amount: c.amount,
              status: c.status,
              dueDate: c.dueDate,
              paymentDate: c.paymentDate
            })),
            exportedAt: actionStartTime.toISOString(),
            totalRecords: customers.length,
            filters: {
              search: customerSearchQuery,
              class: customerClassFilter,
              status: customerStatusFilter,
              dateRange: customerDateRangeFilter
            }
          };
          
          console.log('📊 Export data generated:', exportData);
          toast.success(`Customer data exported successfully (${customers.length} records)`);
          break;
          
        case 'archive':
          console.log(`🗃️ Archiving ${customers.length} customers`);
          
          // Remove archived customers from transaction data
          const archivedIds = new Set(customers.map(c => c.id));
          updatedTransactionData = transactionData.filter(t => !archivedIds.has(t.id));
          
          // Update metrics
          updatedCustomerData = {
            ...updatedCustomerData,
            totalCustomers: Math.max(0, updatedCustomerData.totalCustomers - customers.length),
            activeCustomers: Math.max(0, updatedCustomerData.activeCustomers - customers.length)
          };
          
          updatedDashboardMetrics = {
            ...updatedDashboardMetrics,
            totalStudents: Math.max(0, updatedDashboardMetrics.totalStudents - customers.length),
            activeUsers: Math.max(0, (updatedDashboardMetrics.activeUsers || 0) - customers.length)
          };
          
          toast.success(`${customers.length} customers archived successfully`);
          break;
          
        case 'delete':
          console.log(`🗑️ Deleting ${customers.length} customers`);
          
          const deletedIds = new Set(customers.map(c => c.id));
          updatedTransactionData = transactionData.filter(t => !deletedIds.has(t.id));
          
          // Update all relevant metrics
          updatedCustomerData = {
            ...updatedCustomerData,
            totalCustomers: Math.max(0, updatedCustomerData.totalCustomers - customers.length),
            activeCustomers: Math.max(0, updatedCustomerData.activeCustomers - customers.length)
          };
          
          updatedDashboardMetrics = {
            ...updatedDashboardMetrics,
            totalStudents: Math.max(0, updatedDashboardMetrics.totalStudents - customers.length),
            activeUsers: Math.max(0, (updatedDashboardMetrics.activeUsers || 0) - customers.length)
          };
          
          toast.success(`${customers.length} customers deleted successfully`);
          break;
          
        default:
          console.log(`✅ Bulk action '${action}' completed for ${customers.length} customers`);
          toast.success(`Bulk ${action} completed successfully`);
      }
      
      // Apply all updates simultaneously
      setTransactionData(updatedTransactionData);
      setDashboardMetrics(updatedDashboardMetrics);
      setCustomerData(updatedCustomerData);
      
      // Clear selections and update management state
      updateCustomerManagement({
        selectedCustomers: new Set(),
        isBulkActionInProgress: false,
        lastActionType: `bulk-${action}`,
        lastActionTimestamp: new Date()
      });
      
      console.log(`✅ Bulk ${action} completed in ${Date.now() - actionStartTime.getTime()}ms`);
      
    } catch (error) {
      console.error(`❌ Error performing bulk ${action}:`, error);
      updateCustomerManagement({ isBulkActionInProgress: false });
      toast.error(`Failed to complete bulk ${action}. Please try again.`);
      throw error;
    }
  };

  const handleViewCustomerDetails = (customerId: string) => {
    const customer = transactionData.find(c => c.id === customerId);
    if (customer) {
      console.log('Viewing customer details:', customer);
      toast.info(`Loading detailed profile for ${customer.studentName}...`);
      
      // In a real app, this would navigate to a detailed customer view
      setTimeout(() => {
        const detailsMessage = `
Customer: ${customer.studentName}
Class: ${customer.class}
Fee Type: ${customer.feeType}
Amount Due: ${formatCurrency(customer.amount)}
Status: ${customer.status}
Due Date: ${new Date(customer.dueDate).toLocaleDateString()}
        `.trim();
        
        toast.info(detailsMessage, { duration: 8000 });
      }, 1000);
    }
  };

  const handleEditCustomer = async (customer: TransactionData) => {
    try {
      setIsLoadingAction(true);
      console.log('Opening edit form for customer:', customer.studentName);
      
      // Simulate opening edit modal/form
      await new Promise(resolve => setTimeout(resolve, 500));
      
      toast.info(`Edit form for ${customer.studentName} will be available in the next update`);
      
    } catch (error) {
      console.error('Error opening customer edit form:', error);
      toast.error('Unable to open customer edit form');
    } finally {
      setIsLoadingAction(false);
    }
  };

  const handleDeleteCustomer = async (customerId: string) => {
    const customer = transactionData.find(c => c.id === customerId);
    if (!customer) return;
    
    try {
      setIsLoadingAction(true);
      console.log('Deleting customer:', customer.studentName);
      
      // Show confirmation (in real app, this would be a proper confirmation dialog)
      const confirmed = window.confirm(`Are you sure you want to delete ${customer.studentName}? This action cannot be undone.`);
      
      if (confirmed) {
        // Simulate deletion processing
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Remove customer from transaction data
        setTransactionData(prev => prev.filter(t => t.id !== customerId));
        
        // Update customer metrics
        setCustomerData(prev => ({
          ...prev,
          totalCustomers: Math.max(0, prev.totalCustomers - 1),
          activeCustomers: Math.max(0, prev.activeCustomers - 1)
        }));
        
        // Update dashboard metrics
        setDashboardMetrics(prev => ({
          ...prev,
          totalStudents: Math.max(0, prev.totalStudents - 1),
          activeUsers: Math.max(0, (prev.activeUsers || 0) - 1)
        }));
        
        toast.success(`${customer.studentName} has been successfully removed from the system`);
      } else {
        toast.info('Customer deletion cancelled');
      }
      
    } catch (error) {
      console.error('Error deleting customer:', error);
      toast.error('Failed to delete customer. Please try again.');
    } finally {
      setIsLoadingAction(false);
    }
  };

  const handlePaymentAction = async (customerId: string, action: 'pay' | 'remind' | 'adjust') => {
    const customer = transactionData.find(c => c.id === customerId);
    if (!customer) return;
    
    try {
      setIsLoadingAction(true);
      
      switch (action) {
        case 'pay':
          console.log(`Recording payment for ${customer.studentName}`);
          
          // Simulate payment processing
          await new Promise(resolve => setTimeout(resolve, 1500));
          
          // Update transaction status
          setTransactionData(prev => 
            prev.map(t => 
              t.id === customerId 
                ? { ...t, status: 'paid' as const, paymentDate: new Date().toISOString() }
                : t
            )
          );
          
          // Update dashboard metrics
          setDashboardMetrics(prev => ({
            ...prev,
            totalRevenue: prev.totalRevenue + customer.amount,
            outstandingFees: Math.max(0, prev.outstandingFees - customer.amount),
            overduePayments: customer.status === 'overdue' ? Math.max(0, prev.overduePayments - 1) : prev.overduePayments,
            walletBalance: (prev.walletBalance || 0) + customer.amount,
            totalTransactions: (prev.totalTransactions || 0) + 1
          }));
          
          console.log(`✅ Payment recorded: ${formatCurrency(customer.amount)} from ${customer.studentName}`);
          break;
          
        case 'remind':
          console.log(`Sending payment reminder to ${customer.studentName}`);
          
          // Simulate sending reminder
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          console.log(`✅ Payment reminder sent to ${customer.studentName} (${customer.class})`);
          break;
          
        case 'adjust':
          console.log(`Opening balance adjustment for ${customer.studentName}`);
          
          // Simulate opening adjustment form
          await new Promise(resolve => setTimeout(resolve, 500));
          
          toast.info(`Balance adjustment for ${customer.studentName} will be available in the next update`);
          break;
          
        default:
          console.log(`Unknown payment action: ${action}`);
      }
      
    } catch (error) {
      console.error(`Error performing payment ${action}:`, error);
      throw error;
    } finally {
      setIsLoadingAction(false);
    }
  };

  // Handle view transaction details
  const handleViewTransactionDetails = () => {
    setActiveNavItem('transaction-details');
    toast.info("Loading detailed transaction view...");
  };

  // Handle back from transaction details
  const handleBackFromTransactionDetails = () => {
    setActiveNavItem('transactions');
    toast.info("Returned to transactions overview");
  };

  const renderNavIcon = (iconType: string, isActive: boolean = false) => {
    const iconProps = {
      className: "w-[15px] h-[15px]",
      fill: "none",
      preserveAspectRatio: "none" as const,
      viewBox: "0 0 15 15"
    };

    const strokeColor = isActive ? "#003049" : "#171717";

    switch (iconType) {
      case 'dashboard':
        return (
          <svg {...iconProps} viewBox="0 0 12 12">
            <path d={svgPaths.p1fd7ae00} fill={isActive ? "#003049" : "#00454E"} />
          </svg>
        );
      case 'receipt':
        return (
          <svg {...iconProps}>
            <path d={svgPaths.pf77f300} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" />
            <path d={svgPaths.p3234b080} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" />
            <path d="M5.625 8.13125H7.5" stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d="M5.625 5.63125H7.5" stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d="M3.74725 8.125H3.75287" stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d="M3.74725 5.625H3.75287" stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      case 'user':
        return (
          <svg {...iconProps}>
            <path d={svgPaths.p1600ff00} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d={svgPaths.p3f89be70} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d={svgPaths.p1be00680} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      case 'magic':
        return (
          <svg {...iconProps}>
            <path d={svgPaths.p256bf880} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d={svgPaths.p75f1480} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d={svgPaths.p1fbb9ef0} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
            <path d={svgPaths.pbf9100} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
            <path d={svgPaths.p13bbac80} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
          </svg>
        );
      case 'wallet':
        return (
          <svg {...iconProps}>
            <path d="M8.125 5.625H4.375" stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d={svgPaths.p30bcfb80} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d={svgPaths.p2e9f0c00} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      case 'grammerly':
        return (
          <svg {...iconProps}>
            <path d={svgPaths.p276b9800} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
            <path d={svgPaths.p2b623880} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      case 'setting':
        return (
          <svg {...iconProps}>
            <path d={svgPaths.p66e3e00} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" />
            <path d={svgPaths.p2c65c400} stroke={strokeColor} strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" />
          </svg>
        );
      case 'logout':
        return (
          <svg {...iconProps} viewBox="0 0 24 24">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" stroke="#e91f63" strokeLinecap="round" strokeLinejoin="round" />
            <polyline points="16,17 21,12 16,7" stroke="#e91f63" strokeLinecap="round" strokeLinejoin="round" />
            <line x1="21" y1="12" x2="9" y2="12" stroke="#e91f63" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        );
      default:
        return null;
    }
  };

  const renderNavItem = (item: NavItem) => {
    const isActive = activeNavItem === item.id;
    const isLogout = item.id === 'logout';
    
    return (
      <button
        key={item.id}
        onClick={() => handleNavClick(item.id)}
        disabled={isLoggingOut}
        className={`relative rounded-[10px] shrink-0 w-full transition-all duration-200 ${
          isLogout ? 'hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed' : 
          isActive ? 'bg-[#ffffff] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.15)]' : 'hover:bg-white/50'
        } ${isLoggingOut && isLogout ? 'animate-pulse' : ''}`}
        aria-label={`Navigate to ${item.label}`}
      >
        <div className="flex flex-row items-center relative size-full">
          <div className={`box-border content-stretch flex flex-row gap-[11px] items-center justify-start pl-[15px] py-[11px] relative w-full ${
            sidebarCollapsed ? 'pr-[15px]' : 'pr-4'
          }`}>
            {renderNavIcon(item.icon, isLogout ? false : isActive)}
            {!sidebarCollapsed && (
              <div className={`flex flex-col font-['IBM_Plex_Sans_Devanagari:${isActive ? 'Medium' : 'Regular'}',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[13px] text-left text-nowrap ${
                isLogout ? 'text-[#e91f63]' :
                isActive ? 'text-[#003049]' : 'text-[#000000]'
              }`}>
                <p className="block leading-[1.2] whitespace-pre">
                  {isLogout && isLoggingOut ? 'Signing out...' : item.label}
                </p>
              </div>
            )}
          </div>
        </div>
      </button>
    );
  };

  const renderMainContent = () => {
    if (loading) {
      return (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#003049] mx-auto mb-4"></div>
            <div className="text-gray-600 text-sm">Loading dashboard...</div>
            <div className="text-gray-400 text-xs mt-2">Please wait while we fetch your data</div>
          </div>
        </div>
      );
    }

    if (activeNavItem === 'transaction-details') {
      return (
        <div className="flex-1">
          <div className="w-full flex flex-col min-h-full">
            {/* Header with back button */}
            <div className="flex-shrink-0 bg-white border-b border-gray-200">
              <div className="px-6 py-4 border-b border-gray-100">
                <button
                  onClick={handleBackFromTransactionDetails}
                  className="flex items-center gap-2 text-[#025864] hover:text-[#003049] transition-colors"
                  aria-label="Back to transactions overview"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                  </svg>
                  <span className="font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] text-sm">Back to Transactions</span>
                </button>
              </div>
              <div className="h-[60px]">
                <Frame1707478525 
                  selectedTerm={selectedTransactionTerm}
                  totalRevenue={getTermSpecificMetrics(selectedTransactionTerm).revenue}
                  totalCollected={getTermSpecificMetrics(selectedTransactionTerm).revenue - getTermSpecificMetrics(selectedTransactionTerm).outstanding}
                  outstandingBalance={getTermSpecificMetrics(selectedTransactionTerm).outstanding}
                  totalPupils={dashboardMetrics.totalStudents}
                  loading={loadingTermMetrics}
                />
              </div>
            </div>
            
            {/* Main content area */}
            <div className="flex-1 p-6">
              <Group1000005071New />
            </div>
            
            {/* Table Header */}
            <div className="flex-shrink-0" style={{ height: '40px' }}>
              <Frame1707478519 />
            </div>
          </div>
        </div>
      );
    }

    if (activeNavItem === 'integrations') {
      return (
        <div className="flex-1">
          <div className="w-full">
            <div className="bg-background">
              <div className="p-6">
                <div className="w-full max-w-7xl mx-auto flex flex-col gap-6">
                  {/* Page Header */}
                  <div className="flex-shrink-0">
                    <h1 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-[24px] mb-2">
                      Integrations
                    </h1>
                    <p className="text-gray-600 text-sm">
                      Connect Master-Fees with your existing business tools and accounting software
                    </p>
                  </div>
                  
                  {/* Accounting & Finance Section */}
                  <div className="flex-shrink-0">
                    <h2 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] text-lg mb-4">
                      Accounting & Finance
                    </h2>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      <QuickBooksIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`QuickBooks connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                      <XeroIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`Xero connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                      <WaveIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`Wave connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                      <SageIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`Sage connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                    </div>
                  </div>
                  
                  {/* Payment Processing Section */}
                  <div className="flex-shrink-0">
                    <h2 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] text-lg mb-4">
                      Payment Processing
                    </h2>
                    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                      <StripeIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`Stripe connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                      <PayPalIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`PayPal connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                      <MPesaIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`M-Pesa connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                    </div>
                  </div>
                  
                  {/* Education & Communication Section */}
                  <div className="flex-shrink-0">
                    <h2 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] text-lg mb-4">
                      Education & Communication
                    </h2>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      <GoogleWorkspaceIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`Google Workspace connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                      <SlackIntegration 
                        schoolId={schoolId}
                        onConnectionChange={(connected) => {
                          console.log(`Slack connection status changed: ${connected ? 'connected' : 'disconnected'}`);
                        }}
                      />
                    </div>
                  </div>
                  
                  {/* Coming Soon Section */}
                  <div className="flex-shrink-0">
                    <h2 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] text-lg mb-4">
                      Coming Soon
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {/* Microsoft 365 */}
                      <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 opacity-75">
                        <div className="flex items-center gap-4 mb-4">
                          <div className="w-12 h-12 bg-[#0078d4] rounded-lg flex items-center justify-center">
                            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M24 12.593c0 1.292-.769 2.401-1.87 2.907v1.5c0 2.761-2.239 5-5 5s-5-2.239-5-5v-1.5C11.031 14.994 10.262 13.885 10.262 12.593s.769-2.401 1.868-2.907V8.187c0-2.761 2.239-5 5-5s5 2.239 5 5v1.499c1.101.506 1.87 1.615 1.87 2.907z"/>
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-lg">
                              Microsoft 365
                            </h3>
                            <p className="text-gray-500 text-sm">Office suite and Teams integration</p>
                          </div>
                        </div>
                        <div className="text-center">
                          <span className="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Coming Soon</span>
                        </div>
                      </div>
                      
                      {/* Zoom */}
                      <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 opacity-75">
                        <div className="flex items-center gap-4 mb-4">
                          <div className="w-12 h-12 bg-[#2d8cff] rounded-lg flex items-center justify-center">
                            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M8.75 12c0 1.65 1.35 3 3 3s3-1.35 3-3-1.35-3-3-3-3 1.35-3 3zm7.5 0c0 2.485-2.015 4.5-4.5 4.5s-4.5-2.015-4.5-4.5S9.265 7.5 11.75 7.5s4.5 2.015 4.5 4.5z"/>
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-lg">
                              Zoom
                            </h3>
                            <p className="text-gray-500 text-sm">Video conferencing for meetings</p>
                          </div>
                        </div>
                        <div className="text-center">
                          <span className="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Coming Soon</span>
                        </div>
                      </div>
                      
                      {/* Mailchimp */}
                      <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 opacity-75">
                        <div className="flex items-center gap-4 mb-4">
                          <div className="w-12 h-12 bg-[#ffe01b] rounded-lg flex items-center justify-center">
                            <svg className="w-8 h-8 text-black" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.418 0-8-3.582-8-8s3.582-8 8-8 8 3.582 8 8-3.582 8-8 8z"/>
                            </svg>
                          </div>
                          <div>
                            <h3 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-lg">
                              Mailchimp
                            </h3>
                            <p className="text-gray-500 text-sm">Email marketing and newsletters</p>
                          </div>
                        </div>
                        <div className="text-center">
                          <span className="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">Coming Soon</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Request Integration */}
                  <div className="flex-shrink-0">
                    <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-6 text-center">
                      <div className="text-gray-600 mb-2">
                        <svg className="w-12 h-12 mx-auto mb-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-3.582 8-8 8a8.959 8.959 0 01-4.906-1.436L3 21l2.436-5.094A8.959 8.959 0 013 12c0-4.418 3.582-8 8-8s8 3.582 8 8z" />
                        </svg>
                      </div>
                      <h3 className="text-lg font-semibold text-gray-700 mb-2">Need a Custom Integration?</h3>
                      <p className="text-gray-600 text-sm mb-4">
                        Don't see the integration you need? Let us know and we'll prioritize it for future releases.
                      </p>
                      <button 
                        onClick={() => toast.info("Integration request feature will be available in the next update")}
                        className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition-colors"
                      >
                        Request Integration
                      </button>
                    </div>
                  </div>
                  
                  {/* Extra spacing to ensure scroll */}
                  <div className="h-4 flex-shrink-0"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (activeNavItem === 'customer-care') {
      return (
        <div className="flex-1">
          <div className="w-full">
            <div className="bg-background">
              <div>
                {/* Support Header */}
                <div className="flex-shrink-0">
                  <SupportHeader 
                    onSearch={(query) => {
                      console.log(`Searching support for: ${query}`);
                      toast.info(`Searching for "${query}" in help articles...`);
                    }}
                  />
                </div>
                
                {/* Contact Cards */}
                <div className="flex-shrink-0">
                  <SupportContactCards />
                </div>
                
                {/* FAQ Section */}
                <div className="flex-shrink-0">
                  <SupportFAQ />
                </div>
                
                {/* Resources Section */}
                <div className="flex-shrink-0">
                  <SupportResources />
                </div>
                
                {/* Footer */}
                <div className="flex-shrink-0 bg-[#f8f9fa] py-8 border-t border-gray-200">
                  <div className="max-w-6xl mx-auto px-6 text-center">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div>
                        <h4 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] mb-3">
                          Office Hours
                        </h4>
                        <div className="text-sm text-gray-600 space-y-1">
                          <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                          <p>Saturday: 9:00 AM - 2:00 PM</p>
                          <p>Sunday: Closed</p>
                          <p className="text-green-600 font-medium">Emergency support: 24/7</p>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] mb-3">
                          Contact Information
                        </h4>
                        <div className="text-sm text-gray-600 space-y-1">
                          <p>Email: support@master-fees.com</p>
                          <p>Phone: +260-XXX-XXXX</p>
                          <p>WhatsApp: +260-XXX-XXXX</p>
                          <p>Address: Lusaka, Zambia</p>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[#1f1f20] mb-3">
                          Follow Us
                        </h4>
                        <div className="flex justify-center gap-4">
                          <button
                            onClick={() => toast.info('Social media links will be available in the next update')}
                            className="p-2 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
                            title="Twitter"
                          >
                            <svg className="w-5 h-5 text-[#1da1f2]" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                            </svg>
                          </button>
                          <button
                            onClick={() => toast.info('Social media links will be available in the next update')}
                            className="p-2 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
                            title="LinkedIn"
                          >
                            <svg className="w-5 h-5 text-[#0077b5]" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                            </svg>
                          </button>
                          <button
                            onClick={() => toast.info('Social media links will be available in the next update')}
                            className="p-2 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
                            title="Facebook"
                          >
                            <svg className="w-5 h-5 text-[#1877f2]" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                            </svg>
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-8 pt-8 border-t border-gray-300 text-center">
                      <p className="text-sm text-gray-500">
                        © 2025 Master-Fees Ltd. All rights reserved. | Privacy Policy | Terms of Service | System Status
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (activeNavItem === 'transactions') {
      return (
        <div className="flex-1">
          <div className="w-full flex flex-col gap-3 p-4">
            <div className="flex-shrink-0">
              <Frame1707478532 
                selectedTerm={selectedTransactionTerm}
                onTermChange={async (term) => {
                  setSelectedTransactionTerm(term);
                  console.log(`Transactions term changed to: ${term}`);
                  toast.info(`Loading ${term} financial data...`);
                  await loadTermMetrics(term);
                }}
                onSettingsClick={() => {
                  setActiveNavItem('settings');
                  console.log("Navigated to Settings from Transactions header");
                }}
                totalRevenue={getTermSpecificMetrics(selectedTransactionTerm).revenue}
                totalBalance={getTermSpecificMetrics(selectedTransactionTerm).balance}
                loading={loadingTermMetrics}
              />
            </div>
            <div className="flex-1">
              <Frame1707478528 
                schoolId={schoolId}
                selectedTerm={selectedTransactionTerm}
                transactions={transactionData}
                totalRevenue={getTermSpecificMetrics(selectedTransactionTerm).revenue}
                totalCollected={getTermSpecificMetrics(selectedTransactionTerm).revenue - getTermSpecificMetrics(selectedTransactionTerm).outstanding}
                outstandingBalance={getTermSpecificMetrics(selectedTransactionTerm).outstanding}
                loading={loadingTermMetrics}
                onViewDetails={handleViewTransactionDetails}
              />
            </div>
          </div>
        </div>
      );
    }

    if (activeNavItem === 'customer-management') {
      return (
        <div className="flex-1">
          <div className="w-full flex flex-col">
            {/* Fixed Header */}
            <div className="flex-shrink-0 px-6 py-4 bg-[#f8f8f8] border-b border-gray-200">
              <div className="mb-4 bg-[#f8f8f8]">
                <h1 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-[24px]">
                  Customer Management
                </h1>
              </div>
              <Frame1707478669 
                totalCustomers={customerData.totalCustomers}
                activeCustomers={customerData.activeCustomers}
                newCustomersThisMonth={customerData.newCustomersThisMonth}
                growthRate={customerData.customerGrowthRate}
                onAddCustomer={handleAddCustomer}
                onImportData={handleImportCustomerData}
                onExportData={handleExportCustomerData}
                onSendReminders={handleSendPaymentReminders}
                onBulkUpdate={handleBulkUpdate}
                onSearch={handleCustomerSearchChange}
              />
            </div>
            
            {/* Fixed Filters */}
            <div className="flex-shrink-0 px-6 py-3 bg-[#f8f8f8] border-b border-gray-100">
              <Frame1707478670 
                onSearchChange={handleCustomerSearchChange}
                onClassFilter={handleCustomerClassFilter}
                onStatusFilter={handleCustomerStatusFilter}
                onDateRangeFilter={handleCustomerDateRangeFilter}
                onSortChange={handleCustomerSortChange}
                onClearFilters={handleCustomerClearFilters}
                totalResults={transactionData.length}
                filteredResults={getActiveCustomerData().length}
                currentFilters={{
                  search: customerSearchQuery,
                  class: customerClassFilter,
                  status: customerStatusFilter,
                  dateRange: customerDateRangeFilter,
                  sort: customerSort
                }}
                isFiltering={isFiltering}
                selectedCount={selectedCustomers.size}
              />
            </div>
            
            {/* Content Area */}
            <div className="flex-1">
              <div className="p-6">
                <Frame1707478602 
                  customers={getPaginatedCustomerData()}
                  totalCustomers={getActiveCustomerData().length}
                  loading={loading || isFiltering || isPaginating || isBulkActionInProgress}
                  selectedCustomers={selectedCustomers}
                  onCustomerSelect={handleCustomerSelect}
                  onSelectAll={handleSelectAllCustomers}
                  onBulkAction={handleCustomerBulkAction}
                  onViewDetails={handleViewCustomerDetails}
                  onEditCustomer={handleEditCustomer}
                  onDeleteCustomer={handleDeleteCustomer}
                  onPaymentAction={handlePaymentAction}
                  customerStats={getCustomerStats()}
                />
              </div>
            </div>
            
            {/* Fixed Footer - Pagination */}
            <div className="flex-shrink-0 px-6 py-4 bg-[#f8f8f8] border-t border-gray-100">
              <div className="h-8 w-full">
                <PaginationContainer 
                  currentPage={currentPage}
                  totalPages={getTotalPages()}
                  totalItems={getActiveCustomerData().length}
                  itemsPerPage={itemsPerPage}
                  onPageChange={handlePageChange}
                  onItemsPerPageChange={handleItemsPerPageChange}
                  loading={isPaginating}
                  disabled={loading || isFiltering || isBulkActionInProgress}
                />
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (activeNavItem === 'tasks') {
      return (
        <div className="flex-1">
          <div className="w-full">
            <div className="bg-background">
              <div className="p-6">
                <div className="w-full max-w-7xl mx-auto flex flex-col gap-6">
                  {/* Tasks Header */}
                  <div className="relative w-full flex-shrink-0" style={{ height: '50px' }}>
                    <Group1000005066 
                      pendingTasks={dashboardMetrics.pendingTasks || 0}
                      completedTasks={dashboardMetrics.completedTasks || 0}
                      totalTasks={(dashboardMetrics.pendingTasks || 0) + (dashboardMetrics.completedTasks || 0)}
                    />
                  </div>
                  
                  {/* Calendar Tasks Component */}
                  <div className="relative w-full flex-shrink-0" style={{ height: '320px' }}>
                    <Frame1707478778New 
                      upcomingDeadlines={Math.floor(dashboardMetrics.overduePayments / 2)}
                      eventsThisWeek={dashboardMetrics.pendingTasks || 0}
                      selectedDate={new Date()}
                    />
                  </div>
                  
                  {/* Task Management Component */}
                  <div className="relative w-full flex-shrink-0" style={{ height: '300px' }}>
                    <Group1000005058New 
                      tasks={[
                        {
                          id: 'task_001',
                          title: 'Review overdue payments',
                          status: 'pending',
                          priority: 'high',
                          dueDate: new Date().toISOString(),
                          assignee: 'Admin'
                        },
                        {
                          id: 'task_002',
                          title: 'Process new enrollments',
                          status: 'in-progress',
                          priority: 'medium',
                          dueDate: new Date(Date.now() + 86400000).toISOString(),
                          assignee: 'Admin'
                        },
                        {
                          id: 'task_003',
                          title: 'Generate monthly report',
                          status: 'completed',
                          priority: 'low',
                          dueDate: new Date(Date.now() - 86400000).toISOString(),
                          assignee: 'Admin'
                        }
                      ]}
                      onTaskUpdate={(taskId, status) => {
                        console.log(`Task ${taskId} updated to ${status}`);
                        // Update task counts
                        if (status === 'completed') {
                          setDashboardMetrics(prev => ({
                            ...prev,
                            completedTasks: (prev.completedTasks || 0) + 1,
                            pendingTasks: Math.max(0, (prev.pendingTasks || 0) - 1)
                          }));
                        }
                      }}
                    />
                  </div>
                  
                  {/* Extra spacing to ensure scroll */}
                  <div className="h-4 flex-shrink-0"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (activeNavItem === 'wallet') {
      return (
        <div className="flex-1">
          <div className="w-full">
            <div className="bg-[#f8f8f8]">
              <div className="p-6">
                <div className="w-full max-w-7xl mx-auto flex flex-col gap-6">
                  {/* Wallet Card */}
                  <div className="relative h-[240px] w-full flex-shrink-0">
                    <Group1000005064Wallet 
                      balance={dashboardMetrics.walletBalance || 0}
                      monthlyGrowth={dashboardMetrics.monthlyGrowth || 0}
                      totalTransactions={dashboardMetrics.totalTransactions || 0}
                      pendingWithdrawals={Math.floor((dashboardMetrics.walletBalance || 0) * 0.1)}
                      onWithdraw={handleWithdraw}
                      onViewHistory={handleViewHistory}
                      onDownloadStatement={handleDownloadStatement}
                      onWalletSettings={handleWalletSettings}
                      onTransferFunds={handleTransferFunds}
                      onViewBalanceDetails={handleViewBalanceDetails}
                    />
                  </div>
                  
                  {/* Transaction History Table */}
                  <div className="relative w-full flex-shrink-0" style={{ height: '700px' }}>
                    <Group1000005063 
                      transactions={transactionData}
                      walletBalance={dashboardMetrics.walletBalance || 0}
                      loading={loading}
                      onViewTransaction={(transactionId) => {
                        console.log(`Viewing transaction: ${transactionId}`);
                        toast.info(`Viewing transaction details: ${transactionId}`);
                      }}
                      onExportTransactions={() => {
                        toast.success("Transaction export initiated. Your CSV file will be ready shortly.");
                        console.log("Exporting wallet transactions");
                      }}
                      onFilterTransactions={(filter) => {
                        console.log(`Applying transaction filter: ${filter}`);
                      }}
                      onSortTransactions={(sortBy, order) => {
                        console.log(`Sorting transactions by ${sortBy} in ${order} order`);
                      }}
                    />
                  </div>
                  
                  {/* Extra spacing to ensure scroll */}
                  <div className="h-4 flex-shrink-0"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (activeNavItem === 'settings') {
      return (
        <div className="flex-1">
          <div className="w-full">
            <div className="bg-background">
              <div className="p-6">
                <div className="w-full max-w-7xl mx-auto flex flex-col gap-8">
                  {/* Settings Header */}
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h1 className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-[24px] mb-2">
                          Settings & Configuration
                        </h1>
                        <p className="text-gray-600 text-sm">
                          Manage your school's account, security, and system preferences
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        {isDirty && (
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                            <span className="text-sm text-orange-600">Unsaved changes</span>
                          </div>
                        )}
                        <button
                          onClick={handleSaveAllSettings}
                          disabled={!isDirty || isUpdating}
                          className={`px-4 py-2 rounded-md transition-colors ${
                            isDirty && !isUpdating
                              ? 'bg-[#003049] text-white hover:bg-[#004060]'
                              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                          }`}
                        >
                          {isUpdating ? 'Saving...' : 'Save All'}
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Figma Settings Design Component */}
                  <div className="relative w-full flex-shrink-0">
                    <FunctionalSettingsForm 
                      schoolName={schoolProfile.schoolName}
                      contactEmail={schoolProfile.contactEmail}
                      phoneNumber={schoolProfile.phoneNumber}
                      address={schoolProfile.address}
                      website={schoolProfile.website}
                      organizationalCategory={schoolProfile.language}
                      onSchoolNameChange={(value) => updateSettingsState({
                        schoolProfile: { ...schoolProfile, schoolName: value }
                      })}
                      onContactEmailChange={(value) => updateSettingsState({
                        schoolProfile: { ...schoolProfile, contactEmail: value }
                      })}
                      onPhoneNumberChange={(value) => updateSettingsState({
                        schoolProfile: { ...schoolProfile, phoneNumber: value }
                      })}
                      onAddressChange={(value) => updateSettingsState({
                        schoolProfile: { ...schoolProfile, address: value }
                      })}
                      onWebsiteChange={(value) => updateSettingsState({
                        schoolProfile: { ...schoolProfile, website: value }
                      })}
                      onOrganizationalCategoryChange={(value) => updateSettingsState({
                        schoolProfile: { ...schoolProfile, language: value }
                      })}
                      onPasswordChange={handlePasswordChange}
                      onLogoUpload={(file) => updateSettingsState({
                        schoolProfile: { ...schoolProfile, logo: file }
                      })}
                      onSave={() => handleAccountUpdate(schoolProfile)}
                      isUpdating={isUpdating}
                      onSectionChange={(section) => {
                        // Handle section navigation if needed
                        console.log(`Settings section changed to: ${section}`);
                        if (section === 'users') {
                          toast.info('User management will be available in the next update');
                        } else if (section === 'banking') {
                          toast.info('Banking configuration will be available in the next update');
                        } else if (section === 'pricing') {
                          toast.info('Pricing structure management will be available in the next update');
                        } else if (section === 'verification') {
                          toast.info('Account verification will be available in the next update');
                        } else if (section === 'billing') {
                          toast.info('Subscription & billing management will be available in the next update');
                        }
                      }}
                    />
                  </div>
                  
                  {/* Additional Settings Sections */}
                  <div className="flex-shrink-0">
                    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 lg:p-8">
                      <div className="mb-8">
                        <h2 className="text-xl lg:text-2xl font-semibold text-gray-900 mb-2 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif]">
                          Advanced Settings
                        </h2>
                        <p className="text-sm lg:text-base text-gray-600 font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif]">
                          Configure system preferences, security, and integration settings
                        </p>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 lg:gap-6">
                        {/* Notifications Card */}
                        <div className="group bg-gradient-to-br from-blue-50 to-blue-100/50 rounded-xl p-5 lg:p-6 border border-blue-200 hover:border-blue-300 hover:shadow-lg transform hover:scale-[1.02] transition-all duration-300 cursor-pointer"
                             onClick={() => handleNotificationUpdate({
                               emailNotifications: !notifications.emailNotifications
                             })}
                             role="button"
                             tabIndex={0}
                             aria-label="Manage notification settings"
                             onKeyDown={(e) => {
                               if (e.key === 'Enter' || e.key === ' ') {
                                 e.preventDefault();
                                 handleNotificationUpdate({
                                   emailNotifications: !notifications.emailNotifications
                                 });
                               }
                             }}>
                          <div className="flex items-start justify-between mb-4">
                            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-blue-200 rounded-xl flex items-center justify-center group-hover:bg-blue-300 group-hover:scale-110 transition-all duration-300">
                              <svg className="w-5 h-5 lg:w-6 lg:h-6 text-blue-700 group-hover:text-blue-800 transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-5 5v-5zM4 18h7M4 14h9M4 10h12M4 6h15" />
                              </svg>
                            </div>
                            <div className={`w-3 h-3 rounded-full transition-all duration-300 ${
                              notifications.emailNotifications 
                                ? 'bg-green-500 shadow-lg shadow-green-500/30 animate-pulse' 
                                : 'bg-gray-300 group-hover:bg-gray-400'
                            }`}></div>
                          </div>
                          <h3 className="text-base lg:text-lg font-semibold text-gray-900 mb-2 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] group-hover:text-blue-900 transition-colors duration-300">
                            Notifications
                          </h3>
                          <p className="text-xs lg:text-sm text-gray-600 mb-4 font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] leading-relaxed">
                            Configure email, SMS, and push notification preferences for alerts and updates
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-medium text-blue-700 bg-blue-100 px-2 py-1 rounded-full">
                              {notifications.emailNotifications ? 'Active' : 'Inactive'}
                            </span>
                            <svg className="w-4 h-4 text-blue-600 group-hover:text-blue-800 group-hover:translate-x-1 transition-all duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                        
                        {/* Security Card */}
                        <div className="group bg-gradient-to-br from-red-50 to-red-100/50 rounded-xl p-5 lg:p-6 border border-red-200 hover:border-red-300 hover:shadow-lg transform hover:scale-[1.02] transition-all duration-300 cursor-pointer"
                             onClick={() => handleSecurityUpdate({
                               twoFactorAuth: !security.twoFactorAuth
                             })}
                             role="button"
                             tabIndex={0}
                             aria-label="Manage security settings"
                             onKeyDown={(e) => {
                               if (e.key === 'Enter' || e.key === ' ') {
                                 e.preventDefault();
                                 handleSecurityUpdate({
                                   twoFactorAuth: !security.twoFactorAuth
                                 });
                               }
                             }}>
                          <div className="flex items-start justify-between mb-4">
                            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-red-200 rounded-xl flex items-center justify-center group-hover:bg-red-300 group-hover:scale-110 transition-all duration-300">
                              <svg className="w-5 h-5 lg:w-6 lg:h-6 text-red-700 group-hover:text-red-800 transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                              </svg>
                            </div>
                            <div className={`w-3 h-3 rounded-full transition-all duration-300 ${
                              security.twoFactorAuth 
                                ? 'bg-green-500 shadow-lg shadow-green-500/30 animate-pulse' 
                                : 'bg-gray-300 group-hover:bg-gray-400'
                            }`}></div>
                          </div>
                          <h3 className="text-base lg:text-lg font-semibold text-gray-900 mb-2 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] group-hover:text-red-900 transition-colors duration-300">
                            Security
                          </h3>
                          <p className="text-xs lg:text-sm text-gray-600 mb-4 font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] leading-relaxed">
                            Two-factor authentication, session management, and advanced access control
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-medium text-red-700 bg-red-100 px-2 py-1 rounded-full">
                              {security.twoFactorAuth ? '2FA Enabled' : '2FA Disabled'}
                            </span>
                            <svg className="w-4 h-4 text-red-600 group-hover:text-red-800 group-hover:translate-x-1 transition-all duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                        
                        {/* System Card */}
                        <div className="group bg-gradient-to-br from-green-50 to-green-100/50 rounded-xl p-5 lg:p-6 border border-green-200 hover:border-green-300 hover:shadow-lg transform hover:scale-[1.02] transition-all duration-300 cursor-pointer"
                             onClick={() => handleSystemUpdate({
                               autoBackup: !system.autoBackup
                             })}
                             role="button"
                             tabIndex={0}
                             aria-label="Manage system settings"
                             onKeyDown={(e) => {
                               if (e.key === 'Enter' || e.key === ' ') {
                                 e.preventDefault();
                                 handleSystemUpdate({
                                   autoBackup: !system.autoBackup
                                 });
                               }
                             }}>
                          <div className="flex items-start justify-between mb-4">
                            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-green-200 rounded-xl flex items-center justify-center group-hover:bg-green-300 group-hover:scale-110 transition-all duration-300">
                              <svg className="w-5 h-5 lg:w-6 lg:h-6 text-green-700 group-hover:text-green-800 transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                              </svg>
                            </div>
                            <div className={`w-3 h-3 rounded-full transition-all duration-300 ${
                              system.autoBackup 
                                ? 'bg-green-500 shadow-lg shadow-green-500/30 animate-pulse' 
                                : 'bg-gray-300 group-hover:bg-gray-400'
                            }`}></div>
                          </div>
                          <h3 className="text-base lg:text-lg font-semibold text-gray-900 mb-2 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] group-hover:text-green-900 transition-colors duration-300">
                            System
                          </h3>
                          <p className="text-xs lg:text-sm text-gray-600 mb-4 font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] leading-relaxed">
                            Automatic backups, data retention policies, and system preferences
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-medium text-green-700 bg-green-100 px-2 py-1 rounded-full">
                              {system.autoBackup ? 'Auto Backup' : 'Manual Backup'}
                            </span>
                            <svg className="w-4 h-4 text-green-600 group-hover:text-green-800 group-hover:translate-x-1 transition-all duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                        
                        {/* Integrations Card */}
                        <div className="group bg-gradient-to-br from-purple-50 to-purple-100/50 rounded-xl p-5 lg:p-6 border border-purple-200 hover:border-purple-300 hover:shadow-lg transform hover:scale-[1.02] transition-all duration-300 cursor-pointer"
                             onClick={() => setActiveNavItem('integrations')}
                             role="button"
                             tabIndex={0}
                             aria-label="Manage integrations"
                             onKeyDown={(e) => {
                               if (e.key === 'Enter' || e.key === ' ') {
                                 e.preventDefault();
                                 setActiveNavItem('integrations');
                               }
                             }}>
                          <div className="flex items-start justify-between mb-4">
                            <div className="w-10 h-10 lg:w-12 lg:h-12 bg-purple-200 rounded-xl flex items-center justify-center group-hover:bg-purple-300 group-hover:scale-110 transition-all duration-300">
                              <svg className="w-5 h-5 lg:w-6 lg:h-6 text-purple-700 group-hover:text-purple-800 transition-colors duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                              </svg>
                            </div>
                            <div className="flex items-center gap-1">
                              <div className={`w-2 h-2 rounded-full transition-all duration-300 ${
                                integrations.quickbooksEnabled 
                                  ? 'bg-green-500 shadow-sm shadow-green-500/30' 
                                  : 'bg-gray-300'
                              }`}></div>
                              <div className={`w-2 h-2 rounded-full transition-all duration-300 ${
                                integrations.stripeEnabled 
                                  ? 'bg-green-500 shadow-sm shadow-green-500/30' 
                                  : 'bg-gray-300'
                              }`}></div>
                              <div className={`w-2 h-2 rounded-full transition-all duration-300 ${
                                integrations.mpesaEnabled 
                                  ? 'bg-green-500 shadow-sm shadow-green-500/30' 
                                  : 'bg-gray-300'
                              }`}></div>
                            </div>
                          </div>
                          <h3 className="text-base lg:text-lg font-semibold text-gray-900 mb-2 font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] group-hover:text-purple-900 transition-colors duration-300">
                            Integrations
                          </h3>
                          <p className="text-xs lg:text-sm text-gray-600 mb-4 font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] leading-relaxed">
                            Connect with QuickBooks, Stripe, M-Pesa, and other business services
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-medium text-purple-700 bg-purple-100 px-2 py-1 rounded-full">
                              {[integrations.quickbooksEnabled, integrations.stripeEnabled, integrations.mpesaEnabled].filter(Boolean).length} Connected
                            </span>
                            <svg className="w-4 h-4 text-purple-600 group-hover:text-purple-800 group-hover:translate-x-1 transition-all duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                      </div>
                      
                      {/* Quick Actions Bar */}
                      <div className="mt-8 pt-6 border-t border-gray-200">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                          <div>
                            <h4 className="text-sm font-medium text-gray-900 font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif]">
                              Quick Actions
                            </h4>
                            <p className="text-xs text-gray-600 font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif]">
                              Commonly used settings and configuration options
                            </p>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <button
                              onClick={handleSystemDiagnostics}
                              disabled={isUpdating}
                              className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 hover:text-gray-900 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
                              aria-label="Run system diagnostics">
                              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              {isUpdating ? 'Running...' : 'Run Diagnostics'}
                            </button>
                            <button
                              onClick={() => handleBackupManagement('create')}
                              disabled={isUpdating}
                              className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-blue-700 bg-blue-100 rounded-lg hover:bg-blue-200 hover:text-blue-900 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
                              aria-label="Create system backup">
                              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3-3m0 0l-3 3m3-3v12" />
                              </svg>
                              Create Backup
                            </button>
                            <button
                              onClick={() => handleDataExport('csv', 'all')}
                              disabled={isUpdating}
                              className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-green-700 bg-green-100 rounded-lg hover:bg-green-200 hover:text-green-900 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
                              aria-label="Export all data">
                              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                              </svg>
                              Export Data
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* System Status Footer */}
                  <div className="flex-shrink-0">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-2">
                            <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
                            <span className="text-sm font-medium">System Status: {isConnected ? 'Online' : 'Offline'}</span>
                          </div>
                          <div className="text-sm text-gray-500">
                            Last updated: {settingsState.lastUpdated.toLocaleTimeString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {isDirty && (
                            <button
                              onClick={handleDiscardChanges}
                              className="text-sm text-gray-600 hover:text-gray-800"
                            >
                              Discard Changes
                            </button>
                          )}
                          <div className="text-sm text-gray-500">
                            {dashboardMetrics.activeUsers || 0} active users
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Extra spacing to ensure scroll */}
                  <div className="h-4 flex-shrink-0"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    // Enhanced dashboard content with real data
    return (
      <div className="flex-1 p-4">
        <div className="flex gap-4 min-h-0">
          {/* Left Section - Charts and Metrics */}
          <div className="flex-[1] min-w-0 flex flex-col gap-4">
            {/* Revenue Chart Section */}
            <div className="flex-1 bg-[rgba(239,234,234,1)] rounded-[3px]">
              {/* Revenue Recovery Chart */}
              <div className="relative w-full h-[280px] bg-white shadow-lg rounded-lg mx-auto">
                {/* Chart Header */}
                <div className="absolute top-4 right-4 flex flex-col gap-1.5 items-end">
                  <div className="flex items-center gap-4">
                    <div className="flex gap-3 items-center text-[16px]">
                      <button
                        onClick={() => setSelectedPeriod(selectedPeriod === 'Term 2' ? 'Term 1' : 'Term 2')}
                        className="font-['Inter:Bold',_sans-serif] font-bold hover:text-[#003049] transition-colors"
                        aria-label={`Switch to ${selectedPeriod === 'Term 2' ? 'Term 1' : 'Term 2'}`}
                      >
                        {selectedPeriod}
                      </button>
                      <button
                        onClick={() => setSelectedYear(selectedYear === '2025' ? '2024' : '2025')}
                        className="font-['Inter:Regular',_sans-serif] hover:text-[#003049] transition-colors"
                        aria-label={`Switch to year ${selectedYear === '2025' ? '2024' : '2025'}`}
                      >
                        {selectedYear}
                      </button>
                    </div>
                  </div>
                  <div className="flex gap-2 items-center">
                    <button
                      onClick={handleCompare}
                      className="bg-[#e9f1ef] px-2.5 py-1 rounded-md hover:bg-[#d0e7e1] transition-colors"
                      aria-label="Compare with previous period"
                    >
                      <div className="font-['Inter:Medium',_sans-serif] text-[#025864] text-[8px]">Compare</div>
                    </button>
                    <button 
                      onClick={handleSettings} 
                      className="size-[13px] hover:opacity-70 transition-opacity"
                      aria-label="Chart settings"
                    >
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
                        <path d={svgPaths.p1f4f2480} fill="#025864" />
                        <path d={svgPaths.p217b6f00} fill="#025864" />
                      </svg>
                    </button>
                    <button 
                      onClick={handleMaximize} 
                      className="size-[13px] hover:opacity-70 transition-opacity"
                      aria-label="Maximize chart"
                    >
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
                        <path d="M11.375 4.875V1.625H8.125" stroke="#025864" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
                        <path d="M1.625 8.125V11.375H4.875" stroke="#025864" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
                        <path d="M11.375 1.625L7.3125 5.6875" stroke="#025864" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
                        <path d="M5.6875 7.3125L1.625 11.375" stroke="#025864" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.75" />
                      </svg>
                    </button>
                  </div>
                </div>

                {/* Chart Title */}
                <div className="absolute top-4 left-6">
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <div className="size-2.5 rotate-90 scale-y-[-100%]">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
                        <path d={svgPaths.pcb65b60} stroke="#171717" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" />
                      </svg>
                    </div>
                    <div className="font-['Inter:Semi_Bold',_sans-serif] text-[18px]">Revenue Recovery</div>
                    <div className="size-2.5 rotate-90">
                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
                        <path d={svgPaths.pcb65b60} stroke="#171717" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" />
                      </svg>
                    </div>
                  </div>
                  <div className="flex gap-1.5 items-center ml-4">
                    <div className="bg-[#c0f1e5] px-2 py-0.5 rounded-[20px]">
                      <div className="font-['Inter:Extra_Bold',_sans-serif] text-[#02424b] text-[8px]">
                        {selectedPeriod === 'Term 2' ? `+${dashboardMetrics.monthlyGrowth?.toFixed(1) || 8}%` : '+5%'}
                      </div>
                    </div>
                    <div className="bg-[#c0f1e5] px-2 py-[3px] rounded-[20px] flex items-center gap-2">
                      <div className="size-1.5">
                        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 6">
                          <circle cx="3" cy="3" fill="white" r="2.5" stroke="#025864" />
                        </svg>
                      </div>
                      <div className="font-['Inter:Semi_Bold',_sans-serif] text-[#025964] text-[8px]">
                        Collected: {formatCurrency(dashboardMetrics.totalRevenue)}
                      </div>
                      <div className="font-['Inter:Semi_Bold',_sans-serif] text-[#025964] text-[8px]">
                        Outstanding: {formatCurrency(dashboardMetrics.outstandingFees)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Interactive Chart Bars */}
                <div className="absolute bottom-16 left-14 right-14 top-24">
                  <div className="relative h-full">
                    {['Jan', 'Feb', 'Mar', 'April'].map((month, index) => {
                      // Calculate heights based on real data
                      const collectionRate = dashboardMetrics.collectionRate;
                      const heights = selectedPeriod === 'Term 2' 
                        ? [`${Math.max(20, collectionRate * 0.6)}%`, `${Math.max(25, collectionRate * 0.7)}%`, `${Math.max(30, collectionRate * 0.8)}%`, `${Math.min(85, collectionRate)}%`]
                        : [`${Math.max(15, collectionRate * 0.5)}%`, `${Math.max(20, collectionRate * 0.6)}%`, `${Math.max(25, collectionRate * 0.7)}%`, `${Math.min(75, collectionRate * 0.9)}%`];
                      const height = heights[index];
                      const isActive = index === 3; // April is active
                      
                      return (
                        <button
                          key={month}
                          onClick={() => toast.info(`Viewing ${month} ${selectedYear} revenue details: ${formatCurrency(dashboardMetrics.totalRevenue * (index + 1) * 0.25)}`)}
                          className={`absolute bottom-0 w-[8%] rounded-lg transition-all hover:opacity-80 ${
                            isActive 
                              ? 'bg-[#025964] border border-[#003049]' 
                              : 'bg-[#eaedf1] hover:bg-[#d0d4d9]'
                          }`}
                          style={{ 
                            height, 
                            left: `${10 + index * 20}%`
                          }}
                          aria-label={`View ${month} revenue data`}
                        />
                      );
                    })}
                  </div>
                </div>

                {/* Y-Axis Labels */}
                <div className="absolute left-2 top-20 bottom-20 w-12 flex flex-col justify-between">
                  {['100%', '90%', '80%', '70%', '60%', '50%', '40%', '30%', '20%', '10%'].map((percentage) => (
                    <div key={percentage} className="font-['Inter:Regular',_sans-serif] text-[#808080] text-[8px]">
                      {percentage}
                    </div>
                  ))}
                </div>

                {/* X-Axis Labels */}
                <div className="absolute bottom-4 left-14 right-14 flex justify-around">
                  {['Jan', 'Feb', 'Mar', 'April'].map((month) => (
                    <div key={month} className="font-['Inter:Regular',_sans-serif] text-[8px]">
                      {month}
                    </div>
                  ))}
                </div>

                {/* Goal Indicators */}
                <div className="absolute left-6 top-24">
                  <div className="bg-[#ecf3f1] px-[7px] py-[3px] rounded-[10px] mb-12">
                    <div className="font-['Inter:Semi_Bold',_sans-serif] text-[#025864] text-[8px]">Target: 95%</div>
                  </div>
                  <div className="bg-[#025864] px-[7px] py-[3px] rounded-[10px]">
                    <div className="font-['Inter:Semi_Bold',_sans-serif] text-white text-[8px]">
                      Current: {dashboardMetrics.collectionRate}%
                    </div>
                  </div>
                </div>
              </div>

              {/* Revenue Breakdown Component */}
              <div className="w-full mt-3">
                <Group1000005059 
                  schoolId={schoolId}
                  totalRevenue={dashboardMetrics.totalRevenue}
                  outstandingFees={dashboardMetrics.outstandingFees}
                  collectionRate={dashboardMetrics.collectionRate}
                  totalTransactions={dashboardMetrics.totalTransactions || 0}
                  monthlyGrowth={dashboardMetrics.monthlyGrowth || 0}
                  loading={loading}
                  onViewTransactions={() => {
                    setActiveNavItem('transactions');
                    console.log('Navigated to Transactions from breakdown');
                  }}
                />
              </div>
            </div>
          </div>

          {/* Right Section - Updates and Notifications */}
          <div className="flex-[1] bg-white rounded-lg shadow-sm min-w-0">
            <div className="relative min-h-[520px] w-full">
              {/* Updates Header */}
              <div className="absolute top-6 left-6 right-6 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] text-[#1f1f20] text-[18px]">
                    Live Updates
                  </div>
                  <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-[8px] ${
                    isConnected ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                  }`}>
                    <div className={`w-2 h-2 rounded-full ${
                      isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                    }`}></div>
                    {isConnected ? 'Online' : 'Offline'}
                  </div>
                  <button
                    onClick={refreshDashboard}
                    className="text-xs text-gray-500 hover:text-gray-700 underline ml-2"
                    disabled={loading}
                    aria-label="Refresh dashboard data"
                  >
                    {loading ? 'Refreshing...' : 'Refresh'}
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleMarkAllAsRead}
                    className="bg-[#025864] text-white px-3 py-1.5 rounded-md hover:opacity-80 transition-opacity"
                    disabled={unreadCount === 0}
                    aria-label="Mark all notifications as read"
                  >
                    <div className="font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] text-[10px] whitespace-nowrap">
                      Mark all read
                    </div>
                  </button>
                  <div className="bg-[#e91f63] text-white px-2 py-0.5 rounded-[19px] min-w-[25px] text-center">
                    <div className="font-['Roboto:Bold',_sans-serif] text-[9px]">{unreadCount}</div>
                  </div>
                </div>
              </div>

              {/* Notifications List */}
              <div className="absolute top-20 left-6 right-6 bottom-6 max-h-[400px] overflow-y-auto">
                {realtimeNotifications.length === 0 ? (
                  <div className="text-center text-gray-500 mt-8">
                    <div className="mb-4">
                      <svg className="w-12 h-12 mx-auto text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-5 5v-5zM9.586 14.414l.707-.707A2 2 0 0111.414 13H14a2 2 0 012 2v3a2 2 0 01-2 2h-2.586l-.707-.707A2 2 0 019.586 18.586L8.172 17.172a2 2 0 010-2.828l1.414-1.414z" />
                      </svg>
                    </div>
                    <p className="text-sm mb-2">No notifications</p>
                    <p className="text-xs text-gray-400 mb-4">Real-time notifications will appear here when customers make payments or enroll</p>
                    <p className="text-xs text-gray-400">Last updated: {formatTimeAgo(lastRefresh.toISOString())}</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {realtimeNotifications.map((notification) => (
                      <button
                        key={notification.id}
                        onClick={() => handleMarkAsRead(notification.id)}
                        className={`w-full text-left p-3 rounded-lg border transition-all hover:shadow-sm transform hover:scale-[1.02] ${
                          notification.read 
                            ? 'bg-gray-50 border-gray-200 opacity-75' 
                            : 'bg-white border-gray-300 shadow-sm ring-1 ring-blue-100'
                        }`}
                        aria-label={`Mark ${notification.title} as read`}
                      >
                        <div className="flex items-start justify-between mb-1">
                          <div className={`text-[12px] font-medium flex items-center gap-2 ${
                            notification.type === 'error' ? 'text-red-600' :
                            notification.type === 'warning' ? 'text-orange-600' :
                            notification.type === 'success' ? 'text-green-600' :
                            'text-blue-600'
                          }`}>
                            {notification.type === 'success' && (
                              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                              </svg>
                            )}
                            {notification.type === 'info' && (
                              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                              </svg>
                            )}
                            {notification.type === 'warning' && (
                              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                              </svg>
                            )}
                            {notification.title}
                          </div>
                          <div className="text-[10px] text-gray-500">
                            {formatTimeAgo(notification.timestamp)}
                          </div>
                        </div>
                        <div className="text-[11px] text-gray-700 leading-relaxed">
                          {notification.message}
                        </div>
                        <div className="flex items-center justify-between mt-2">
                          <div className={`w-2 h-2 rounded-full ${
                            notification.type === 'error' ? 'bg-red-400' :
                            notification.type === 'warning' ? 'bg-orange-400' :
                            notification.type === 'success' ? 'bg-green-400' :
                            'bg-blue-400'
                          }`} />
                          <div className="flex items-center gap-2">
                            {notification.metadata?.amount && (
                              <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full text-[8px]">
                                {formatCurrency(notification.metadata.amount)}
                              </span>
                            )}
                            {!notification.read && (
                              <div className="w-2 h-2 bg-[#e91f63] rounded-full animate-pulse" />
                            )}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="bg-[#f8f8f8] min-h-screen w-screen flex max-w-full">
      {/* Sidebar */}
      <motion.div 
        className={`bg-[#f5f7f9] border-r border-[#e8e8e8] flex flex-col transition-all duration-300 ${
          sidebarCollapsed ? 'w-16' : 'w-56'
        } min-w-0 sticky top-0 self-start min-h-screen`}
        animate={isLoggingOut ? { opacity: 0.6, scale: 0.98 } : { opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
      >
        {/* Logo and Hamburger */}
        <div className="flex items-center justify-between p-3 border-b border-[#e8e8e8]">
          <div className="flex items-center gap-3">
            <div className="size-[22px] flex-shrink-0">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
                <path d={svgPaths.p2b19d800} fill="#003049" />
                <path d={svgPaths.p30679380} stroke="#5DFCAF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" />
              </svg>
            </div>
            {!sidebarCollapsed && (
              <div className="font-['Baloo_Bhaina:Regular',_sans-serif] text-[#003049] text-[20px]">
                Master-Fees
              </div>
            )}
          </div>
          <button
            onClick={toggleSidebar}
            className="p-1.5 hover:bg-gray-200 rounded-md transition-colors"
            aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none">
              <path d="M3 12H21M3 6H21M3 18H21" stroke="#003049" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto max-h-[calc(100vh-120px)]">
          {/* General Navigation */}
          <div className="p-3">
            <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic text-[#9ca0a4] text-[11px] text-left mb-3">
              {!sidebarCollapsed && <p className="block leading-[1.2]">GENERAL</p>}
            </div>
            <div className="space-y-1">
              {generalNavItems.map(renderNavItem)}
            </div>
          </div>

          {/* Support Navigation */}
          <div className="p-4">
            <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] not-italic text-[#9ca0a4] text-[11px] text-left mb-3">
              {!sidebarCollapsed && <p className="block leading-[1.2]">SUPPORT</p>}
            </div>
            <div className="space-y-1">
              {supportNavItems.map(renderNavItem)}
            </div>
          </div>
        </div>

        {/* Footer */}
        {!sidebarCollapsed && (
          <div className="p-4 border-t border-[#e8e8e8]">
            <div className="text-center font-['Microsoft_Sans_Serif:Regular',_sans-serif] text-[#707479] text-[8px]">
              <p className="block leading-[1.2]">
                © 2025 Master-Fees Ltd.
                <br />
                All Rights Reserved
              </p>
            </div>
          </div>
        )}
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Header - Hide on integrations, customer-care, and transaction-details pages */}
        {activeNavItem !== 'integrations' && activeNavItem !== 'customer-care' && activeNavItem !== 'transaction-details' && (
          <header className="bg-[#f8f8f8] p-3 flex-shrink-0" role="banner">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] text-[#000000] text-[16px]">
                  {schoolName}
                </div>
                {isConnected && (
                  <div className="flex items-center gap-1 px-2 py-1 bg-green-100 rounded-full">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-green-700 text-[10px]">Live</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-4">
                {/* Wallet Info */}
                <button
                  onClick={handleWalletClick}
                  className="flex items-center gap-2.5 px-2.5 py-1 hover:bg-gray-50 transition-colors rounded-lg"
                  aria-label="View wallet details"
                >
                  <div className="size-5">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
                      <path d="M10.8333 7.5H5.83333" stroke="#003049" strokeLinecap="round" strokeLinejoin="round" />
                      <path d={svgPaths.pf0d1800} stroke="#003049" strokeLinecap="round" strokeLinejoin="round" />
                      <path d={svgPaths.p224d6600} stroke="#003049" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                  <div className="text-[#003049] text-left">
                    <div className="font-['IBM_Plex_Sans_Devanagari:SemiBold',_sans-serif] text-[14px] whitespace-nowrap">
                      {formatCurrency(dashboardMetrics.walletBalance || dashboardMetrics.totalRevenue)}
                    </div>
                    <div className="font-['Inter:Light',_sans-serif] text-[8px]">
                      Available Balance
                    </div>
                  </div>
                  <div className="size-3">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
                      <path d="M3 4.5L6 7.5L9 4.5" stroke="#003049" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                </button>

                {/* Withdraw Button */}
                <button
                  onClick={handleWithdraw}
                  className="bg-[#003049] text-white px-2.5 py-2.5 hover:bg-[#004060] transition-colors rounded"
                  disabled={isLoadingAction}
                  aria-label="Initiate withdrawal"
                >
                  <div className="font-['Inter:Semi_Bold',_sans-serif] text-[12px] whitespace-nowrap">
                    {isLoadingAction ? 'Processing...' : 'Withdraw'}
                  </div>
                </button>
              </div>
            </div>
          </header>
        )}

        {/* Main Content Area */}
        <main className="flex-1 bg-[rgba(255,255,255,0)]" role="main">
          {renderMainContent()}
        </main>
      </div>
    </div>

    {/* Logout Confirmation Modal */}
    <LogoutConfirmationModal
      isOpen={showLogoutConfirmation}
      onConfirm={handleConfirmLogout}
      onCancel={handleCancelLogout}
      schoolName={schoolName}
    />
  </>
  );
}

// Session management utilities
const saveSession = (sessionData: SessionData) => {
  try {
    if (sessionData.keepLoggedIn) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));
      console.log('💾 Session saved to localStorage');
    } else {
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));
      console.log('💾 Session saved to sessionStorage');
    }
  } catch (error) {
    console.error('Failed to save session:', error);
  }
};

const loadSession = (): SessionData | null => {
  try {
    // First try localStorage (persistent)
    const persistentSession = localStorage.getItem(SESSION_KEY);
    if (persistentSession) {
      const sessionData = JSON.parse(persistentSession);
      
      // Check if session has expired (24 hours)
      if (Date.now() - sessionData.loginTime > SESSION_DURATION) {
        localStorage.removeItem(SESSION_KEY);
        console.log('🔄 Persistent session expired and removed');
        return null;
      }
      
      console.log('🔓 Restored persistent session from localStorage');
      return sessionData;
    }
    
    // Then try sessionStorage (current tab only)
    const sessionData = sessionStorage.getItem(SESSION_KEY);
    if (sessionData) {
      console.log('🔓 Restored session from sessionStorage');
      return JSON.parse(sessionData);
    }
    
    return null;
  } catch (error) {
    console.error('Failed to load session:', error);
    return null;
  }
};

const clearSession = () => {
  try {
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
    console.log('🗑️ All sessions cleared');
  } catch (error) {
    console.error('Failed to clear session:', error);
  }
};

export default function App() {
  const [appState, setAppState] = useState<'login' | 'signup' | 'forgot-password' | 'reset-password' | 'onboarding' | 'detailed-onboarding' | 'final-onboarding' | 'pricing-structure' | 'class-selection' | 'product-groups' | 'dashboard' | 'loading'>('loading');
  const [schoolName, setSchoolName] = useState('Twalumbu Education Centre');
  const [schoolId, setSchoolId] = useState<string>('admin_school_demo');
  const [tempSchoolName, setTempSchoolName] = useState('');
  const [basicFormData, setBasicFormData] = useState<FormData>({
    schoolName: '',
    institutionType: '',
    country: '',
    state: '',
    town: ''
  });
  const [extendedFormData, setExtendedFormData] = useState<ExtendedFormData>({
    schoolName: '',
    institutionType: '',
    country: '',
    state: '',
    town: '',
    schoolEmail: '',
    contactNumbers: '',
    physicalAddress: '',
    schoolCategories: '',
    schoolLogo: null
  });
  const [completePricingData, setCompletePricingData] = useState<CompletePricingData>({
    schoolName: '',
    institutionType: '',
    country: '',
    state: '',
    town: '',
    schoolEmail: '',
    contactNumbers: '',
    physicalAddress: '',
    schoolCategories: '',
    schoolLogo: null,
    selectedGrades: [],
    classesPerGrade: 0,
    exceptions: ''
  });
  const [classSelectionData, setClassSelectionData] = useState<ClassSelectionData>({
    schoolName: '',
    institutionType: '',
    country: '',
    state: '',
    town: '',
    schoolEmail: '',
    contactNumbers: '',
    physicalAddress: '',
    schoolCategories: '',
    schoolLogo: null,
    selectedGrades: [],
    classesPerGrade: 0,
    exceptions: '',
    selectedClasses: []
  });

  // Forgot password state
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
  const [forgotPasswordPhone, setForgotPasswordPhone] = useState('');
  const [forgotPasswordMethod, setForgotPasswordMethod] = useState<'email' | 'sms'>('email');

  // Check for existing session on app load
  useEffect(() => {
    const checkExistingSession = () => {
      const existingSession = loadSession();
      
      if (existingSession) {
        console.log('🎯 Found existing session, logging user in automatically');
        setSchoolId(existingSession.schoolId);
        setSchoolName(existingSession.schoolName);
        setAppState('dashboard');
        toast.success(`Welcome back to Master-Fees, ${existingSession.schoolName}!`);
      } else {
        console.log('🔒 No existing session found, showing login');
        setAppState('login');
      }
    };

    // Small delay to show loading state briefly
    const timer = setTimeout(checkExistingSession, 500);
    return () => clearTimeout(timer);
  }, []);

  const handleLogin = (schoolId: string, schoolName: string, accessToken: string, keepLoggedIn: boolean = false) => {
    console.log('🔑 Login successful with keepLoggedIn:', keepLoggedIn);
    
    const sessionData: SessionData = {
      schoolId: schoolId || 'admin_school_demo',
      schoolName: schoolName || 'Twalumbu Education Centre',
      accessToken: accessToken || 'demo_token',
      loginTime: Date.now(),
      keepLoggedIn
    };
    
    // Save session based on user preference
    saveSession(sessionData);
    
    setSchoolId(sessionData.schoolId);
    setSchoolName(sessionData.schoolName);
    setAppState('dashboard');
    
    const persistenceMessage = keepLoggedIn 
      ? "You'll stay logged in across browser sessions." 
      : "You'll be logged out when you close this tab.";
    
    toast.success(`Welcome to Master-Fees! ${persistenceMessage}`);
  };

  const handleSignup = () => {
    setAppState('signup');
    console.log("Navigated to signup");
  };

  const handleSignupComplete = (schoolId: string, schoolName: string, accessToken: string) => {
    const sessionData: SessionData = {
      schoolId: schoolId || 'admin_school_demo',
      schoolName: schoolName || 'New School',
      accessToken: accessToken || 'demo_token',
      loginTime: Date.now(),
      keepLoggedIn: true // Default to keeping signup sessions persistent
    };
    
    saveSession(sessionData);
    
    setSchoolId(sessionData.schoolId);
    setSchoolName(sessionData.schoolName);
    setAppState('dashboard');
    toast.success(`Welcome to Master-Fees, ${schoolName}!`);
  };

  const handleBackToLogin = () => {
    setAppState('login');
  };

  const handleForgotPassword = () => {
    setAppState('forgot-password');
    console.log("Navigated to password reset");
  };

  const handleForgotPasswordCodeSent = (email: string, phone: string, method: 'email' | 'sms') => {
    setForgotPasswordEmail(email);
    setForgotPasswordPhone(phone);
    setForgotPasswordMethod(method);
    setAppState('reset-password');
    toast.success(`Reset code sent via ${method}`);
  };

  const handlePasswordReset = (schoolId: string, schoolName: string, accessToken: string) => {
    const sessionData: SessionData = {
      schoolId: schoolId || 'admin_school_demo',
      schoolName: schoolName || 'Twalumbu Education Centre',
      accessToken: accessToken || 'demo_token',
      loginTime: Date.now(),
      keepLoggedIn: true // Default to persistent for password resets
    };
    
    saveSession(sessionData);
    
    setSchoolId(sessionData.schoolId);
    setSchoolName(sessionData.schoolName);
    setAppState('dashboard');
    toast.success(`Password reset successful. Welcome back to ${schoolName}.`);
  };

  const handleResendCode = () => {
    setAppState('forgot-password');
    toast.info("Please request a new reset code");
  };

  const handleOnboardingNext = (enteredSchoolName: string) => {
    setTempSchoolName(enteredSchoolName);
    setAppState('detailed-onboarding');
    console.log("Proceeding to detailed onboarding");
  };

  const handleDetailedOnboardingComplete = (formData: FormData) => {
    setBasicFormData(formData);
    setAppState('final-onboarding');
    console.log("Proceeding to final onboarding");
  };

  const handleFinalOnboardingComplete = (formData: ExtendedFormData) => {
    setExtendedFormData(formData);
    setAppState('pricing-structure');
    console.log("Proceeding to pricing structure");
  };

  const handlePricingStructureComplete = (formData: CompletePricingData) => {
    setCompletePricingData(formData);
    setAppState('class-selection');
    console.log("Proceeding to class selection");
  };

  const handleClassSelectionComplete = (formData: ClassSelectionData) => {
    setClassSelectionData(formData);
    setAppState('product-groups');
    console.log("Proceeding to product groups");
  };

  const handleProductGroupComplete = async (formData: FinalOnboardingData) => {
    try {
      toast.info("Creating your school account...");
      
      // Create school in Supabase
      const response = await api.createSchool({
        schoolName: formData.schoolName,
        institutionType: formData.institutionType,
        country: formData.country,
        state: formData.state,
        town: formData.town,
        schoolEmail: formData.schoolEmail,
        contactNumbers: formData.contactNumbers,
        physicalAddress: formData.physicalAddress,
        schoolCategories: formData.schoolCategories,
        selectedGrades: formData.selectedGrades,
        classesPerGrade: formData.classesPerGrade,
        exceptions: formData.exceptions,
        selectedClasses: formData.selectedClasses,
        productGroups: formData.productGroups
      });

      if (response.success && response.schoolId) {
        const sessionData: SessionData = {
          schoolId: response.schoolId,
          schoolName: formData.schoolName,
          accessToken: 'onboarding_token',
          loginTime: Date.now(),
          keepLoggedIn: true // Onboarding sessions are persistent
        };
        
        saveSession(sessionData);
        
        setSchoolId(sessionData.schoolId);
        setSchoolName(sessionData.schoolName);
        setAppState('dashboard');
        
        toast.success(`Onboarding completed successfully! Welcome to Master-Fees, ${formData.schoolName}!`);
      } else {
        throw new Error(response.error || 'Failed to create school account');
      }
    } catch (error) {
      console.error('Error completing onboarding:', error);
      toast.error('Failed to complete onboarding. Please try again or contact support.');
    }
  };

  const handleBackToOnboarding = () => {
    setAppState('onboarding');
  };

  const handleBackToDetailedOnboarding = () => {
    setAppState('detailed-onboarding');
  };

  const handleBackToFinalOnboarding = () => {
    setAppState('final-onboarding');
  };

  const handleBackToPricingStructure = () => {
    setAppState('pricing-structure');
  };

  const handleBackToClassSelection = () => {
    setAppState('class-selection');
  };

  const handleStartOnboarding = () => {
    setAppState('onboarding');
    console.log("Started onboarding flow");
  };

  const handleLogout = () => {
    console.log('👋 User logging out - clearing all sessions');
    clearSession();
    
    setAppState('login');
    setSchoolName('Twalumbu Education Centre'); // Reset to default
    setSchoolId('admin_school_demo');
    setTempSchoolName('');
    
    // Reset all form data
    setBasicFormData({
      schoolName: '',
      institutionType: '',
      country: '',
      state: '',
      town: ''
    });
    setExtendedFormData({
      schoolName: '',
      institutionType: '',
      country: '',
      state: '',
      town: '',
      schoolEmail: '',
      contactNumbers: '',
      physicalAddress: '',
      schoolCategories: '',
      schoolLogo: null
    });
    setCompletePricingData({
      schoolName: '',
      institutionType: '',
      country: '',
      state: '',
      town: '',
      schoolEmail: '',
      contactNumbers: '',
      physicalAddress: '',
      schoolCategories: '',
      schoolLogo: null,
      selectedGrades: [],
      classesPerGrade: 0,
      exceptions: ''
    });
    setClassSelectionData({
      schoolName: '',
      institutionType: '',
      country: '',
      state: '',
      town: '',
      schoolEmail: '',
      contactNumbers: '',
      physicalAddress: '',
      schoolCategories: '',
      schoolLogo: null,
      selectedGrades: [],
      classesPerGrade: 0,
      exceptions: '',
      selectedClasses: []
    });
    
    toast.info("You have been signed out successfully");
    console.log("User signed out successfully");
  };

  // Loading state while checking session
  if (appState === 'loading') {
    return (
      <div className="w-screen min-h-screen flex items-center justify-center bg-[#f8f8f8]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#003049] mx-auto mb-4"></div>
          <div className="text-[#003049] text-base font-medium">Loading Master-Fees...</div>
          <div className="text-gray-500 text-sm mt-2">Checking for existing session</div>
        </div>
      </div>
    );
  }

  if (appState === 'login') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <FeeMasterLoginPage onLogin={handleLogin} onSignup={handleSignup} onForgotPassword={handleForgotPassword} />
      </div>
    );
  }

  if (appState === 'signup') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <SignupPage onSignup={handleSignupComplete} onBack={handleBackToLogin} />
      </div>
    );
  }

  if (appState === 'forgot-password') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <ForgotPasswordPage onCodeSent={handleForgotPasswordCodeSent} onBack={handleBackToLogin} />
      </div>
    );
  }

  if (appState === 'reset-password') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <ResetPasswordPage 
          email={forgotPasswordEmail}
          phone={forgotPasswordPhone}
          method={forgotPasswordMethod}
          onPasswordReset={handlePasswordReset}
          onBack={() => setAppState('forgot-password')}
          onResendCode={handleResendCode}
        />
      </div>
    );
  }

  if (appState === 'onboarding') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <OnboardingPage onComplete={handleOnboardingNext} onBack={handleStartOnboarding} />
      </div>
    );
  }

  if (appState === 'detailed-onboarding') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <DetailedOnboardingPage 
          onComplete={handleDetailedOnboardingComplete} 
          onBack={handleBackToOnboarding}
          initialSchoolName={tempSchoolName}
        />
      </div>
    );
  }

  if (appState === 'final-onboarding') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <FinalOnboardingPage 
          onComplete={handleFinalOnboardingComplete} 
          onBack={handleBackToDetailedOnboarding}
          basicFormData={basicFormData}
        />
      </div>
    );
  }

  if (appState === 'pricing-structure') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <PricingStructurePage 
          onComplete={handlePricingStructureComplete} 
          onBack={handleBackToFinalOnboarding}
          extendedFormData={extendedFormData}
        />
      </div>
    );
  }

  if (appState === 'class-selection') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <ClassSelectionPage 
          onComplete={handleClassSelectionComplete} 
          onBack={handleBackToPricingStructure}
          completePricingData={completePricingData}
        />
      </div>
    );
  }

  if (appState === 'product-groups') {
    return (
      <div className="relative w-screen min-h-screen max-w-[1366px] mx-auto">
        <ProductGroupPage 
          onComplete={handleProductGroupComplete} 
          onBack={handleBackToClassSelection}
          completePricingData={classSelectionData}
        />
      </div>
    );
  }

  return <Dashboard onLogout={handleLogout} schoolName={schoolName} schoolId={schoolId} />;
}