import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"
import { Hono } from "npm:hono"
import { cors } from "npm:hono/cors"
import { logger } from "npm:hono/logger"
import * as kv from './kv_store.tsx'

const app = new Hono()

// CORS middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['*'],
}))

// Logger middleware
app.use('*', logger())

// Error handler middleware
app.onError((err, c) => {
  console.error('Server error:', err)
  return c.json({ 
    success: false, 
    error: 'Internal server error', 
    details: err.message 
  }, 500)
})

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
)

// Initialize school data structure
interface SchoolData {
  id: string
  schoolName: string
  institutionType: string
  country: string
  state: string
  town: string
  schoolEmail: string
  contactNumbers: string
  physicalAddress: string
  schoolCategories: string
  selectedGrades: string[]
  classesPerGrade: number
  exceptions: string
  selectedClasses: string[]
  productGroups: Array<{
    id: string
    name: string
    classes: string[]
  }>
  createdAt: string
  updatedAt: string
}

interface DashboardMetrics {
  totalStudents: number
  totalRevenue: number
  outstandingFees: number
  collectionRate: number
  overduePayments: number
  newEnrollments: number
}

interface Student {
  id: string
  schoolId: string
  firstName: string
  lastName: string
  className: string
  grade: string
  parentName: string
  parentPhone: string
  parentEmail: string
  enrollmentDate: string
  feesOwed: number
  feesPaid: number
  status: 'active' | 'inactive' | 'graduated'
}

interface Transaction {
  id: string
  schoolId: string
  studentId: string
  amount: number
  type: 'payment' | 'fee_charge' | 'penalty'
  status: 'pending' | 'completed' | 'failed'
  description: string
  paymentMethod: string
  transactionDate: string
}

interface Notification {
  id: string
  title: string
  message: string
  type: 'info' | 'warning' | 'success' | 'error'
  timestamp: string
  read: boolean
}

// Removed unused authentication interfaces

// Utility functions for demo data generation
const generateSecureCode = (): string => {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// No authentication needed

// Twilio SMS function
const sendSMS = async (to: string, message: string): Promise<boolean> => {
  try {
    const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID')
    const authToken = Deno.env.get('TWILIO_AUTH_TOKEN')
    
    if (!accountSid || !authToken) {
      console.warn('Twilio credentials not configured. SMS will be simulated.')
      console.log(`SMS Simulation - To: ${to}, Message: ${message}`)
      return true // Simulate success for demo
    }

    const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`
    const auth = btoa(`${accountSid}:${authToken}`)
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams({
        From: '+1234567890', // Configure your Twilio phone number
        To: to,
        Body: message
      })
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('Twilio SMS error:', errorText)
      return false
    }

    console.log('SMS sent successfully to:', to)
    return true
  } catch (error) {
    console.error('SMS sending failed:', error)
    return false
  }
}

// Email function (mock - replace with actual email service like SendGrid)
const sendEmail = async (to: string, subject: string, message: string): Promise<boolean> => {
  try {
    // Mock email sending - replace with actual email service
    console.log(`Email Simulation - To: ${to}, Subject: ${subject}, Message: ${message}`)
    
    // In production, integrate with services like:
    // - SendGrid
    // - AWS SES
    // - Mailgun
    // - Postmark
    
    return true // Simulate success
  } catch (error) {
    console.error('Email sending failed:', error)
    return false
  }
}

// Simple mock authentication endpoints for backward compatibility
app.post('/make-server-0a4ed55a/auth/signin', async (c) => {
  return c.json({
    success: true,
    message: 'Demo login successful',
    data: {
      accessToken: 'demo_token',
      schoolId: 'admin_school_demo',
      schoolName: 'Twalumbu Education Centre',
      email: 'demo@example.com'
    }
  })
})

app.post('/make-server-0a4ed55a/auth/verify-session', async (c) => {
  return c.json({
    success: true,
    data: {
      userId: 'demo_user',
      email: 'demo@example.com',
      schoolId: 'admin_school_demo',
      schoolName: 'Twalumbu Education Centre'
    }
  })
})

app.post('/make-server-0a4ed55a/auth/signup', async (c) => {
  return c.json({
    success: true,
    message: 'Demo signup successful',
    data: {
      accessToken: 'demo_token',
      schoolId: 'admin_school_demo',
      schoolName: 'New Demo School',
      email: 'demo@example.com'
    }
  })
})

// Health check
app.get('/make-server-0a4ed55a/health', (c) => {
  return c.json({ 
    success: true, 
    message: 'Master-Fees API is running', 
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  })
})

// Initialize demo data on startup
const initializeDemoData = async () => {
  const adminSchoolId = 'admin_school_demo'
  const adminSchoolName = 'Twalumbu Education Centre'
  
  // Check if demo school exists
  const existingSchool = await kv.get(`school:${adminSchoolId}`)
  if (!existingSchool) {
    console.log('Initializing demo school data...')
    
    const schoolData: SchoolData = {
      id: adminSchoolId,
      schoolName: adminSchoolName,
      institutionType: 'Private Primary School',
      country: 'Zambia',
      state: 'Central Province',
      town: 'Kabwe',
      schoolEmail: 'admin@twalumbu.edu.zm',
      contactNumbers: '+260-97-123-4567, +260-21-234-5678',
      physicalAddress: 'Plot 123, Education Road, Kabwe Central, Zambia',
      schoolCategories: 'Private Primary Education, STEM Focus',
      selectedGrades: ['Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7'],
      classesPerGrade: 2,
      exceptions: 'Grade 7 has 3 classes due to high enrollment',
      selectedClasses: ['Grade 1A', 'Grade 1B', 'Grade 2A', 'Grade 2B', 'Grade 3A', 'Grade 3B'],
      productGroups: [
        {
          id: 'primary-lower',
          name: 'Lower Primary (Grades 1-3)',
          classes: ['Grade 1A', 'Grade 1B', 'Grade 2A', 'Grade 2B', 'Grade 3A', 'Grade 3B']
        },
        {
          id: 'primary-upper',
          name: 'Upper Primary (Grades 4-7)',  
          classes: ['Grade 4A', 'Grade 4B', 'Grade 5A', 'Grade 5B', 'Grade 6A', 'Grade 6B', 'Grade 7A', 'Grade 7B', 'Grade 7C']
        }
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`school:${adminSchoolId}`, schoolData)
    
    // Initialize demo metrics
    const demoMetrics: DashboardMetrics = {
      totalStudents: 147,
      totalRevenue: 532000,
      outstandingFees: 87500,
      collectionRate: 84.2,
      overduePayments: 12,
      newEnrollments: 7
    }
    
    await kv.set(`school:${adminSchoolId}:metrics`, demoMetrics)
    
    console.log('Demo school data initialized successfully!')
  }
}

// Initialize demo data when server starts
initializeDemoData().catch(error => {
  console.error('Failed to initialize demo data:', error)
})

// Public Routes - no authentication required

// School routes
app.get('/make-server-0a4ed55a/schools/:schoolId', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    
    const schoolData = await kv.get(`school:${schoolId}`)
    if (!schoolData) {
      return c.json({ success: false, error: 'School not found' }, 404)
    }
    
    return c.json({ success: true, data: schoolData })
  } catch (error) {
    console.error('Error fetching school:', error)
    return c.json({ success: false, error: 'Failed to fetch school data' }, 500)
  }
})

// Dashboard metrics
app.get('/make-server-0a4ed55a/schools/:schoolId/metrics', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    
    let metrics = await kv.get(`school:${schoolId}:metrics`)
    
    // If no metrics exist, create default ones
    if (!metrics) {
      const defaultMetrics: DashboardMetrics = {
        totalStudents: 147,
        totalRevenue: 532000,
        outstandingFees: 87500,
        collectionRate: 84.2,
        overduePayments: 12,
        newEnrollments: 7
      }
      await kv.set(`school:${schoolId}:metrics`, defaultMetrics)
      metrics = defaultMetrics
    }
    
    return c.json({ success: true, data: metrics })
  } catch (error) {
    console.error('Error fetching metrics:', error)
    return c.json({ success: false, error: 'Failed to fetch metrics' }, 500)
  }
})

// Customer metrics endpoint
app.get('/make-server-0a4ed55a/schools/:schoolId/customer-metrics', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    
    // Get existing dashboard metrics to calculate customer metrics
    const dashboardMetrics = await kv.get(`school:${schoolId}:metrics`) || {
      totalStudents: 147,
      totalRevenue: 532000,
      outstandingFees: 87500,
      collectionRate: 84.2,
      overduePayments: 12,
      newEnrollments: 7
    }
    
    // Calculate customer-specific metrics based on dashboard data
    const totalCustomers = dashboardMetrics.totalStudents
    const activeCustomers = Math.floor(totalCustomers * 0.85) // 85% active rate
    const newCustomersThisMonth = dashboardMetrics.newEnrollments
    const customerGrowthRate = Math.random() * 20 + 5 // 5-25% growth rate
    const averagePaymentTime = Math.random() * 10 + 3 // 3-13 days average
    
    const customerMetrics = {
      totalCustomers,
      activeCustomers,
      newCustomersThisMonth,
      customerGrowthRate: Math.round(customerGrowthRate * 10) / 10, // Round to 1 decimal
      averagePaymentTime: Math.round(averagePaymentTime * 10) / 10 // Round to 1 decimal
    }
    
    // Cache the calculated metrics
    await kv.set(`school:${schoolId}:customer-metrics`, customerMetrics)
    
    console.log(`✅ Customer metrics calculated for school ${schoolId}:`, customerMetrics)
    
    return c.json({ success: true, data: customerMetrics })
  } catch (error) {
    console.error('Error fetching customer metrics:', error)
    return c.json({ success: false, error: 'Failed to fetch customer metrics' }, 500)
  }
})

// Students routes
app.get('/make-server-0a4ed55a/schools/:schoolId/students', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    
    const students = await kv.getByPrefix(`school:${schoolId}:student:`)
    return c.json({ success: true, data: students || [] })
  } catch (error) {
    console.error('Error fetching students:', error)
    return c.json({ success: false, error: 'Failed to fetch students' }, 500)
  }
})

app.post('/make-server-0a4ed55a/schools/:schoolId/students', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    const studentData = await c.req.json()
    
    const studentId = `student_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const student: Student = {
      id: studentId,
      schoolId,
      ...studentData,
      enrollmentDate: new Date().toISOString()
    }
    
    await kv.set(`school:${schoolId}:student:${studentId}`, student)
    
    // Update metrics
    const metrics = await kv.get(`school:${schoolId}:metrics`) || {}
    metrics.totalStudents = (metrics.totalStudents || 0) + 1
    metrics.newEnrollments = (metrics.newEnrollments || 0) + 1
    await kv.set(`school:${schoolId}:metrics`, metrics)
    
    return c.json({ success: true, data: student })
  } catch (error) {
    console.error('Error creating student:', error)
    return c.json({ success: false, error: 'Failed to create student' }, 500)
  }
})

// Transactions routes
app.get('/make-server-0a4ed55a/schools/:schoolId/transactions', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    
    const transactions = await kv.getByPrefix(`school:${schoolId}:transaction:`)
    return c.json({ success: true, data: transactions || [] })
  } catch (error) {
    console.error('Error fetching transactions:', error)
    return c.json({ success: false, error: 'Failed to fetch transactions' }, 500)
  }
})

app.get('/make-server-0a4ed55a/schools/:schoolId/transactions/term/:term', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    const term = c.req.param('term')
    
    // Get all transactions for the school
    const allTransactions = await kv.getByPrefix(`school:${schoolId}:transaction:`)
    
    // Filter by term (for demo, we'll generate realistic data based on term)
    const termMultiplier = term === 'Term 1' ? 0.85 : term === 'Term 2' ? 1.0 : 1.15
    const baseRevenue = 532000
    const baseOutstanding = 87500
    
    const termRevenue = Math.floor(baseRevenue * termMultiplier)
    const termOutstanding = Math.floor(baseOutstanding * (2 - termMultiplier))
    const termBalance = Math.max(0, termRevenue - termOutstanding)
    
    return c.json({ 
      success: true, 
      data: {
        transactions: allTransactions || [],
        totalRevenue: termRevenue,
        totalBalance: termBalance,
        outstandingFees: termOutstanding,
        term: term
      }
    })
  } catch (error) {
    console.error('Error fetching term transactions:', error)
    return c.json({ success: false, error: 'Failed to fetch term transactions' }, 500)
  }
})

// Notifications routes
app.get('/make-server-0a4ed55a/schools/:schoolId/notifications', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    
    const notifications = await kv.getByPrefix(`school:${schoolId}:notification:`)
    return c.json({ success: true, data: notifications || [] })
  } catch (error) {
    console.error('Error fetching notifications:', error)
    return c.json({ success: false, error: 'Failed to fetch notifications' }, 500)
  }
})

app.post('/make-server-0a4ed55a/schools/:schoolId/notifications', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    const notificationData = await c.req.json()
    
    const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const notification: Notification = {
      id: notificationId,
      ...notificationData,
      timestamp: new Date().toISOString(),
      read: false
    }
    
    await kv.set(`school:${schoolId}:notification:${notificationId}`, notification)
    
    return c.json({ success: true, data: notification })
  } catch (error) {
    console.error('Error creating notification:', error)
    return c.json({ success: false, error: 'Failed to create notification' }, 500)
  }
})

// Bulk create students endpoint
app.post('/make-server-0a4ed55a/schools/:schoolId/students/bulk', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    const studentsData = await c.req.json()
    
    if (!Array.isArray(studentsData)) {
      return c.json({ success: false, error: 'Students data must be an array' }, 400)
    }
    
    const createdStudents = []
    
    for (const studentData of studentsData) {
      const studentId = `student_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      const student: Student = {
        id: studentId,
        schoolId,
        ...studentData,
        enrollmentDate: new Date().toISOString()
      }
      
      await kv.set(`school:${schoolId}:student:${studentId}`, student)
      createdStudents.push(student)
    }
    
    // Update metrics
    const metrics = await kv.get(`school:${schoolId}:metrics`) || {}
    metrics.totalStudents = (metrics.totalStudents || 0) + createdStudents.length
    metrics.newEnrollments = (metrics.newEnrollments || 0) + createdStudents.length
    await kv.set(`school:${schoolId}:metrics`, metrics)
    
    console.log(`✅ Created ${createdStudents.length} students for school ${schoolId}`)
    
    return c.json({ success: true, data: createdStudents })
  } catch (error) {
    console.error('Error bulk creating students:', error)
    return c.json({ success: false, error: 'Failed to create students' }, 500)
  }
})

// Create school endpoint
app.post('/make-server-0a4ed55a/schools', async (c) => {
  try {
    const schoolData = await c.req.json()
    
    const schoolId = `school_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const school: SchoolData = {
      id: schoolId,
      ...schoolData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`school:${schoolId}`, school)
    
    // Initialize default metrics for new school
    const defaultMetrics: DashboardMetrics = {
      totalStudents: 0,
      totalRevenue: 0,
      outstandingFees: 0,
      collectionRate: 0,
      overduePayments: 0,
      newEnrollments: 0
    }
    
    await kv.set(`school:${schoolId}:metrics`, defaultMetrics)
    
    console.log(`✅ Created new school: ${schoolId} - ${school.schoolName}`)
    
    return c.json({ success: true, schoolId, data: school })
  } catch (error) {
    console.error('Error creating school:', error)
    return c.json({ success: false, error: 'Failed to create school' }, 500)
  }
})

// Create transaction endpoint
app.post('/make-server-0a4ed55a/schools/:schoolId/transactions', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    const transactionData = await c.req.json()
    
    const transactionId = `transaction_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const transaction: Transaction = {
      id: transactionId,
      schoolId,
      ...transactionData,
      transactionDate: new Date().toISOString()
    }
    
    await kv.set(`school:${schoolId}:transaction:${transactionId}`, transaction)
    
    // Update metrics if it's a completed payment
    if (transaction.type === 'payment' && transaction.status === 'completed') {
      const metrics = await kv.get(`school:${schoolId}:metrics`) || {}
      metrics.totalRevenue = (metrics.totalRevenue || 0) + transaction.amount
      metrics.outstandingFees = Math.max(0, (metrics.outstandingFees || 0) - transaction.amount)
      
      // Recalculate collection rate
      if (metrics.totalRevenue > 0) {
        const totalFees = metrics.totalRevenue + metrics.outstandingFees
        metrics.collectionRate = Math.round((metrics.totalRevenue / totalFees) * 100 * 10) / 10
      }
      
      await kv.set(`school:${schoolId}:metrics`, metrics)
    }
    
    console.log(`✅ Created transaction ${transactionId} for school ${schoolId}: ${transaction.amount}`)
    
    return c.json({ success: true, data: transaction })
  } catch (error) {
    console.error('Error creating transaction:', error)
    return c.json({ success: false, error: 'Failed to create transaction' }, 500)
  }
})

// Mark notification as read endpoint
app.put('/make-server-0a4ed55a/schools/:schoolId/notifications/:notificationId/read', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    const notificationId = c.req.param('notificationId')
    
    const notification = await kv.get(`school:${schoolId}:notification:${notificationId}`)
    if (!notification) {
      return c.json({ success: false, error: 'Notification not found' }, 404)
    }
    
    const updatedNotification = {
      ...notification,
      read: true
    }
    
    await kv.set(`school:${schoolId}:notification:${notificationId}`, updatedNotification)
    
    return c.json({ success: true, data: updatedNotification })
  } catch (error) {
    console.error('Error marking notification as read:', error)
    return c.json({ success: false, error: 'Failed to mark notification as read' }, 500)
  }
})

// Generate sample data endpoint (no authentication required)
app.post('/make-server-0a4ed55a/schools/:schoolId/generate-sample-data', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    
    console.log(`🎲 Generating sample data for school: ${schoolId}`)
    
    // Generate sample students
    const sampleStudents = [
      {
        firstName: 'John',
        lastName: 'Banda',
        className: 'Grade 5A',
        grade: 'Grade 5',
        parentName: 'Mary Banda',
        parentPhone: '+260-97-123-4567',
        parentEmail: 'mary.banda@example.com',
        feesOwed: 2500,
        feesPaid: 2000,
        status: 'active'
      },
      {
        firstName: 'Sarah',
        lastName: 'Mwanza',
        className: 'Grade 3B',
        grade: 'Grade 3',
        parentName: 'Peter Mwanza',
        parentPhone: '+260-96-234-5678',
        parentEmail: 'peter.mwanza@example.com',
        feesOwed: 2200,
        feesPaid: 2200,
        status: 'active'
      },
      {
        firstName: 'David',
        lastName: 'Phiri',
        className: 'Grade 7A',
        grade: 'Grade 7',
        parentName: 'Grace Phiri',
        parentPhone: '+260-95-345-6789',
        parentEmail: 'grace.phiri@example.com',
        feesOwed: 3000,
        feesPaid: 1500,
        status: 'active'
      }
    ]
    
    let createdStudents = 0
    for (const studentData of sampleStudents) {
      const studentId = `student_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      const student: Student = {
        id: studentId,
        schoolId,
        ...studentData,
        enrollmentDate: new Date().toISOString()
      }
      
      await kv.set(`school:${schoolId}:student:${studentId}`, student)
      createdStudents++
    }
    
    // Generate sample transactions
    const sampleTransactions = [
      {
        studentId: 'demo_student_1',
        amount: 1000,
        type: 'payment',
        status: 'completed',
        description: 'Tuition payment - Term 2',
        paymentMethod: 'Mobile Money',
        transactionDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        studentId: 'demo_student_2',
        amount: 500,
        type: 'payment',
        status: 'completed',
        description: 'Lunch program payment',
        paymentMethod: 'Bank Transfer',
        transactionDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      }
    ]
    
    let createdTransactions = 0
    for (const transactionData of sampleTransactions) {
      const transactionId = `transaction_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      const transaction: Transaction = {
        id: transactionId,
        schoolId,
        ...transactionData
      }
      
      await kv.set(`school:${schoolId}:transaction:${transactionId}`, transaction)
      createdTransactions++
    }
    
    console.log(`✅ Sample data generated: ${createdStudents} students, ${createdTransactions} transactions`)
    
    return c.json({ 
      success: true, 
      message: 'Sample data generated successfully',
      data: {
        studentsCreated: createdStudents,
        transactionsCreated: createdTransactions
      }
    })
  } catch (error) {
    console.error('Error generating sample data:', error)
    return c.json({ success: false, error: 'Failed to generate sample data' }, 500)
  }
})

// Start the server
serve(app.fetch)

// QuickBooks Integration Routes

interface QuickBooksConnection {
  schoolId: string
  accessToken: string
  refreshToken: string
  realmId: string
  companyName: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  lastSync?: string
  autoSync: boolean
}

// QuickBooks API helper functions
const getQuickBooksAPIUrl = (realmId: string) => {
  return `https://sandbox-quickbooks.api.intuit.com/v3/company/${realmId}`
}

const refreshQuickBooksToken = async (refreshToken: string) => {
  try {
    const clientId = Deno.env.get('QUICKBOOKS_CLIENT_ID')
    const clientSecret = Deno.env.get('QUICKBOOKS_CLIENT_SECRET')
    
    if (!clientId || !clientSecret) {
      throw new Error('QuickBooks credentials not configured')
    }

    const response = await fetch('https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${btoa(`${clientId}:${clientSecret}`)}`
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: refreshToken
      })
    })

    if (!response.ok) {
      throw new Error('Failed to refresh QuickBooks token')
    }

    const data = await response.json()
    return {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      expiresIn: data.expires_in
    }
  } catch (error) {
    console.error('Error refreshing QuickBooks token:', error)
    throw error
  }
}

const makeQuickBooksRequest = async (connection: QuickBooksConnection, endpoint: string, method: string = 'GET', body?: any) => {
  try {
    const url = `${getQuickBooksAPIUrl(connection.realmId)}/${endpoint}`
    
    const response = await fetch(url, {
      method,
      headers: {
        'Authorization': `Bearer ${connection.accessToken}`,
        'Content-Type': 'application/json'
      },
      body: body ? JSON.stringify(body) : undefined
    })

    if (response.status === 401) {
      // Token expired, try to refresh
      const refreshResult = await refreshQuickBooksToken(connection.refreshToken)
      
      // Update stored connection with new tokens
      const updatedConnection = {
        ...connection,
        accessToken: refreshResult.accessToken,
        refreshToken: refreshResult.refreshToken,
        updatedAt: new Date().toISOString()
      }
      
      await kv.set(`quickbooks:connection:${connection.schoolId}`, updatedConnection)
      
      // Retry the request with new token
      const retryResponse = await fetch(url, {
        method,
        headers: {
          'Authorization': `Bearer ${refreshResult.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: body ? JSON.stringify(body) : undefined
      })

      if (!retryResponse.ok) {
        throw new Error(`QuickBooks API error: ${retryResponse.status}`)
      }

      return retryResponse.json()
    }

    if (!response.ok) {
      throw new Error(`QuickBooks API error: ${response.status}`)
    }

    return response.json()
  } catch (error) {
    console.error('QuickBooks API request failed:', error)
    throw error
  }
}

// Check QuickBooks connection status
app.get('/make-server-0a4ed55a/integrations/quickbooks/status', async (c) => {
  try {
    const schoolId = c.req.query('schoolId')
    
    if (!schoolId) {
      return c.json({ error: 'School ID is required' }, 400)
    }

    const connection = await kv.get(`quickbooks:connection:${schoolId}`)
    const syncStatus = await kv.get(`quickbooks:sync:${schoolId}`) || {
      isLoading: false,
      lastSync: null,
      error: null,
      syncedItems: { customers: 0, invoices: 0, payments: 0 }
    }

    return c.json({
      success: true,
      connection: {
        isConnected: !!connection,
        companyName: connection?.companyName,
        lastSync: connection?.lastSync,
        error: connection?.isActive === false ? 'Connection expired' : null
      },
      syncStatus,
      autoSync: connection?.autoSync || false
    })
  } catch (error) {
    console.error('Error checking QuickBooks status:', error)
    return c.json({ error: 'Failed to check connection status' }, 500)
  }
})

// Handle QuickBooks OAuth callback
app.post('/make-server-0a4ed55a/integrations/quickbooks/callback', async (c) => {
  try {
    const { code, state, realmId } = await c.req.json()
    
    if (!code || !state || !realmId) {
      return c.json({ error: 'Missing required OAuth parameters' }, 400)
    }

    // Decode state to get school ID
    const stateData = JSON.parse(atob(state))
    const schoolId = stateData.schoolId

    const clientId = Deno.env.get('QUICKBOOKS_CLIENT_ID')
    const clientSecret = Deno.env.get('QUICKBOOKS_CLIENT_SECRET')
    
    if (!clientId || !clientSecret) {
      return c.json({ error: 'QuickBooks credentials not configured' }, 500)
    }

    // Exchange authorization code for access token
    const tokenResponse = await fetch('https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${btoa(`${clientId}:${clientSecret}`)}`
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: `${c.req.url.split('/api')[0]}/api/integrations/quickbooks/callback`
      })
    })

    if (!tokenResponse.ok) {
      const error = await tokenResponse.text()
      console.error('QuickBooks token exchange failed:', error)
      return c.json({ error: 'Failed to exchange authorization code' }, 400)
    }

    const tokenData = await tokenResponse.json()

    // Get company info
    const companyInfoResponse = await fetch(`${getQuickBooksAPIUrl(realmId)}/companyinfo/${realmId}`, {
      headers: {
        'Authorization': `Bearer ${tokenData.access_token}`
      }
    })

    let companyName = 'QuickBooks Company'
    if (companyInfoResponse.ok) {
      const companyData = await companyInfoResponse.json()
      companyName = companyData.QueryResponse?.CompanyInfo?.[0]?.CompanyName || companyName
    }

    // Store connection
    const connection: QuickBooksConnection = {
      schoolId,
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      realmId,
      companyName,
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      autoSync: false
    }

    await kv.set(`quickbooks:connection:${schoolId}`, connection)

    console.log(`QuickBooks connected for school: ${schoolId}`)
    return c.json({ success: true, companyName })
  } catch (error) {
    console.error('Error handling QuickBooks callback:', error)
    return c.json({ error: 'Failed to complete QuickBooks connection' }, 500)
  }
})

// Disconnect QuickBooks
app.post('/make-server-0a4ed55a/integrations/quickbooks/disconnect', async (c) => {
  try {
    const { schoolId } = await c.req.json()
    
    if (!schoolId) {
      return c.json({ error: 'School ID is required' }, 400)
    }

    // Remove connection
    await kv.del(`quickbooks:connection:${schoolId}`)
    await kv.del(`quickbooks:sync:${schoolId}`)

    console.log(`QuickBooks disconnected for school: ${schoolId}`)
    return c.json({ success: true })
  } catch (error) {
    console.error('Error disconnecting QuickBooks:', error)
    return c.json({ error: 'Failed to disconnect QuickBooks' }, 500)
  }
})

// Sync data with QuickBooks
app.post('/make-server-0a4ed55a/integrations/quickbooks/sync', async (c) => {
  try {
    const { schoolId, syncType } = await c.req.json()
    
    if (!schoolId) {
      return c.json({ error: 'School ID is required' }, 400)
    }

    const connection = await kv.get(`quickbooks:connection:${schoolId}`)
    if (!connection) {
      return c.json({ error: 'QuickBooks not connected' }, 400)
    }

    // Update sync status
    await kv.set(`quickbooks:sync:${schoolId}`, {
      isLoading: true,
      lastSync: null,
      error: null,
      syncedItems: { customers: 0, invoices: 0, payments: 0 }
    })

    try {
      // Get school data
      const students = await kv.getByPrefix(`school:${schoolId}:student:`) || []
      const transactions = await kv.getByPrefix(`school:${schoolId}:transaction:`) || []

      let syncedItems = { customers: 0, invoices: 0, payments: 0 }

      // Sync students as customers
      for (const student of students) {
        try {
          // Check if customer already exists
          const customerQuery = await makeQuickBooksRequest(
            connection,
            `customers?where=CompanyName='${student.firstName} ${student.lastName}'`
          )

          if (customerQuery.QueryResponse?.Customer?.length === 0) {
            // Create new customer
            const customerData = {
              Name: `${student.firstName} ${student.lastName}`,
              CompanyName: `${student.firstName} ${student.lastName}`,
              PrimaryEmailAddr: {
                Address: student.parentEmail
              },
              PrimaryPhone: {
                FreeFormNumber: student.parentPhone
              },
              BillAddr: {
                Line1: 'Student Address',
                City: 'City',
                Country: 'Country'
              }
            }

            await makeQuickBooksRequest(connection, 'customers', 'POST', customerData)
            syncedItems.customers++
          }
        } catch (error) {
          console.error(`Error syncing student ${student.id}:`, error)
        }
      }

      // Sync transactions as invoices/payments
      for (const transaction of transactions) {
        try {
          if (transaction.type === 'payment') {
            // Create payment record
            const paymentData = {
              CustomerRef: {
                value: "1" // This would need to be mapped to actual customer ID
              },
              TotalAmt: transaction.amount,
              TxnDate: transaction.transactionDate.split('T')[0],
              PaymentMethodRef: {
                value: "1" // This would need to be mapped to actual payment method
              }
            }

            await makeQuickBooksRequest(connection, 'payments', 'POST', paymentData)
            syncedItems.payments++
          }
        } catch (error) {
          console.error(`Error syncing transaction ${transaction.id}:`, error)
        }
      }

      // Update connection with last sync time
      await kv.set(`quickbooks:connection:${schoolId}`, {
        ...connection,
        lastSync: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      })

      // Update sync status
      await kv.set(`quickbooks:sync:${schoolId}`, {
        isLoading: false,
        lastSync: new Date().toISOString(),
        error: null,
        syncedItems
      })

      console.log(`QuickBooks sync completed for school: ${schoolId}`)
      return c.json({ success: true, syncedItems })

    } catch (syncError) {
      // Update sync status with error
      await kv.set(`quickbooks:sync:${schoolId}`, {
        isLoading: false,
        lastSync: null,
        error: syncError.message,
        syncedItems: { customers: 0, invoices: 0, payments: 0 }
      })

      throw syncError
    }
  } catch (error) {
    console.error('Error syncing with QuickBooks:', error)
    return c.json({ error: 'Failed to sync data with QuickBooks' }, 500)
  }
})

// Toggle auto-sync
app.post('/make-server-0a4ed55a/integrations/quickbooks/auto-sync', async (c) => {
  try {
    const { schoolId, enabled } = await c.req.json()
    
    if (!schoolId) {
      return c.json({ error: 'School ID is required' }, 400)
    }

    const connection = await kv.get(`quickbooks:connection:${schoolId}`)
    if (!connection) {
      return c.json({ error: 'QuickBooks not connected' }, 400)
    }

    // Update auto-sync setting
    await kv.set(`quickbooks:connection:${schoolId}`, {
      ...connection,
      autoSync: enabled,
      updatedAt: new Date().toISOString()
    })

    console.log(`QuickBooks auto-sync ${enabled ? 'enabled' : 'disabled'} for school: ${schoolId}`)
    return c.json({ success: true })
  } catch (error) {
    console.error('Error toggling auto-sync:', error)
    return c.json({ error: 'Failed to update auto-sync setting' }, 500)
  }
})

// School onboarding routes
app.post('/make-server-0a4ed55a/schools', async (c) => {
  try {
    const schoolData: Omit<SchoolData, 'id' | 'createdAt' | 'updatedAt'> = await c.req.json()
    
    const schoolId = `school_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const now = new Date().toISOString()
    
    const fullSchoolData: SchoolData = {
      id: schoolId,
      ...schoolData,
      createdAt: now,
      updatedAt: now
    }
    
    await kv.set(`school:${schoolId}`, fullSchoolData)
    
    // Initialize default metrics for the school
    const defaultMetrics: DashboardMetrics = {
      totalStudents: 0,
      totalRevenue: 0,
      outstandingFees: 0,
      collectionRate: 0,
      overduePayments: 0,
      newEnrollments: 0
    }
    
    await kv.set(`school:${schoolId}:metrics`, defaultMetrics)
    
    console.log(`School created successfully: ${schoolId}`)
    return c.json({ 
      success: true, 
      schoolId,
      message: 'School created successfully',
      data: fullSchoolData
    })
  } catch (error) {
    console.log(`Error creating school: ${error}`)
    return c.json({ error: 'Failed to create school', details: error.message }, 500)
  }
})

app.get('/make-server-0a4ed55a/schools/:id', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const schoolData = await kv.get(`school:${schoolId}`)
    
    if (!schoolData) {
      return c.json({ error: 'School not found' }, 404)
    }
    
    return c.json({ success: true, data: schoolData })
  } catch (error) {
    console.log(`Error fetching school: ${error}`)
    return c.json({ error: 'Failed to fetch school', details: error.message }, 500)
  }
})

app.put('/make-server-0a4ed55a/schools/:id', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const updateData = await c.req.json()
    
    const existingSchool = await kv.get(`school:${schoolId}`)
    if (!existingSchool) {
      return c.json({ error: 'School not found' }, 404)
    }
    
    const updatedSchool = {
      ...existingSchool,
      ...updateData,
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`school:${schoolId}`, updatedSchool)
    
    return c.json({ success: true, data: updatedSchool })
  } catch (error) {
    console.log(`Error updating school: ${error}`)
    return c.json({ error: 'Failed to update school', details: error.message }, 500)
  }
})

// Dashboard metrics routes
app.get('/make-server-0a4ed55a/schools/:id/metrics', async (c) => {
  try {
    const schoolId = c.req.param('id')
    
    // Get stored metrics or calculate from data
    let metrics = await kv.get(`school:${schoolId}:metrics`)
    
    if (!metrics) {
      // Calculate metrics from actual data
      const students = await kv.getByPrefix(`school:${schoolId}:student:`) || []
      const transactions = await kv.getByPrefix(`school:${schoolId}:transaction:`) || []
      
      const totalStudents = students.length
      const totalRevenue = transactions
        .filter(t => t.type === 'payment' && t.status === 'completed')
        .reduce((sum, t) => sum + t.amount, 0)
      
      const outstandingFees = students.reduce((sum, s) => sum + (s.feesOwed - s.feesPaid), 0)
      const collectionRate = totalRevenue > 0 ? (totalRevenue / (totalRevenue + outstandingFees)) * 100 : 0
      
      const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
      const newEnrollments = students.filter(s => s.enrollmentDate > oneWeekAgo).length
      
      const overduePayments = students.filter(s => s.feesOwed > s.feesPaid).length
      
      metrics = {
        totalStudents,
        totalRevenue,
        outstandingFees,
        collectionRate: Math.round(collectionRate * 10) / 10,
        overduePayments,
        newEnrollments
      }
      
      await kv.set(`school:${schoolId}:metrics`, metrics)
    }
    
    return c.json({ success: true, data: metrics })
  } catch (error) {
    console.log(`Error fetching metrics: ${error}`)
    return c.json({ error: 'Failed to fetch metrics', details: error.message }, 500)
  }
})

// Student management routes
app.post('/make-server-0a4ed55a/schools/:id/students', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const studentData: Omit<Student, 'id' | 'schoolId'> = await c.req.json()
    
    const studentId = `student_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    
    const student: Student = {
      id: studentId,
      schoolId,
      ...studentData,
      enrollmentDate: studentData.enrollmentDate || new Date().toISOString()
    }
    
    await kv.set(`school:${schoolId}:student:${studentId}`, student)
    
    // Update metrics
    const metrics = await kv.get(`school:${schoolId}:metrics`) || {}
    metrics.totalStudents = (metrics.totalStudents || 0) + 1
    metrics.newEnrollments = (metrics.newEnrollments || 0) + 1
    await kv.set(`school:${schoolId}:metrics`, metrics)
    
    return c.json({ success: true, studentId, data: student })
  } catch (error) {
    console.log(`Error creating student: ${error}`)
    return c.json({ error: 'Failed to create student', details: error.message }, 500)
  }
})

app.get('/make-server-0a4ed55a/schools/:id/students', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const students = await kv.getByPrefix(`school:${schoolId}:student:`) || []
    
    return c.json({ success: true, data: students })
  } catch (error) {
    console.log(`Error fetching students: ${error}`)
    return c.json({ error: 'Failed to fetch students', details: error.message }, 500)
  }
})

// Transaction routes
app.post('/make-server-0a4ed55a/schools/:id/transactions', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const transactionData: Omit<Transaction, 'id' | 'schoolId'> = await c.req.json()
    
    const transactionId = `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    
    const transaction: Transaction = {
      id: transactionId,
      schoolId,
      ...transactionData,
      transactionDate: transactionData.transactionDate || new Date().toISOString()
    }
    
    await kv.set(`school:${schoolId}:transaction:${transactionId}`, transaction)
    
    // Update student fees if it's a payment
    if (transaction.type === 'payment' && transaction.status === 'completed') {
      const student = await kv.get(`school:${schoolId}:student:${transaction.studentId}`)
      if (student) {
        student.feesPaid = (student.feesPaid || 0) + transaction.amount
        await kv.set(`school:${schoolId}:student:${transaction.studentId}`, student)
      }
      
      // Update metrics
      const metrics = await kv.get(`school:${schoolId}:metrics`) || {}
      metrics.totalRevenue = (metrics.totalRevenue || 0) + transaction.amount
      await kv.set(`school:${schoolId}:metrics`, metrics)
    }
    
    return c.json({ success: true, transactionId, data: transaction })
  } catch (error) {
    console.log(`Error creating transaction: ${error}`)
    return c.json({ error: 'Failed to create transaction', details: error.message }, 500)
  }
})

app.get('/make-server-0a4ed55a/schools/:id/transactions', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const transactions = await kv.getByPrefix(`school:${schoolId}:transaction:`) || []
    
    return c.json({ success: true, data: transactions })
  } catch (error) {
    console.log(`Error fetching transactions: ${error}`)
    return c.json({ error: 'Failed to fetch transactions', details: error.message }, 500)
  }
})

// Get transactions by term
app.get('/make-server-0a4ed55a/schools/:schoolId/transactions/term/:term', async (c) => {
  try {
    const schoolId = c.req.param('schoolId')
    const term = decodeURIComponent(c.req.param('term'))
    
    console.log(`📊 Getting transactions for school ${schoolId}, term: ${term}`)
    
    // Get all transactions for the school
    const allTransactions = await kv.getByPrefix(`school:${schoolId}:transaction:`) || []
    
    // Filter transactions by term (this would be based on transaction dates or term field)
    const termTransactions = allTransactions.filter(transaction => {
      // For demo purposes, we'll calculate term-based metrics
      // In a real app, you'd filter by actual transaction.term or date ranges
      return true; // Include all for now, but calculate term-specific totals
    })
    
    // Calculate term-specific metrics based on multipliers
    const termMultiplier = getTermMultiplier(term)
    
    // Get school metrics to use as base
    const schoolMetrics = await kv.get(`school:${schoolId}:metrics`)
    const baseRevenue = schoolMetrics?.totalRevenue || 532000
    const baseOutstanding = schoolMetrics?.outstandingFees || 87500
    
    const termRevenue = Math.floor(baseRevenue * termMultiplier)
    const termOutstanding = Math.floor(baseOutstanding * (2 - termMultiplier))
    const termBalance = Math.max(0, termRevenue - termOutstanding)
    
    console.log(`✅ Term ${term} metrics calculated:`, {
      revenue: termRevenue,
      balance: termBalance,
      outstanding: termOutstanding,
      multiplier: termMultiplier
    })
    
    return c.json({
      success: true,
      data: {
        transactions: termTransactions,
        totalRevenue: termRevenue,
        totalBalance: termBalance,
        outstandingFees: termOutstanding,
        term: term
      }
    })
  } catch (error) {
    console.error('Get transactions by term error:', error)
    return c.json({ success: false, error: 'Failed to get term transactions' }, 500)
  }
})

function getTermMultiplier(term: string): number {
  switch (term) {
    case 'Term 1':
      return 0.85 // Term 1 typically has lower collection rates
    case 'Term 2':
      return 1.0 // Current term (baseline)
    case 'Term 3':
      return 1.15 // Term 3 often has higher collection due to year-end push
    default:
      return 1.0
  }
}

// Notifications routes
app.get('/make-server-0a4ed55a/schools/:id/notifications', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const notifications = await kv.get(`school:${schoolId}:notifications`) || []
    
    return c.json({ success: true, data: notifications })
  } catch (error) {
    console.log(`Error fetching notifications: ${error}`)
    return c.json({ error: 'Failed to fetch notifications', details: error.message }, 500)
  }
})

app.post('/make-server-0a4ed55a/schools/:id/notifications', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const notificationData = await c.req.json()
    
    const notifications = await kv.get(`school:${schoolId}:notifications`) || []
    const newNotification: Notification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...notificationData,
      timestamp: new Date().toISOString(),
      read: false
    }
    
    notifications.unshift(newNotification)
    
    // Keep only last 50 notifications
    if (notifications.length > 50) {
      notifications.splice(50)
    }
    
    await kv.set(`school:${schoolId}:notifications`, notifications)
    
    return c.json({ success: true, data: newNotification })
  } catch (error) {
    console.log(`Error creating notification: ${error}`)
    return c.json({ error: 'Failed to create notification', details: error.message }, 500)
  }
})

app.put('/make-server-0a4ed55a/schools/:id/notifications/:notificationId/read', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const notificationId = c.req.param('notificationId')
    
    const notifications = await kv.get(`school:${schoolId}:notifications`) || []
    const updatedNotifications = notifications.map(n => 
      n.id === notificationId ? { ...n, read: true } : n
    )
    
    await kv.set(`school:${schoolId}:notifications`, updatedNotifications)
    
    return c.json({ success: true })
  } catch (error) {
    console.log(`Error marking notification as read: ${error}`)
    return c.json({ error: 'Failed to mark notification as read', details: error.message }, 500)
  }
})

// Bulk operations
app.post('/make-server-0a4ed55a/schools/:id/students/bulk', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const studentsData = await c.req.json()
    
    const createdStudents = []
    
    for (const studentData of studentsData) {
      const studentId = `student_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      const student: Student = {
        id: studentId,
        schoolId,
        ...studentData,
        enrollmentDate: studentData.enrollmentDate || new Date().toISOString()
      }
      
      await kv.set(`school:${schoolId}:student:${studentId}`, student)
      createdStudents.push(student)
    }
    
    // Update metrics
    const metrics = await kv.get(`school:${schoolId}:metrics`) || {}
    metrics.totalStudents = (metrics.totalStudents || 0) + createdStudents.length
    metrics.newEnrollments = (metrics.newEnrollments || 0) + createdStudents.length
    await kv.set(`school:${schoolId}:metrics`, metrics)
    
    return c.json({ success: true, count: createdStudents.length, data: createdStudents })
  } catch (error) {
    console.log(`Error bulk creating students: ${error}`)
    return c.json({ error: 'Failed to bulk create students', details: error.message }, 500)
  }
})

// Revenue breakdown routes
app.get('/make-server-0a4ed55a/schools/:id/breakdown', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const category = c.req.query('category')
    
    const students = await kv.getByPrefix(`school:${schoolId}:student:`) || []
    const transactions = await kv.getByPrefix(`school:${schoolId}:transaction:`) || []
    
    // Group by grade or other categories
    const breakdown = students.reduce((acc, student) => {
      const gradeKey = student.grade || 'Unknown'
      if (!acc[gradeKey]) {
        acc[gradeKey] = {
          category: gradeKey,
          budgeted: 0,
          collected: 0,
          outstanding: 0,
          percentage: 0,
          studentCount: 0
        }
      }
      
      acc[gradeKey].budgeted += student.feesOwed || 0
      acc[gradeKey].collected += student.feesPaid || 0
      acc[gradeKey].outstanding += (student.feesOwed || 0) - (student.feesPaid || 0)
      acc[gradeKey].studentCount += 1
      
      return acc
    }, {})
    
    // Calculate percentages
    Object.values(breakdown).forEach((item: any) => {
      item.percentage = item.budgeted > 0 ? (item.collected / item.budgeted) * 100 : 0
      item.percentage = Math.round(item.percentage * 10) / 10
    })
    
    const result = Object.values(breakdown)
    
    // Filter by category if specified
    if (category && category !== 'all') {
      const filtered = result.filter((item: any) => item.category === category)
      return c.json({ success: true, data: filtered })
    }
    
    return c.json({ success: true, data: result })
  } catch (error) {
    console.log(`Error fetching breakdown: ${error}`)
    return c.json({ error: 'Failed to fetch breakdown', details: error.message }, 500)
  }
})

// Real-time activity tracking
app.get('/make-server-0a4ed55a/schools/:id/recent-activity', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const since = c.req.query('since')
    
    // Get recent events from activity log
    const activityLog = await kv.getByPrefix(`school:${schoolId}:activity:`) || []
    
    // Filter by timestamp if 'since' parameter is provided
    let recentActivity = activityLog
    if (since) {
      const sinceTimestamp = new Date(since).getTime()
      recentActivity = activityLog.filter(activity => {
        const activityTime = new Date(activity.timestamp).getTime()
        return activityTime > sinceTimestamp
      })
    }
    
    // Sort by timestamp descending (most recent first)
    recentActivity.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    
    return c.json({ success: true, data: recentActivity.slice(0, 10) })
  } catch (error) {
    console.log(`Error fetching recent activity: ${error}`)
    return c.json({ error: 'Failed to fetch recent activity', details: error.message }, 500)
  }
})

// Production-ready demonstration endpoints (remove demo simulation endpoints for production)

// Demo simulation endpoints (keep for development/testing only)
app.post('/make-server-0a4ed55a/schools/:id/simulate-payment', async (c) => {
  try {
    const schoolId = c.req.param('id')
    const { studentId, amount } = await c.req.json()
    
    // Get student data
    const student = await kv.get(`school:${schoolId}:student:${studentId}`)
    if (!student) {
      return c.json({ error: 'Student not found' }, 404)
    }
    
    // Create payment transaction
    const transactionId = `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const transaction = {
      id: transactionId,
      studentId,
      studentName: student.firstName + ' ' + student.lastName,
      amount,
      type: 'payment',
      status: 'completed',
      method: 'Bank Transfer',
      timestamp: new Date().toISOString(),
      description: `Fee payment from ${student.firstName} ${student.lastName}`
    }
    
    // Save transaction
    await kv.set(`school:${schoolId}:transaction:${transactionId}`, transaction)
    
    // Update student payment record
    const updatedStudent = {
      ...student,
      feesPaid: (student.feesPaid || 0) + amount,
      lastPaymentDate: new Date().toISOString()
    }
    await kv.set(`school:${schoolId}:student:${studentId}`, updatedStudent)
    
    // Create notification
    const notifications = await kv.get(`school:${schoolId}:notifications`) || []
    const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const notification = {
      id: notificationId,
      title: 'Payment Received',
      message: `${student.firstName} ${student.lastName} has made a payment of ${new Intl.NumberFormat('en-ZM', { style: 'currency', currency: 'ZMW' }).format(amount)}`,
      type: 'success',
      timestamp: new Date().toISOString(),
      read: false,
      metadata: {
        studentId,
        amount,
        transactionId
      }
    }
    notifications.unshift(notification)
    
    // Keep only last 50 notifications
    if (notifications.length > 50) {
      notifications.splice(50)
    }
    
    await kv.set(`school:${schoolId}:notifications`, notifications)
    
    return c.json({ 
      success: true, 
      data: { 
        transaction, 
        notification, 
        updatedStudent 
      }
    })
  } catch (error) {
    console.log(`Error simulating payment: ${error}`)
    return c.json({ error: 'Failed to simulate payment', details: error.message }, 500)
  }
})

// Start the server
Deno.serve(app.fetch)