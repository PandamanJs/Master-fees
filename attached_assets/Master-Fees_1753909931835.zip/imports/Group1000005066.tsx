function Frame1707478757() {
  return (
    <div className="absolute bg-[#ff2323] box-border content-stretch flex flex-col gap-2.5 items-center justify-center left-[486px] p-0 rounded-[50px] size-5 top-[9px]">
      <div className="flex flex-col font-['IBM_Plex_Sans_Devanagari:Bold',_sans-serif] h-[15px] justify-end leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[10px] text-center w-full">
        <p className="block leading-[1.45]">25</p>
      </div>
    </div>
  );
}

export default function Group1000005066() {
  return (
    <div className="relative size-full">
      <div className="absolute flex flex-col font-['IBM_Plex_Sans_Devanagari:Medium',_sans-serif] justify-center leading-[0] left-[144.5px] not-italic text-[#000000] text-[24px] text-center text-nowrap top-[18.5px] translate-x-[-50%] translate-y-[-50%]">
        <p className="block leading-[normal] whitespace-pre">
          Scheduled Tasks Calendar
        </p>
      </div>
      <div className="absolute flex flex-col font-['IBM_Plex_Sans_Devanagari:Regular',_sans-serif] justify-center leading-[0] left-[337px] not-italic text-[16px] text-left text-neutral-900 text-nowrap top-[19px] translate-y-[-50%]">
        <p className="block leading-[normal] whitespace-pre">
          Task Schedule List
        </p>
      </div>
      <Frame1707478757 />
    </div>
  );
}