function Frame4() {
  return (
    <div></div>
  );
}

export default function Frame11() {
  return (
    <div className="box-border content-stretch flex flex-row gap-[67px] items-center justify-start p-0 relative size-full">
      <div className="flex flex-col font-['Microsoft_Sans_Serif:Regular',_sans-serif] h-[19px] justify-center leading-[0] not-italic relative shrink-0 text-[#707479] text-[13px] text-center w-[180px]">
        
      </div>
      <Frame4 />
    </div>
  );
}